# HomiGo Care — Minimalist MVP Build Kit

**Scope authority:** This MVP definition supersedes older full-platform prompts and feature lists in this kit.
**Product story:** Convenience + Privacy + Safety.
**Build target:** one connected demo across Patient, Professional (Doctor/Nurse), and Admin.
**Do not expand scope:** no 29-role marketplace, no marketing website, no medicine/lab ordering, no wallet, no referral, no advanced analytics, no full assessment engine.

## What's included
- `00_START_HERE.md`: start/build instructions and boundaries.
- `AI_MASTER_PROMPT.md`: authoritative AI implementation prompt.
- `MVP_SCOPE.md`: feature, screen, data, and acceptance criteria.
- `02_PHASE_PROMPTS/`: build prompts revised for the MVP; Phase 2/3 prompts are deferred references.
- `03_SPECS/`: architecture, API, role, screen, privacy, SOS, QA and state-machine sections scoped to the MVP.
- `04_DESIGN_SYSTEM/`: original logo assets, design tokens, icons and illustrations retained.
- `05_STARTER/mock-api/`: starter mock API retained as a development aid.

## Important interpretation
The kit contains original full-platform reference material and assets so useful technical context is not lost. Where any retained legacy section conflicts with `MVP_SCOPE.md`, `AI_MASTER_PROMPT.md`, or this file, the MVP documents win. Anything not listed as an MVP feature is deferred, not implicitly approved for implementation.
