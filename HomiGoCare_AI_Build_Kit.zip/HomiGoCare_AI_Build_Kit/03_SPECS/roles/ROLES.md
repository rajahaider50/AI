# Roles (29)

Rule: every nurse, doctor and allied-health professional must currently work at, or be affiliated with, a hospital, clinic or accredited program. Profile shows that affiliation.

| # | Role | Side | Phase | What they do | Required documents |
|---|---|---|---|---|---|
| 1 | Individual Patient (`PATIENT`) | patient | 1 | Books services for self | CNIC (optional at signup, needed for verified status) |
| 2 | Family Account Manager (`PATIENT`) | patient | 1 | Manages bookings and records for several family members | Family member profiles |
| 3 | Home Visit Nurse (RN/BSN) (`HOME_VISIT_NURSE`) | professional | 1 | Short visits: injections, wound care, drips, catheter care | CNIC; Pakistan Nursing Council registration; Degree; Experience letter; Hospital/clinic affiliation letter; Character certificate; Profile photo |
| 4 | Dedicated Nurse (RN/BSN) (`DEDICATED_NURSE`) | professional | 1 | 8/12/24 hour continuous care | Same as Home Visit Nurse |
| 5 | Hospital Companion Nurse (`HOSPITAL_COMPANION_NURSE`) | professional | 1 | Stays with patient inside hospital | Same as Home Visit Nurse |
| 6 | Student Nurse (`STUDENT_NURSE`) | professional | 1 | Basic tasks only under supervisor approval; labeled Student | CNIC; Student ID; Program enrollment letter (2nd year+); Supervisor approval |
| 7 | Intern Nurse (`INTERN_NURSE`) | professional | 1 | Mandatory internship; supervised; labeled Intern | CNIC; Degree; Internship letter; Supervisor approval |
| 8 | CNA - Certified Nursing Assistant (`CNA`) | professional | 1 | Basic care only: hygiene, feeding, mobility, vitals. No clinical procedures | CNIC; CNA certificate; Character certificate |
| 9 | CMW - Community Midwife (`CMW`) | professional | 1 | Antenatal/postnatal, normal delivery support, newborn care, family planning | CNIC; Government CMW certificate; Registration; Affiliation |
| 10 | Lady Health Visitor (LHV) (`LHV`) | professional | 1 | Mother and child health, vaccinations, growth monitoring | CNIC; Government LHV certificate; Registration; Affiliation |
| 11 | MLT - Medical Lab Technologist (`MLT`) | professional | 1 | Home sample collection; results uploaded to Health Passport | CNIC; MLT degree/diploma; Lab affiliation |
| 12 | Physiotherapist (`PHYSIOTHERAPIST`) | professional | 1 | Home physiotherapy | CNIC; DPT degree; Registration; Affiliation |
| 13 | Occupational Therapist (`OCCUPATIONAL_THERAPIST`) | professional | 1 | Daily-task recovery, adaptive equipment training | CNIC; Degree; Registration; Affiliation |
| 14 | General Physician (GP) (`GP`) | professional | 1 | Home visits for general complaints and prescriptions | CNIC; MBBS; PMDC registration; Hospital/clinic affiliation |
| 15 | Specialist Doctor (`SPECIALIST`) | professional | 1 | Online video/audio consultations only | CNIC; MBBS + specialty certificate; PMDC registration; Hospital affiliation |
| 16 | Speech Therapist (`SPEECH_THERAPIST`) | professional | 2 | Stroke/surgery recovery, speech and swallowing | CNIC; Degree; Registration; Affiliation |
| 17 | Respiratory Therapist (`RESPIRATORY_THERAPIST`) | professional | 3 | Oxygen, ventilator support, nebulizer | CNIC; Degree; Registration; Affiliation |
| 18 | Psychologist / Mental Health Counselor (`PSYCHOLOGIST`) | professional | 2 | Online or home therapy sessions | CNIC; Degree; Registration; Affiliation |
| 19 | Nutritionist / Dietitian (`NUTRITIONIST`) | professional | 3 | Diet plans for diabetes, weight, post-surgery, pregnancy | CNIC; Degree; Registration |
| 20 | Palliative / Hospice Care Nurse (`PALLIATIVE_NURSE`) | professional | 3 | Comfort care for terminally ill patients | Same as RN + palliative training certificate |
| 21 | Vaccination Specialist (`VACCINATION_SPECIALIST`) | professional | 3 | Home vaccination, cold-chain handling | CNIC; Certificate; Cold-chain training; Affiliation |
| 22 | Home Health Aide / Caregiver (non-medical) (`HOME_HEALTH_AIDE`) | professional | 2 | Companionship, daily activity help, mobility. No medical certificate | CNIC; Character certificate; Two references |
| 23 | Ambulance / Emergency Driver (`AMBULANCE_DRIVER`) | professional | 3 | Optional in-house emergency transport (alternative to Rescue 1122 / Edhi) | CNIC; Driving licence; Vehicle documents; Ambulance fitness certificate |
| 24 | Lab Partner (`LAB_PARTNER`) | partner | 3 | Receives orders, sends technician, uploads results | Lab licence; Business registration; Contact person CNIC |
| 25 | Pharmacy Partner (`PHARMACY_PARTNER`) | partner | 3 | Receives and delivers medicine orders | DRAP licence; Business registration; Contact person CNIC |
| 26 | Admin (`ADMIN`) | internal | 1 | Full access: verification, disputes, monitoring, SOS | 2FA mandatory |
| 27 | Verification Officer (`VERIFICATION_OFFICER`) | internal | 3 | Document verification only; no settings or disputes | 2FA mandatory |
| 28 | Field Quality Supervisor (`FIELD_SUPERVISOR`) | internal | 3 | Random visit checks, service quality, on-ground disputes | 2FA mandatory |
| 29 | Customer Support Agent (`SUPPORT_AGENT`) | internal | 3 | In-app chat/call support; no verification access | 2FA mandatory |

Phase rollout: Phase 1 ships roles 1-15 and Admin. Phase 2 adds Speech Therapist, Psychologist, Home Health Aide. Phase 3 adds the rest, including partners and internal sub-roles.

Implementation note: `professional_type` and `user_role` enums in `schema.sql` already contain these codes. Gate each role behind a feature flag `roles.<code>.enabled` so rollout is a config change.
