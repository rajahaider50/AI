# Roles — Minimalist MVP

Only these role types are enabled in the MVP.

| Role | Interface | Permissions and responsibilities |
|---|---|---|
| Patient | Patient Android app | Browse verified Doctors/Nurses; create and view own bookings; manage own Health Passport PIN/authorization; trigger SOS; view own SOS status. |
| Doctor | Professional Android app | Submit credentials; see own verification status; once approved, receive/accept/decline bookings; complete services; access patient Health Passport only with valid patient authorization. |
| Nurse | Professional Android app | Same shared workflow as Doctor, with nurse-specific profile/service fields and required documents. |
| Admin | Admin web panel | Verify professionals; monitor booking metadata; view/acknowledge/update SOS alerts; maintain administrative audit records. No default access to clinical records. |

## Out of scope
The original 29-role catalog is retained only as roadmap/reference material. Do not expose those roles in MVP onboarding, menus, data seeders, permission matrices, or demo copy.

## Professional verification
A professional must be Approved before accepting a live booking. For a prototype, seeded verified professionals may be used; make the seeded/mock nature clear. Required documents and professional licensing rules need validation against applicable local regulations before production launch.
