# Demo script (5 minutes)

1. Splash with official logo. Sign in as Ali (patient).
2. Home: All-in-One Booking grid (doctor, nurse, medicine, lab). Book "Nurse home visit" with Sara Khan; pay with sandbox.
3. Switch to Sara's app: accept the request, mark On the way.
4. Patient opens Health Passport: enter PIN 1234, grant access for this booking. Sara opens the passport; patient shows the access log entry.
5. Patient presses and holds SOS. Admin dashboard (second window) flashes the red alert with name, phone, emergency contact and location. Admin acknowledges, then resolves.
6. Admin: verification queue, approve Hina Tariq.
7. Close with the website waitlist page in English and Urdu.

Talking points: native Android, one design system across three surfaces, audit trail, honest emergency behavior, phased roles.
