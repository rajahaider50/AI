# Minimalist MVP Demo Script (90–120 seconds)

## Demo setup
- Use synthetic patient, Doctor/Nurse, and Admin accounts.
- Start the API/mock API and all three interfaces.
- Use two browser/app windows where needed.
- Do not show real patient data or claim production integrations.
- Confirm that the seeded professional is approved, or demonstrate the Admin approval step first.

## Run of show
1. **0–10 sec — Patient home:** Show a clean dashboard with Doctor, Nurse, Health Passport, and SOS.
2. **10–30 sec — Book care:** Browse verified professionals, open a profile, choose service date/time/address, and confirm.
3. **30–45 sec — Professional:** Switch to the Professional app; show the same booking, accept it, then mark service complete (or show the active status if completion takes too long).
4. **45–60 sec — Privacy:** Open Health Passport, enter the demo PIN, grant access for the relevant booking, and show the authorization/access state.
5. **60–80 sec — SOS:** Patient triggers SOS. Switch to Admin; show the actual generated alert, open details, acknowledge it, and update status.
6. **80–100 sec — Verification:** Show the Admin verification queue and approve or request changes for a demo professional if this is not already shown.
7. **100–120 sec — Close:** Recap: Convenience, Privacy, Safety.

## Claims to avoid
- Do not claim a real ambulance is dispatched.
- Do not claim offline SOS/SMS works unless implemented and tested on a physical device.
- Do not claim real payment processing.
- Do not claim production-grade medical record security based solely on a demo PIN screen.
- Do not claim credential verification is automated if Admin is reviewing seeded/demo documents.

## One-sentence pitch
“HomiGo Care connects patients with verified doctors and nurses for home healthcare, while keeping medical-record access patient-controlled and making SOS alerts visible to the platform’s Admin team.”
