# Architecture

```
 Patient App (Android)   Professional App (Android)   Admin Web (React)   Website (Next.js)
          \                    |                          |                   |
           +-------- HTTPS /v1 REST + JWT  -------------+                   (public: waitlist, content)
                               |
                  API (Node 22, Express, Zod)  <---- Socket.io / SSE realtime ----> clients
                               |
        +----------+-----------+-------------+---------------+
   PostgreSQL 16   Object store (S3,    Provider interfaces:   Push (FCM)
   (Prisma)        private + presigned)  Payments, OTP/SMS, Maps
```

## Repo layout (monorepo, pnpm workspaces)
```
apps/android/            Gradle multi-module
  app-patient/  app-pro/  core-designsystem/  core-network/  core-data/  core-ui/  feature-*/
apps/admin-web/          React + Vite
apps/website/            Next.js 15
services/api/            Express + Prisma
packages/design-tokens/  tokens.json, tokens.css, tailwind preset (copied from 04_DESIGN_SYSTEM)
packages/api-types/      generated from openapi.yaml
```

## Layers (backend)
routes -> controller (Zod validation) -> service (business rules, state machines) -> repository (Prisma). Providers (payments, OTP, push, storage) are interfaces with a sandbox implementation first.

## Layers (Android)
UI (Compose screens, stateless) -> ViewModel (StateFlow, UiState sealed class: Loading/Content/Empty/Error) -> Repository -> (Retrofit API | Room cache). Hilt for DI. Every screen implements all four states.

## Realtime
Events (see `x-realtime` in openapi.yaml): `booking.created`, `booking.updated`, `sos.created`, `sos.updated`, `professional.verification`, `notification.created`. Socket.io in production; the mock uses SSE at `/v1/rt/stream?token=`. Clients must reconnect with backoff and refetch on reconnect.

## Environments
| Env | Purpose | Notes |
|---|---|---|
| local | dev | docker compose: postgres + api; mock-api optional |
| staging | QA, demo | OTP_DEV_BYPASS may stay on; sandbox payments |
| production | live | bypass OFF, Admin behind VPN/IP allowlist + 2FA, backups, TLS |

## Environment variables (services/api/.env.example)
`DATABASE_URL, JWT_ACCESS_SECRET, JWT_REFRESH_SECRET, FIELD_ENC_KEY (32 bytes base64), S3_BUCKET, S3_REGION, S3_ACCESS_KEY, S3_SECRET, FCM_SERVICE_ACCOUNT_JSON, OTP_PROVIDER, OTP_DEV_BYPASS, PAYMENT_PROVIDER, CORS_ORIGINS, ADMIN_ALLOWED_IPS`

## Performance targets
API p95 < 400 ms for list endpoints; app cold start < 2.5 s on a mid-range device; SOS create round trip < 2 s on 4G.
