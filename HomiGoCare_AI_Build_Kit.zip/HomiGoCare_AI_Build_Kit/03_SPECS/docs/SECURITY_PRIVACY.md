# Security and privacy (checklist the AI must satisfy)

## Auth
- Phone + OTP verification at signup. Password hashed with bcrypt cost >= 12.
- JWT access token 15 min; refresh token rotating, stored hashed, revoked on reuse (reuse = revoke whole family).
- Admin: email + password + 2FA (TOTP in production). Admin app only reachable through VPN / IP allowlist.
- Rate limits: login 5/min/IP+account, OTP send 3/10 min/phone, PIN verify 5 tries then 15 min lock.

## Data
- TLS everywhere. HSTS on web.
- Field-level AES-256-GCM encryption for CNIC and medical fields (allergies, conditions, medications, notes). Keys from env/KMS, never in code.
- Documents in a private bucket; access only through short-lived presigned URLs (5 min). Never public URLs.
- Android: tokens in EncryptedSharedPreferences/Keystore. `FLAG_SECURE` on Health Passport and document screens. Disable backup of sensitive data. Certificate pinning optional in production.

## Access control
- Role checks on every route (patient/professional/admin sub-roles). Object-level checks: a patient reads only their own bookings; a professional reads only assigned bookings and only granted passports.
- Admin cannot read medical records. Admin may read verification documents. All admin actions are written to `audit_logs` (append-only).

## Logging
Never log: PIN, OTP, password, tokens, CNIC, medical fields, document URLs. Use request ids. Redact by default.

## Input
Zod validation on every body/query. Upload limits: 10 MB, types jpeg/png/pdf/m4a/opus, content sniffing, virus scan hook.

## Compliance notes (owner must confirm with counsel)
Pakistan Personal Data Protection Bill direction, PMDC / PNC verification, DRAP for pharmacies. Provide data export and account deletion (DELETION_PENDING with 30 days grace).

## OWASP mobile/web checks to run in Phase 11
Broken access control, IDOR on bookings/documents/passport, auth bypass, injection, insecure storage, exported components, WebView misuse, dependency vulnerabilities.
