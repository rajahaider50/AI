# Deferred Features — Not MVP Build Requirements

These remain possible roadmap items but must not be implemented during the minimalist MVP unless the owner explicitly reopens scope.

- Additional 27 roles in the original 29-role ecosystem.
- Family account manager and multiple patient profiles.
- Medicine orders, pharmacy partner, prescription upload/order tracking.
- Lab tests, lab partners, sample collection.
- Wallet, real payment gateways, professional commissions, payouts, refunds.
- Referrals, coupons, loyalty and rewards.
- Complex professional assessment/exam engine and cooldown rules.
- Professional earnings, reviews, messaging/chat, advanced booking history.
- Live GPS tracking/route history beyond an explicitly tested location field for SOS.
- Guaranteed offline SOS, SMS fallback, carrier relay, background GPS.
- Ambulance dispatch and emergency-services integration.
- Dispute management, broadcast messages, CSV export, audit explorer, advanced analytics.
- Public marketing website, waitlist, SEO pages.
- Production clinical records, diagnosis/treatment recommendation, external medical integrations.

Retained legacy specs may mention these features. That does not make them part of the MVP.
