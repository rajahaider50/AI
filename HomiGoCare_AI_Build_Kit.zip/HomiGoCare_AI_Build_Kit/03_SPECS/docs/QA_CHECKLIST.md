# QA checklist (Phase 11 and before every demo)

## Functional
- [ ] Signup, OTP, login, logout, refresh rotation
- [ ] Professional: submit documents, see verification status, admin approves, appears in search
- [ ] Booking: all four types (doctor appointment, nurse home visit, medicine order, lab test) -> pay (sandbox) -> accept -> track -> complete -> rate
- [ ] Duplicate accept returns 409; duplicate create with same Idempotency-Key returns same booking
- [ ] Health Passport: PIN set, lock after 5 wrong tries, grant to booking, professional reads, access log shows read, passport expires
- [ ] SOS: create, location updates, admin sees red alert, acknowledge/resolve, false alarm
- [ ] Notifications arrive; deep links open the right screen

## Visual
- [ ] Every screen uses tokens only; same colors on Android, admin, website
- [ ] Official logo appears on splash, login, app bar/sidebar, website header, favicon, launcher icon
- [ ] No emoji anywhere (run: grep for emoji ranges in src and strings)
- [ ] 320/360/411 widths, font scale 1.3, RTL Urdu
- [ ] Loading, empty, error and offline states exist on every list screen

## Security
- [ ] Items in SECURITY_PRIVACY.md all pass; IDOR tests for booking, document, passport
- [ ] No secrets in repo; `.env.example` complete
- [ ] Dependency audit has no critical issues

## Performance and release
- [ ] Cold start under 2.5 s; no ANR; R8 enabled, signed AAB builds
- [ ] Crash reporting configured; backups configured; staging smoke test passes
