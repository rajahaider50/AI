# State machines (enforce in the service layer; reject illegal transitions with 409)

## Booking
```
PENDING -> ACCEPTED -> ON_THE_WAY -> ARRIVED -> IN_PROGRESS -> COMPLETED
PENDING -> DECLINED | EXPIRED | CANCELLED
ACCEPTED/ON_THE_WAY -> CANCELLED (fee rules apply)
```
- Only the assigned professional may move ACCEPTED->...->COMPLETED. Only the patient or admin may CANCEL.
- Accept is atomic: first professional wins; second gets 409 `ALREADY_TAKEN`.
- INSTANT bookings expire after 5 minutes without acceptance -> EXPIRED and patient is notified.
- Create and payment endpoints require an `Idempotency-Key` header.
- Completion triggers: payment capture (SANDBOX), commission row (15%), rating prompt, receipt.

## Professional verification
```
DRAFT -> SUBMITTED -> UNDER_REVIEW -> APPROVED
                                   -> REJECTED (reason required)
                                   -> ACTION_REQUIRED (list of docs to fix) -> SUBMITTED
APPROVED -> SUSPENDED (admin, reason required) -> UNDER_REVIEW
```
Only APPROVED professionals appear in search and can go online. Every decision writes `audit_logs`.

## Assessment
3 phases in order. Phase 1: 30 questions, pass 70%. Phase 2: 20 questions, pass 75%. Phase 3: 20 questions, pass 80%. Max 3 attempts per phase; after the 3rd failure, 7-day cooldown. Passing all three is required before submission can move to UNDER_REVIEW.

## SOS
```
ACTIVE -> ACKNOWLEDGED -> RESPONDING -> RESOLVED
ACTIVE/ACKNOWLEDGED/RESPONDING -> ESCALATED -> RESOLVED
ACTIVE/ACKNOWLEDGED -> FALSE_ALARM
```
Each transition appends to the SOS timeline with actor and time.

## Health Passport access
`NONE -> GRANTED(booking, expires at booking end + 2h) -> EXPIRED | REVOKED`. A professional may read only while GRANTED. Each read appends to `access_logs` (append-only; DB trigger blocks update/delete).

## Payment
`INITIATED -> SUCCESS | FAILED`, `SUCCESS -> REFUNDED`. Never mark SUCCESS from the client; only from the provider callback or the sandbox confirm endpoint.
