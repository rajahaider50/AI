# Decisions (already made; do not re-open)

| # | Topic | Decision | Why |
|---|---|---|---|
| D1 | Mobile tech | **Native Android (Kotlin + Compose)**. Not React Native. | Owner asked for original native apps. Better GPS, background SMS fallback, performance. |
| D2 | Number of apps | Two apps (Patient, Professional) sharing core modules | Different audiences, store listings and permissions |
| D3 | Backend | Node 22 + TypeScript + Express + Prisma + PostgreSQL 16 | One language across API, admin, website |
| D4 | Admin | Separate React web app, never public | Security; ops use |
| D5 | Screen IDs | 76 canonical IDs: P-01..P-33, PR-01..PR-24, A-01..A-13 (+ A-01A, A-03A, A-04A, A-05A, A-06A, A-07A) | Merges the Developer Guide, interactive master (67) and flow charts (9 extended) |
| D6 | Phases | 1 = MVP, 2 = core, 3 = full. `showcase` flag marks the hackathon set | Ships value early |
| D7 | Roles | 29 roles; Phase 1 = roles 1-15 + Admin; Phase 2 = Speech Therapist, Psychologist, Home Health Aide; Phase 3 = rest | Matches Roles Update doc |
| D8 | Payments | Provider interface; `SANDBOX` first; JazzCash/Easypaisa later. 15% professional commission | No live merchant credentials yet |
| D9 | OTP | Provider interface; dev code 123456 when `OTP_DEV_BYPASS=true` | Testing without SMS cost |
| D10 | SOS | Honest SOS: real alert + real device location to Admin. No fake dispatch. Offline = SMS fallback where the device allows | Safety and trust |
| D11 | Hackathon | A "showcase" track inside Phase 1 delivers PIN lock, All-in-One Booking UI, SOS alert in 5 hours using the mock API | Matches hackathon rules |
| D12 | Logo | Official raster art supplied by owner; all launcher, store, web and OG assets derived from it | Brand consistency |
| D13 | Logo vs UI color | Logo turquoise differs from UI teal `#1B6B63`. UI uses brand tokens; logo accents (`#28B8C0 #0C6A80 #F87848 #F5B82E`) only in logo/illustration | Contrast + consistency |
| D14 | Icons | Original 107-icon set, 24 grid, 1.75 stroke, round caps. No emoji | Professional look |
| D15 | Languages | EN + UR, RTL aware | Audience |
| D16 | Admin sees medical records? | No. Admin sees booking metadata and verification documents only | Privacy |
| D17 | Assessment | 3 phases (70/75/80% pass; 30/20/20 questions), 3 attempts, 7-day cooldown. Questions are SAMPLES | Per Developer Guide |
| D18 | Health Passport | Patient grants access per booking; PIN 4 digits, lockout after 5 wrong tries for 15 min; every read logged immutably | Privacy |

## ID crosswalk
- Developer Guide v1.0/1.1 numbering `P-01..` and `PR-..`, `A-..` is preserved.
- Interactive Spider-Web master (67 screens) maps 1:1 to the same IDs.
- Screens flagged `status: EXTENDED` in `screens.json` come from the flow-chart images and were not in the original guide; they are small additions (for example sub-screens A-03A, A-04A).
- If two sources disagree on a label, `screens.json` wins.

## Hackathon vs phase flags
Three showcase screens carry later phase numbers in the source guide (P-16 and P-24 Health Passport = phase 2, P-25 SOS = phase 3). For the 5-hour hackathon they are pulled forward (`showcase: true`). In the full build, implement them in Phase 07 (`07_HEALTH_PASSPORT_SOS`) regardless of the number. Key IDs: dashboard A-02, SOS monitor A-06, alert detail A-06A, verification A-03/A-03A.
