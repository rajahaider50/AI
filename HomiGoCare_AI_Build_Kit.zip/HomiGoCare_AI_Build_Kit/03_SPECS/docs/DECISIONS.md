# MVP Decisions — authoritative

| # | Topic | MVP decision |
|---|---|---|
| D1 | Product scope | Three panels only: Patient, shared Professional, Admin. |
| D2 | Professional types | Doctor and Nurse only. One shared Professional app. |
| D3 | Mobile tech | Preserve native Android Kotlin + Compose if this is the existing project. Do not migrate stacks without an explicit blocker. |
| D4 | Admin | Separate protected web panel. |
| D5 | Screens | Use the MVP screen groups in `MVP_SCOPE.md`; preserve canonical IDs where possible. |
| D6 | Roles | Patient, Doctor, Nurse, Admin. The 29-role ecosystem is roadmap/reference only. |
| D7 | Booking | Doctor appointment or Nurse home visit; no medicine/lab ordering. |
| D8 | Payments | No real payment integration in MVP. If a sandbox placeholder remains, label it as simulated and do not block booking on it. |
| D9 | OTP | Development bypass allowed only when explicitly enabled in local environment; never production. |
| D10 | SOS | Patient action creates an alert visible in Admin; no fake ambulance dispatch or guaranteed SMS/offline capability. |
| D11 | MVP differentiators | Booking, Health Passport PIN/authorization, SOS-to-Admin. |
| D12 | Branding | Use supplied official logo and design tokens. |
| D13 | Colors | UI primary teal `#1B6B63`; red reserved for emergency; orange as restrained accent. |
| D14 | Icons | Use supplied icon set; no emoji icons. |
| D15 | Languages | English for MVP; retain RTL-compatible layout foundations if already present. Urdu content can be deferred unless required by demo. |
| D16 | Admin privacy | Admin sees professional verification documents, booking metadata, and SOS operational data; not unrestricted patient records. |
| D17 | Assessment | Advanced multi-phase assessment engine is deferred. |
| D18 | Health Passport | Four-digit PIN and explicit patient authorization; enforce access on backend and log access where implemented. |
| D19 | Website | Public website and waitlist are deferred. |
| D20 | Extended features | Family accounts, wallet, referral, payments/commission, chat, reviews, lab/pharmacy integrations, advanced analytics are deferred. |

## Conflict rule
If legacy prompts, screens, roles, API operations, or phase files conflict with this document or `MVP_SCOPE.md`, follow the MVP scope. Do not silently restore deferred features.
