# SOS Specification — MVP

## Goal
Let a patient trigger an SOS alert and let the Admin panel receive, acknowledge, and update it.

## MVP flow
1. Patient opens SOS and sees a clear confirmation/cancel affordance to reduce accidental triggers.
2. Patient confirms SOS.
3. Client sends an authenticated SOS request to the backend.
4. Backend stores an alert with patient identifier, timestamp, status, and location/contact fields only if available and permissioned.
5. Admin dashboard shows a prominent active alert.
6. Admin opens alert details, acknowledges it, and changes status to `ACKNOWLEDGED` or `RESOLVED`, with an optional response note.
7. Patient sees the alert-submitted status where available.

## Minimum alert fields
`id`, `patientId`, `createdAt`, `status`, `location` (nullable), `emergencyContact` (only if configured), `acknowledgedAt` (nullable), `resolvedAt` (nullable), `adminNote` (optional).

## State machine
`CREATED -> ACKNOWLEDGED -> RESOLVED`
Optional `CANCELLED` only if cancellation semantics are implemented and audited.

## UI rules
- Red is reserved for emergency emphasis.
- Show the alert status honestly.
- Do not show fake ETA, ambulance assignment, dispatch ID, or responder tracking.
- Do not imply that an alert is monitored 24/7 unless the service actually is.
- If location permission is denied/unavailable, send the alert without coordinates and say location was unavailable.
- The Admin only sees information needed to respond operationally.

## Explicitly deferred
- Guaranteed offline operation.
- SMS fallback, carrier relay, background GPS streaming.
- Ambulance dispatch or integration with emergency services.
- Automatic call center escalation.
These require separate implementation and device/integration testing.
