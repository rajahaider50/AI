# SOS Emergency specification

Goal: a patient can raise an emergency alert in two taps; the Admin dashboard shows a prominent red alert instantly with the patient's name, phone, emergency contact and last known location.

## Patient flow (P-25 Emergency Screen / SOS; the active state is shown on the same screen)
1. Large red SOS button (always reachable from Home). Press and hold 1.5 s OR tap then confirm (avoid accidents). Haptic feedback.
2. App captures: current location if permission granted (lat, lng, accuracy, timestamp), battery %, network type. If no GPS fix within 5 s, send with last known location and mark it "last known".
3. `POST /v1/sos` with `Idempotency-Key`. Server stores, notifies Admin (realtime + push), and notifies the patient's emergency contact by SMS (provider interface).
4. The active state of P-25 shows: "Alert sent", elapsed time, what is known ("Help team notified at 14:32"), a call button for 1122 (dialer intent), cancel as "false alarm" with confirmation. Location keeps updating through `POST /v1/sos/{id}/location` every 15 s.

## Honesty rules
- Never claim an ambulance is on the way unless an admin set status RESPONDING.
- Never show fake ETAs, fake responder names or fake maps pins.
- If the alert could not be sent, say so and show the fallback (call 1122, SMS).

## Offline fallback (best effort)
If there is no data connection, the Patient app prepares an SMS with a short text and a maps link to the emergency contact and to the SOS relay number (`SOS_RELAY_NUMBER`). The user confirms sending (Android does not allow silent SMS without permission; request `SEND_SMS` only if the product owner accepts the Play Store policy review, otherwise open the SMS composer). The relay posts a `SMS_RELAY` SOS to the API. This depends on device and carrier; document it as best effort.

## Admin (A-06 SOS Monitoring, A-06A alert detail, dashboard A-02)
- Prominent red banner on the dashboard with sound (user-gesture permitted) and a pulsing dot. Respect `prefers-reduced-motion` (no pulse, keep color and text).
- List sorted newest first, with status chips; detail shows map, timeline, patient contact, emergency contact and actions: Acknowledge, Responding, Escalate, Resolve, Mark false alarm. Each action writes the timeline and audit log.
- Realtime events: `sos.created`, `sos.updated`.

## Acceptance tests
1. Create SOS from the mock API as the patient; the admin SSE stream receives `sos.created` within 1 s.
2. Retry with the same Idempotency-Key creates one alert only.
3. Airplane mode shows the offline fallback screen with call and SMS actions.
4. Admin sees no medical records in the SOS detail.
