# Design system rules

## Logo (OFFICIAL, supplied by the owner)
Folder `04_DESIGN_SYSTEM/logo_assets/` (transparent PNGs):
| File | Use |
|---|---|
| `homigo_mark.png` | In-app header marks, empty states, loading |
| `homigo_lockup_horizontal(.png/_white.png)` | App bars on wide screens, website header, admin sidebar. `_white` on teal/dark backgrounds |
| `homigo_lockup_stacked(.png/_white.png)` | Splash, login, onboarding, PDF cover |
| `homigo_wordmark*.png`, `homigo_tagline*.png` | Only when composing custom lockups |
| `homigo_mark_on_white_tile.png` | Places that need an opaque square |
| `android/mipmap-*/ic_launcher*.png`, `mipmap-anydpi-v26/*.xml` | Copy into `app-patient/src/main/res` and `app-pro/src/main/res` |
| `play_store_icon_512.png`, `play_feature_graphic_1024x500.png` | Play Console |
| `web/favicon-*.png`, `favicon.ico`, `og_image_1200x630.png` | Website and admin `<head>` |

Rules: never recolor, redraw, stretch, rotate, add shadows or outlines. Keep clear space equal to 25% of the mark height. Minimum mark size 32 dp; below that use the favicon file. The mark must not sit on busy imagery; use the white tile or a plain surface. Splash: stacked lockup on white (or `_white` on teal gradient).

Why raster: the owner supplied raster 3D art. Use density-specific files; do not upscale. A vector master is recommended for the future.

## Color tokens (same on Android, admin, website)
| Token | Hex | Use |
|---|---|---|
| primary | #1B6B63 | Buttons, links, active nav |
| primaryDark | #0D4A44 | App bars, pressed |
| accent (orange) | #F5823A | Highlights, badges, illustration. NOT for text, NOT behind white text |
| background | #F5F5F5 | Screens |
| surface | #FFFFFF | Cards |
| text | #333333 | Primary text |
| textSecondary | #888888 (decorative) / #666666 (AA, use for small text) | |
| error / SOS | #E53935 | Errors, SOS |
| success | #43A047 | Success |
Scales (teal 50-800, orange 50-700) are in `tokens.json`. Logo accents `#28B8C0 #0C6A80 #F87848 #F5B82E` are for logo/illustration only.

Contrast facts (`contrast.json`): white on orange 2.58 (FAIL), #888 on white 3.54 (FAIL for small), white on red 4.23 (OK for bold 16+), white on teal passes AA.

## Shape and spacing
Buttons and inputs radius 25, cards 15, chips 20, sheets 24 (top). 4-pt grid: 4, 8, 12, 16, 24, 32. Screen gutter 16. Minimum touch target 48 dp.

## Type
Brand 28 bold, H1 22 bold, H2 18 semibold, body 14, small 12, button 16 bold. Latin: Inter (bundle files; fall back to system). Urdu: Noto Nastaliq Urdu (bundle files; the kit could not include font binaries, download from Google Fonts).

## Icons
107 original icons in `04_DESIGN_SYSTEM/icons/`: `svg/`, `android/drawable/hg_ic_*.xml` (VectorDrawable), `icons.json` (names, tags). Use via `HgIcon` composable (Android) or `<Icon name="..."/>` wrapper (web). Tint with tokens. **Emoji are forbidden everywhere.**

## Illustrations
Six SVGs in `04_DESIGN_SYSTEM/illustrations/`: onboarding_1_home_care, onboarding_2_verified, onboarding_3_safety, empty_state, under_review, certification. Use them on the matching screens only.

## Status badges
PENDING amber, ACCEPTED/ON_THE_WAY teal, ARRIVED/IN_PROGRESS dark teal, COMPLETED green, CANCELLED/DECLINED/EXPIRED gray, REJECTED/SOS red. Always pair color with a text label.

## Motion
150-250 ms ease-out. SOS pulse 1.2 s loop, disabled under reduced motion. Skeleton loaders for lists.

## Quality bar (no visual breakage)
Test at 320 dp, 360 dp, 411 dp widths, font scale 1.3, dark mode off (light only in v1), Urdu RTL. No text clipping, no overlapping, no raw hex in screens, no mixed icon styles, no placeholder lorem ipsum.
