# Design System — MVP application

Use the existing `04_DESIGN_SYSTEM/` files as the source of truth for tokens, logo, icons, and illustrations.

## Minimalist rules
- Teal primary actions; white/light neutral surfaces; red only for SOS/emergency; restrained orange accent.
- One primary action per screen.
- Use concise labels and only fields needed for the current task.
- Reuse typography, spacing, rounded corners, input styles, and icon strokes from the supplied system.
- Use supplied logo assets, not a redrawn or AI-generated substitute.
- No emoji as icons.
- Avoid excessive cards, gradients, decorative charts, and repeated information.
- Show loading, empty, error, success, disabled, and permission-denied states.
- Support small Android screens, touch targets, and contrast.
