# Professional Android App — Screen Specification

Canonical IDs. Phase: **1** = MVP, **2** = core, **3** = full. `SHOWCASE` = included in the 5-hour hackathon build.

| ID | Screen | Phase | Showcase | Next |
|---|---|---|---|---|
| PR-01 | Professional Splash | 1 |  | PR-02 |
| PR-02 | Professional Login / Role Entry | 1 |  | PR-08, PR-03 |
| PR-03 | Role & Registration | 1 |  | PR-04 |
| PR-04 | Personal & Professional Details | 1 |  | PR-05 |
| PR-05 | Credential & Document Upload | 1 |  | PR-06 |
| PR-06 | Verification Review / Submission | 1 |  | PR-07 |
| PR-07 | Verification Pending / Status | 1 |  | PR-09, PR-08 |
| PR-08 | Professional Dashboard | 1 | yes | PR-11, PR-17, PR-18, PR-19, PR-10, PR-20 |
| PR-09 | Certification / Assessment | 1 |  | PR-08 |
| PR-10 | Professional Profile Management | 2 |  | PR-08 |
| PR-11 | Incoming Booking Requests | 1 |  | PR-12 |
| PR-12 | Booking Request Details | 1 | yes | PR-13, PR-11 |
| PR-13 | Booking Accepted / Upcoming | 1 | yes | PR-14 |
| PR-14 | Active Visit / Consultation | 2 |  | PR-15, PR-16 |
| PR-15 | Authorized Patient Health Passport | 2 |  | PR-16 |
| PR-16 | Complete Service / Visit | 2 |  | PR-17 |
| PR-17 | Professional Booking History | 2 |  | PR-08, PR-11 |
| PR-18 | Professional Notifications | 2 |  | PR-08, PR-12 |
| PR-19 | Availability & Service Settings | 2 |  | PR-08 |
| PR-20 | Professional Settings & Account | 3 |  | PR-08, PR-01 |
| PR-21 | Earnings & Wallet | 2 |  | PR-08 |
| PR-22 | Ratings & Reviews | 2 |  | PR-08 |
| PR-23 | Messages | 3 |  | PR-08 |
| PR-24 | Help & Support | 3 |  | PR-20 |

## PR-01 — Professional Splash

**Phase 1** · SOURCE_DERIVED

**Purpose:** Professional entry

**Specification**

```text
Section: Entry

 What the professional sees:

   • Professional HomiGo Care branding, logo, tagline, short loading state.

 Actions / buttons:

   • Automatic routing after loading.

   • Existing approved professional → PR-08 Dashboard.

   • New/logged-out professional → PR-02 Login/Registration.

 Functional purpose: Entry point for the professional application.
```

**Next screens:** PR-02
**Actions:** Start
**Design-system components:** Splash gradient, Logo, Subtitle "Professional Portal"
**States / rules:** 2s

## PR-02 — Professional Login / Role Entry

**Phase 1** · SOURCE_DERIVED

**Purpose:** Authenticate and choose professional path

**Specification**

```text
Section: Authentication

 What the professional sees:

   • Phone/email field, password field, Login button, Forgot Password, Sign Up, role indicator for Doctor/Nurse.

 Actions / buttons:

   • Login → PR-08 if approved.

   • Sign Up → PR-03 Role Selection/Registration.

   • Forgot Password → recovery flow.

 Functional purpose: Only authenticated professional accounts proceed to the professional panel.
```

**Next screens:** PR-08, PR-03
**Actions:** Login; Register
**API:** POST /auth/login
**Design-system components:** HgPhoneField, HgPasswordField, RoleChip
**States / rules:** route: approved -> PR-08, else PR-07

## PR-03 — Role & Registration

**Phase 1** · SOURCE_DERIVED

**Purpose:** Doctor/nurse registration

**Specification**

```text
Section: Onboarding

 What the professional sees:

   • Role selection: Doctor or Nurse. Full name, phone, email, password, date of birth and basic professional information.

 Actions / buttons:

   • Continue → PR-04 Personal & Professional Details.

   • Back → PR-02.

 Functional purpose: Creates the professional account and establishes the professional type.
```

**Next screens:** PR-04
**Actions:** Continue
**API:** POST /auth/signup; POST /auth/verify-otp
**Design-system components:** RoleSelector(type), HgTextField
**States / rules:** type decides required docs

## PR-04 — Personal & Professional Details

**Phase 1** · SOURCE_DERIVED

**Purpose:** Professional profile details

**Specification**

```text
Section: Verification

 What the professional sees:

   • Profile photo, CNIC/identity information, address, professional registration number where applicable, specialization/service
     category, experience and languages.

 Actions / buttons:

   • Continue → PR-05 Document Upload.

   • Save and Continue → next verification step.

 Functional purpose: Collects information needed to create the professional profile and verify identity/qualification.
```

**Next screens:** PR-05
**Actions:** Continue
**API:** POST /professional/register
**Design-system components:** PhotoPicker, HgTextField, LanguageChips, HospitalField(required)
**States / rules:** current hospital mandatory

## PR-05 — Credential & Document Upload

**Phase 1** · SOURCE_DERIVED

**Purpose:** Upload degree/certification/identity documents

**Specification**

```text
Section: Verification

 What the professional sees:

   • Document upload cards for CNIC/identity, degree/certification, professional registration/license where applicable, and
     supporting documents.

 Actions / buttons:

   • Upload/Replace document.

   • Continue → PR-06 Verification Review.

   • Submit documents for verification.

 Functional purpose: Required documents are submitted for Admin verification.
```

**Next screens:** PR-06
**Actions:** Continue
**API:** POST /professional/documents/upload-url; POST /professional/documents
**Design-system components:** UploadBox(list by type), StepProgress
**States / rules:** save draft, per-file progress, jpg/pdf <=10MB

## PR-06 — Verification Review / Submission

**Phase 1** · SOURCE_DERIVED

**Purpose:** Review and submit credentials

**Specification**

```text
Section: Verification

 What the professional sees:

   • Checklist of submitted information and documents, document status indicators, declaration/consent and final Submit for
     Verification button.

 Actions / buttons:

   • Submit → PR-07 Verification Pending.

   • Edit → return to relevant information/document screen.

 Functional purpose: Professional cannot become active until required verification is approved.
```

**Next screens:** PR-07
**Actions:** Submit
**API:** POST /professional/submit-verification
**Design-system components:** ChecklistReview, ConsentCheckbox
**States / rules:** blocks until all required docs present

## PR-07 — Verification Pending / Status

**Phase 1** · SOURCE_DERIVED

**Purpose:** Show verification state

**Specification**

```text
Section: Verification

 What the professional sees:

   • Status card: Pending, Approved, Rejected, or Action Required. Submitted documents, review notes and next-step
     instructions.

 Actions / buttons:

   • If Action Required → edit/resubmit documents.

   • If Approved → PR-08 Dashboard or PR-09 Certification.

   • Refresh Status.

 Functional purpose: Shows the current Admin verification state.
```

**Next screens:** PR-09, PR-08
**Actions:** Assessment; Dashboard when approved
**API:** GET /professional/verification-status; WS verification.updated
**Design-system components:** StatusTimeline, ExpandableInfo, Illustration(under review)
**States / rules:** PENDING/APPROVED/REJECTED/ACTION_REQUIRED

## PR-08 — Professional Dashboard

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Main doctor/nurse control center

**Specification**

```text
Section: Main Panel

 What the professional sees:

   • Greeting and profile status, verification/activation badge, Online/Offline availability toggle, today's/upcoming bookings,
     incoming requests, quick actions, notifications.

 Actions / buttons:

   • Incoming Request → PR-11.

   • Upcoming Booking → PR-13.

   • Profile → PR-10.

   • Availability toggle → update status.

   • Notifications → PR-18.

 Functional purpose: Main professional control center.
```

**Next screens:** PR-11, PR-17, PR-18, PR-19, PR-10, PR-20
**Actions:** Bookings; History; Notifications; Availability; Profile; Settings
**API:** GET /professional/dashboard; PUT /professional/online; WS booking.offer
**Design-system components:** OnlineToggle, EarningsCard(gradient), IncomingBookingBanner, ActiveBookingCard, HgBottomNav(4)
**States / rules:** offline => no offers

## PR-09 — Certification / Assessment

**Phase 1** · SOURCE_DERIVED

**Purpose:** Professional assessment when required

**Specification**

```text
Section: Activation

 What the professional sees:

   • Certification or assessment introduction, instructions, assessment sections, progress, completion status and submission.

 Actions / buttons:

   • Start/Continue Assessment.

   • Submit Assessment → certification review/status.

   • Exit → save progress.

 Functional purpose: Used when certification/assessment is required before activation. The exact assessment content is not
 defined in the source material and should be specified separately if implemented.
```

**Next screens:** PR-08
**Actions:** Complete
**API:** GET /professional/assessment; POST .../start; PUT .../answer; POST .../submit; POST /professional/go-live
**Design-system components:** PhaseCard x3, McqQuestion, QuestionMap, Timer, ResultView, Illustration(trophy)
**States / rules:** phase gating, 3 attempts, 7-day cooldown, server timer

## PR-10 — Professional Profile Management

**Phase 2** · SOURCE_DERIVED

**Purpose:** Manage public professional profile

**Specification**

```text
Section: Profile

 What the professional sees:

   • Profile photo, name, role, specialization, experience, qualifications, hospital/clinic affiliation, languages, service types, bio,
     pricing and professional information.

 Actions / buttons:

   • Edit → update information.

   • Save → return to dashboard.

   • View public profile → patient-facing profile preview.

 Functional purpose: Controls the professional information visible to patients.
```

**Next screens:** PR-08
**Actions:** Save
**API:** GET/PUT /professional/profile
**Design-system components:** ProfilePreviewCard, ServiceChips, PriceInputs(min/max)

## PR-11 — Incoming Booking Requests

**Phase 1** · SOURCE_DERIVED

**Purpose:** View incoming patient requests

**Specification**

```text
Section: Bookings

 What the professional sees:

   • List of new patient requests with patient/service type, requested date/time, location, booking type, request status and
     relevant service information.

 Actions / buttons:

   • Tap request → PR-12.

   • Accept → PR-13/booking confirmation.

   • Decline → decline reason/status flow.

 Functional purpose: Primary booking-request screen.
```

**Next screens:** PR-12
**Actions:** Review
**API:** GET /bookings (offers); WS booking.offer
**Design-system components:** OfferCard, CountdownRing
**States / rules:** expiry -> next professional

## PR-12 — Booking Request Details

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Review booking details

**Specification**

```text
Section: Bookings

 What the professional sees:

   • Patient/request summary, requested service, date/time, location, special instructions, booking type, estimated duration,
     relevant patient information and applicable Health Passport access state.

 Actions / buttons:

   • Accept Booking → PR-13.

   • Decline → confirmation/reason flow.

   • Back → PR-11.

 Functional purpose: Professional reviews the request before accepting or declining.
```

**Next screens:** PR-13, PR-11
**Actions:** Accept; Decline
**API:** GET /bookings/{id}; POST /bookings/{id}/accept; POST /bookings/{id}/decline
**Design-system components:** PatientSummary, HealthPassportBasic(locked), EarningsBreakdown, HgButton x2
**States / rules:** accept race -> 409 message

## PR-13 — Booking Accepted / Upcoming

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Upcoming accepted service

**Specification**

```text
Section: Bookings

 What the professional sees:

   • Success/status banner, booking reference, patient/service details, date/time, location, contact actions, navigation/route
     option and Health Passport access status.

 Actions / buttons:

   • Start Visit/Consultation → PR-14.

   • Contact Patient → communication action.

   • View Health Passport → PR-15 after patient authorization/PIN.

 Functional purpose: Represents an accepted booking ready for service.
```

**Next screens:** PR-14
**Actions:** Start Visit
**API:** GET /bookings/{id}
**Design-system components:** BookingCard, MapLinkButton, CallButton

## PR-14 — Active Visit / Consultation

**Phase 2** · SOURCE_DERIVED

**Purpose:** Active consultation/home visit

**Specification**

```text
Section: Service

 What the professional sees:

   • Patient summary, service/visit status, visit timer, notes area, service checklist, supplies/services used where applicable and
     completion control.

 Actions / buttons:

   • View authorized Health Passport → PR-15.

   • Complete Service → PR-16.

   • Emergency/support action → relevant emergency workflow.

 Functional purpose: Professional manages the active service.
```

**Next screens:** PR-15, PR-16
**Actions:** Authorized Health Passport; Complete
**API:** PUT /bookings/{id}/status; POST /bookings/{id}/location; POST /bookings/{id}/supplies
**Design-system components:** VisitTimer, Checklist, RequestSuppliesButton, NotesField, SosButton
**States / rules:** complete only when checklist addressed

## PR-15 — Authorized Patient Health Passport

**Phase 2** · SOURCE_DERIVED

**Purpose:** Access patient passport only after authorization

**Specification**

```text
Section: Privacy

 What the professional sees:

   • Patient medical information made available only after patient authorization. Sections may include medical history,
     prescriptions, test reports, allergies/conditions, vitals and relevant documents. Access status is clearly shown.

 Actions / buttons:

   • View permitted records.

   • Return to visit → PR-14.

   • Do not expose information outside authorized scope.

 Functional purpose: Patient-controlled privacy is central. The source concept requires the patient to authorize access using
 a secret 4-digit PIN; the professional should not bypass that authorization.
```

**Next screens:** PR-16
**Actions:** Continue
**API:** GET /professional/patients/{id}/health-passport
**Design-system components:** AuthorizedBanner, ScopedSections
**States / rules:** 403 + DENIED log when no grant

## PR-16 — Complete Service / Visit

**Phase 2** · SOURCE_DERIVED

**Purpose:** Complete service and record completion

**Specification**

```text
Section: Service

 What the professional sees:

   • Completion summary, visit notes, services performed, supplies used if applicable, final status and completion confirmation.

 Actions / buttons:

   • Complete → PR-17 History/Completed Booking.

   • Add/update notes before completion.

   • Back → active visit if not completed.

 Functional purpose: Closes the service and records the outcome.
```

**Next screens:** PR-17
**Actions:** Complete
**API:** POST /professional/bookings/{id}/visit-notes; PUT /bookings/{id}/status
**Design-system components:** NotesEditor, PrescriptionForm, HgButton
**States / rules:** notes -> patient record

## PR-17 — Professional Booking History

**Phase 2** · SOURCE_DERIVED

**Purpose:** Previous services

**Specification**

```text
Section: Bookings

 What the professional sees:

   • Tabs or filters for Upcoming, Active, Completed and Cancelled. Booking cards with patient/service/date/status.

 Actions / buttons:

   • View booking → details.

   • Upcoming → PR-13.

   • Active → PR-14.
   • Completed → completion/history details.

 Functional purpose: Professional activity history.
```

**Next screens:** PR-08, PR-11
**Actions:** Dashboard; New Requests
**API:** GET /bookings
**Design-system components:** TabRow, BookingCard

## PR-18 — Professional Notifications

**Phase 2** · SOURCE_DERIVED

**Purpose:** Professional alerts

**Specification**

```text
Section: Support

 What the professional sees:

   • Notifications grouped by booking, verification, account, system and important alerts. Read/unread status.

 Actions / buttons:

   • Tap notification → relevant destination.

   • Mark all read.

 Functional purpose: Central professional notification center.
```

**Next screens:** PR-08, PR-12
**Actions:** Open
**API:** GET /notifications
**Design-system components:** NotificationRow

## PR-19 — Availability & Service Settings

**Phase 2** · SOURCE_DERIVED

**Purpose:** Set availability and service preferences

**Specification**

```text
Section: Settings

 What the professional sees:

   • Online/Offline availability, working days/hours, service areas, instant/scheduled booking preference and service categories.

 Actions / buttons:

   • Toggle availability.

   • Edit schedule/service area.

   • Save → PR-08.

 Functional purpose: Controls whether the professional can receive new requests.
```

**Next screens:** PR-08
**Actions:** Save
**API:** PUT /professional/availability
**Design-system components:** WeekdayRows, TimeRangePicker, BreakPicker

## PR-20 — Professional Settings & Account

**Phase 3** · SOURCE_DERIVED

**Purpose:** Manage account/security settings

**Specification**

```text
Section: Settings

 What the professional sees:

   • Account information, security/password, notification preferences, language, privacy, support, terms, logout and account
     status.

 Actions / buttons:

   • Edit settings.

   • Help & Support.

   • Logout → PR-02.

   • Account status/verification → PR-07.

 Functional purpose: Account and preference management.

 4. 5-Hour Hackathon MVP — Professional Panel
 The professional panel is secondary to the patient-facing hero demo, but it must support the complete booking loop. The
 following screens are the minimum practical professional-side scope:

   • PR-02 Login / Registration entry

   • PR-03 Role & Registration

   • PR-04 Personal & Professional Details

   • PR-05 Credential & Document Upload

   • PR-06 Verification Submission

   • PR-07 Verification Pending/Approved state (can be demo-controlled)

   • PR-08 Professional Dashboard

   • PR-11 Incoming Booking Requests

   • PR-12 Booking Request Details

   • PR-13 Accept Booking / Upcoming Booking

   • PR-14 Active Visit / Consultation (simplified)

   • PR-15 Authorized Patient Health Passport (PIN-controlled demo)

   • PR-16 Complete Service

 5. Professional MVP Demo Journey
   • Professional logs in → dashboard.

   • Professional sees a new booking request.

   • Professional opens the request and reviews service/patient details.

   • Professional accepts the booking.

   • Professional opens the upcoming booking and starts the service.

   • Patient authorizes Health Passport access using the required 4-digit PIN; the professional sees only authorized information.

   • Professional completes the service.

   • Booking moves into completed/history state.

 6. Scope Notes
   • The source material defines professional registration, document verification, certification/assessment, activation, dashboard
     and booking acceptance as the core professional flow.

   • The exact content of a professional certification assessment is not fully defined in the supplied material; this document
     therefore treats it as a screen/state rather than inventing an assessment curriculum.

   • Patient Health Passport access remains patient-controlled. The professional panel must not provide a bypass around the
     patient's authorization.

   • Advanced scheduling, payments, detailed analytics and other full-platform capabilities can be deferred if they are not
     required for the 5-hour hackathon demo.
```

**Next screens:** PR-08, PR-01
**Actions:** Save; Logout
**API:** PUT /me
**Design-system components:** SettingsSection, LanguageToggle, Logout

## PR-21 — Earnings & Wallet

**Phase 2** · SOURCE_DERIVED

**Purpose:** Earnings history, balance, withdraw to JazzCash/Easypaisa/bank (min PKR 500, 24 h)

**Specification**

```text
Layout: teal gradient balance card, weekly bar chart, month total, transactions, withdrawal history, rating summary.
```

**Next screens:** PR-08
**Actions:** Withdraw; View transaction
**API:** GET /professional/earnings; POST /wallet/withdraw
**Design-system components:** BalanceCard, BarChart(week), TransactionRow
**States / rules:** min PKR 500

## PR-22 — Ratings & Reviews

**Phase 2** · SOURCE_DERIVED

**Purpose:** Patient ratings, feedback, reputation

**Specification**

```text
Layout: average rating, category averages, review list (anonymous patients shown as Verified Patient).
```

**Next screens:** PR-08
**Actions:** View review
**API:** GET /professionals/{me}/reviews
**Design-system components:** RatingSummary, ReviewItem

## PR-23 — Messages

**Phase 3** · PROPOSED

**Purpose:** Patient chat, admin messages, support

**Specification**

```text
Layout: thread list + chat. Phase 3. Messages tied to a booking; no phone numbers exchanged off-platform.
```

**Next screens:** PR-08
**Actions:** Open thread; Send message
**Design-system components:** ThreadList, ChatView
**States / rules:** phase 3

## PR-24 — Help & Support

**Phase 3** · PROPOSED

**Purpose:** FAQs, contact admin, raise issue

**Specification**

```text
Layout: FAQ, contact admin, issue form.
```

**Next screens:** PR-20
**Actions:** Raise issue
**API:** POST /public/contact
**Design-system components:** FaqAccordion
