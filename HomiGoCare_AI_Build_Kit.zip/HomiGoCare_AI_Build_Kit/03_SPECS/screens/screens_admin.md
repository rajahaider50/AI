# Admin Panel (Web) — Screen Specification

Canonical IDs. Phase: **1** = MVP, **2** = core, **3** = full. `SHOWCASE` = included in the 5-hour hackathon build.

| ID | Screen | Phase | Showcase | Next |
|---|---|---|---|---|
| A-01 | Admin Login | 1 | yes | A-02 |
| A-01A | Admin 2FA / OTP Verification | 1 | yes | A-02 |
| A-02 | Admin Dashboard | 1 | yes | A-03, A-04, A-05, A-06, A-07, A-08, A-09, A-10 |
| A-03 | Professional Verification | 1 | yes | A-03A |
| A-03A | Professional Verification Detail | 1 | yes | A-03, A-09 |
| A-04 | User Management | 1 |  | A-04A |
| A-04A | User Detail | 2 |  | A-04, A-05A, A-07A |
| A-05 | Booking Management | 1 | yes | A-05A |
| A-05A | Booking Detail | 2 |  | A-05, A-07A |
| A-06 | Emergency / SOS Monitoring | 1 | yes | A-06A |
| A-06A | Emergency Alert Detail | 1 | yes | A-06 |
| A-07 | Dispute & Issue Management | 2 |  | A-07A |
| A-07A | Issue / Dispute Detail | 2 |  | A-07 |
| A-08 | Platform Monitoring & Statistics | 2 |  | A-02 |
| A-09 | Admin Notifications | 1 |  | A-02, A-03A, A-06A |
| A-10 | Admin Profile & Settings | 2 |  | A-02, A-01 |
| A-11 | Audit Log & Activity | 2 |  | A-02 |
| A-12 | Help & Support / Knowledge Base | 3 |  | A-02 |
| A-13 | Broadcast & Message Templates | 3 |  | A-09 |

## A-01 — Admin Login

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Secure administrator authentication

**Specification**

```text
Section: Authentication

 What the Admin sees: Secure admin login with email/username, password, visibility control, Login button, Forgot Password
 and secure-access notice.

 Actions / buttons:

   • Login → A-02 Admin Dashboard.

   • Forgot Password → account recovery flow.

   • Invalid credentials → validation/error state.

 Functional purpose: Secure entry into the administration panel. Admin access is restricted to authorized accounts.
Admin Panel Specification                                                                               Page 1
```

**Next screens:** A-02
**Actions:** Login
**API:** POST /auth/login
**Design-system components:** Centered card, HgTextField, HgButton, SecurityNote
**States / rules:** generic error text; rate-limited

## A-01A — Admin 2FA / OTP Verification

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Second factor after password — mandatory for every admin login

**Specification**

```text
Layout: centred card; 6 OTP boxes; resend timer (60 s); security note.
Actions: Verify -> A-02. 3 wrong attempts -> lockout + audit entry.
Rule (flow chart): "Access requires 2FA (OTP)".
```

**Next screens:** A-02
**Actions:** Enter OTP; Resend OTP; Verify
**API:** POST /auth/admin/2fa
**Design-system components:** OtpField, ResendTimer
**States / rules:** 3 attempts

## A-02 — Admin Dashboard

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Administrative command center

**Specification**

```text
Section: Core Admin

 What the Admin sees: Summary cards for total users, verified professionals, pending verifications, active bookings,
 completed bookings, open issues and active SOS alerts. Quick-action cards and recent activity.

 Actions / buttons:

   • Professional Verification → A-03.

   • Users → A-04.

   • Bookings → A-05.

   • Emergency/SOS → A-06.

   • Issues/Disputes → A-07.

   • Statistics/Monitoring → A-08.

 Functional purpose: Central control center for platform monitoring and administrative actions.
```

**Next screens:** A-03, A-04, A-05, A-06, A-07, A-08, A-09, A-10
**Actions:** Verification; Users; Bookings; Emergency; Disputes; Statistics; Notifications; Settings
**API:** GET /admin/stats; GET /admin/professionals?status=pending; GET /admin/sos?status=open; WS admin:all
**Design-system components:** SideNav(dark teal), TopBar, KpiCard x4, SosBanner(red,sticky), VerificationQueue, RecentBookings
**States / rules:** SOS banner persists until acknowledged

## A-03 — Professional Verification

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Review professional verification queue

**Specification**

```text
Section: Verification

 What the Admin sees: Tabs/filters for Pending, Approved, Rejected and Action Required. Professional cards showing name,
 role, specialization, verification status and submitted-document status.

 Actions / buttons:

   • Open professional → A-03A Verification Detail.

   • Approve → approval confirmation/status.

   • Reject → rejection reason.

   • Request Changes → required corrections.

 Functional purpose: Admin reviews doctors and nurses before they can provide services.
```

**Next screens:** A-03A
**Actions:** Review
**API:** GET /admin/professionals
**Design-system components:** FilterTabs, DataTable, StatusBadge
**States / rules:** pending/approved/rejected/needs changes

## A-03A — Professional Verification Detail

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Review credentials and decide verification

**Specification**

```text
Section: Verification

 What the Admin sees: Professional identity information, role, specialization, experience, CNIC/identity documents,
 degree/certification documents, registration/license information where applicable, submission history and verification notes.

 Actions / buttons:

   • View document.

   • Approve Professional.

   • Reject Professional.

   • Request Changes.

   • Return to verification list.

 Functional purpose: Detailed verification workspace. Only information actually submitted by the professional should be
 reviewed.
Admin Panel Specification                                                                                    Page 2
```

**Next screens:** A-03, A-09
**Actions:** Approve/Reject/Request Changes
**API:** GET /admin/professionals/{id}; PUT /admin/professionals/{id}/decision
**Design-system components:** TwoColumnReview, DocumentViewer(signed URL), DocChecklist, ReasonDialog, ConfirmDialog
**States / rules:** reason required for reject/changes; audited

## A-04 — User Management

**Phase 1** · PROPOSED

**Purpose:** Manage patient accounts

**Specification**

```text
Section: Users

 What the Admin sees: Patient and professional user lists with search, filters, role/status indicators and basic account
 information.

 Actions / buttons:

   • Open user → A-04A User Detail.

   • Filter/search users.

   • Suspend/restore account when permitted.

   • View activity/booking history.

 Functional purpose: Admin manages platform accounts and user status.
```

**Next screens:** A-04A
**Actions:** View
**API:** GET /admin/users
**Design-system components:** SearchBar, DataTable, StatusBadge

## A-04A — User Detail

**Phase 2** · PROPOSED

**Purpose:** Review account-level details

**Specification**

```text
Section: Users

 What the Admin sees: Selected user's basic profile, role, verification/status, contact information, relevant booking history,
 account activity and issue flags.

 Actions / buttons:

   • Change permitted account status.

   • View bookings.

   • View reported issues.

   • Back → A-04.

 Functional purpose: Provides administrative context for a particular user without exposing unnecessary private medical
 information.
```

**Next screens:** A-04, A-05A, A-07A
**Actions:** Back; Booking; Issue
**API:** GET /admin/users/{id}; PUT /admin/users/{id}/status
**Design-system components:** ProfileSummary, RecentBookings, ConfirmDialog
**States / rules:** NO medical data shown

## A-05 — Booking Management

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Monitor bookings

**Specification**

```text
Section: Bookings

 What the Admin sees: Tabs/filters for Doctor Appointments, Nurse Home Visits, Lab Bookings and Medicine Orders. Status
 filters such as Pending, Accepted, Active, Completed and Cancelled. Search by booking reference/user/professional.

 Actions / buttons:

   • Open booking → A-05A Booking Detail.

   • Filter/search.

   • Monitor booking status.

   • Open related user/professional profile.

 Functional purpose: Central monitoring of healthcare service bookings.
```

**Next screens:** A-05A
**Actions:** View
**API:** GET /admin/bookings
**Design-system components:** DataTable, StatusBadge, DateRange

## A-05A — Booking Detail

**Phase 2** · PROPOSED

**Purpose:** Review booking operational details

**Specification**

```text
Section: Bookings

 What the Admin sees: Booking reference, patient, professional, service type, date/time, location where appropriate, status
 timeline, relevant instructions, payment/order state when applicable and issue flags.

 Actions / buttons:

   • Monitor/update permitted status.

   • Open user/professional.

   • Escalate issue → A-07.
   • Return to bookings.

 Functional purpose: Administrative view of an individual booking.
Admin Panel Specification                                                                                     Page 3
```

**Next screens:** A-05, A-07A
**Actions:** Back; Issue
**API:** GET /admin/bookings/{id}
**Design-system components:** Timeline, SummaryCards
**States / rules:** no clinical records

## A-06 — Emergency / SOS Monitoring

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Monitor emergency queue

**Specification**

```text
Section: Emergency

 What the Admin sees: Prominent active-emergency section with red alert indicators. List of active/recent SOS events
 showing patient, time, alert status, location/status information available to the platform and assigned/relevant booking.

 Actions / buttons:

   • Open SOS → A-06A Emergency Detail.

   • Acknowledge alert.

   • Mark response status.

   • Filter active/resolved alerts.

 Functional purpose: High-priority safety screen. An active SOS should be visually distinct from normal platform activity.
```

**Next screens:** A-06A
**Actions:** Open Alert
**API:** GET /admin/sos; WS sos.created / sos.updated
**Design-system components:** SosBanner, SosAlertCard, MapPreview, Tabs(active/resolved)
**States / rules:** new alert: sound + red flash + toast

## A-06A — Emergency Alert Detail

**Phase 1** · SHOWCASE · PROPOSED

**Purpose:** Acknowledge and manage SOS response

**Specification**

```text
Section: Emergency

 What the Admin sees: Large emergency status header, patient information relevant to response, emergency time, available
 location information, related booking/professional, emergency contacts/actions and response timeline.

 Actions / buttons:

   • Acknowledge.

   • Take/record response action.

   • Escalate according to platform workflow.

   • Mark Resolved after appropriate action.

   • Return to emergency monitoring.

 Functional purpose: Admin response workspace for emergency events. Exact real-world emergency integration is not
 defined by the source and should not be invented.
```

**Next screens:** A-06
**Actions:** Acknowledge; Update; Resolve; Escalate
**API:** GET /admin/sos/{id}; POST .../acknowledge; POST .../events; POST .../resolve
**Design-system components:** RedHeader, MapView, PatientContactCard, Timeline, NoteBox, ActionBar
**States / rules:** only show data device reported; no fake dispatch

## A-07 — Dispute & Issue Management

**Phase 2** · PROPOSED

**Purpose:** Manage issues/disputes

**Specification**

```text
Section: Support

 What the Admin sees: Open/resolved issue list with issue type, user, booking reference, priority, status and timestamps.

 Actions / buttons:

   • Open issue → A-07A Issue Detail.

   • Assign/update status where permitted.

   • Resolve issue.

   • Search/filter issues.

 Functional purpose: Handles reported booking/platform problems and disputes.
```

**Next screens:** A-07A
**Actions:** Open
**API:** GET /admin/disputes
**Design-system components:** DataTable, PriorityBadge

## A-07A — Issue / Dispute Detail

**Phase 2** · PROPOSED

**Purpose:** Resolve or escalate issue

**Specification**

```text
Section: Support

 What the Admin sees: Issue description, involved user/professional, related booking, timestamps, conversation/evidence
 available to Admin, status and resolution notes.

 Actions / buttons:

   • Update status.

   • Add resolution note.
   • Resolve/escalate issue.

   • Return to issue list.

 Functional purpose: Creates a traceable administrative resolution record.
Admin Panel Specification                                                                                      Page 4
```

**Next screens:** A-07
**Actions:** Resolve; Escalate
**API:** GET/PUT /admin/disputes/{id}; POST .../notes
**Design-system components:** TicketHeader, NotesThread, ActionBar

## A-08 — Platform Monitoring & Statistics

**Phase 2** · PROPOSED

**Purpose:** Platform metrics and statistics

**Specification**

```text
Section: Analytics

 What the Admin sees: High-level platform statistics: registered users, active professionals, verification counts, booking
 volumes, service categories, completed/cancelled bookings, SOS counts and issue counts. Date/filter controls.

 Actions / buttons:

   • Change date range/filter.

   • Open relevant management area from a metric.

   • Refresh data.

 Functional purpose: Provides operational visibility rather than clinical analytics.
```

**Next screens:** A-02
**Actions:** Back
**API:** GET /admin/stats
**Design-system components:** KpiCard, LineChart, BarChart, DateRange
**States / rules:** real data only

## A-09 — Admin Notifications

**Phase 1** · PROPOSED

**Purpose:** Operational alerts

**Specification**

```text
Section: Notifications

 What the Admin sees: Administrative alerts grouped by professional verification, emergency, booking, issue/dispute,
 security and system events. Unread indicators.

 Actions / buttons:

   • Open notification → relevant admin screen.

   • Mark as read.

   • Mark all read.

 Functional purpose: Central notification stream for important administrative events.
```

**Next screens:** A-02, A-03A, A-06A
**Actions:** Open
**API:** GET /admin/notifications
**Design-system components:** GroupedList, UnreadDot

## A-10 — Admin Profile & Settings

**Phase 2** · PROPOSED

**Purpose:** Admin account/settings

**Specification**

```text
Section: Settings

 What the Admin sees: Admin profile, password/security controls, notification preferences, session/security settings, support,
 terms and logout.

 Actions / buttons:

   • Update permitted settings.

   • Logout → A-01.

   • Security action → confirmation flow.

 Functional purpose: Controls the administrator's own account and secure session.
Admin Panel Specification                                                                                      Page 5
 4. 5-Hour Hackathon MVP — Admin Panel
 The Admin Panel exists primarily to demonstrate trust, platform control and the SOS response loop. The following screens
 are the recommended minimum scope:

   • A-01 Admin Login

   • A-02 Admin Dashboard

   • A-03 Professional Verification

   • A-03A Professional Verification Detail

   • A-05 Booking Management

   • A-06 Emergency / SOS Monitoring

   • A-06A Emergency Alert Detail

   • A-04 User Management (simplified)

   • A-09 Admin Notifications (basic)

 5. Recommended Admin Demo Journey
   • Admin logs in → Admin Dashboard.

   • Admin opens Professional Verification → reviews a doctor/nurse credential record → approves or requests changes.

   • Admin returns to Dashboard → opens Booking Management → views the patient booking created from the User Panel.

   • Patient triggers SOS → Admin Dashboard immediately shows a prominent emergency alert.

   • Admin opens Emergency Alert Detail → acknowledges and records the response state.

   • This demonstrates the platform's three major trust pillars: verified professionals, centralized healthcare management and
     emergency safety.

 6. Admin Responsibilities Covered
   • Admin Authentication & Secure Access

   • Professional Verification

   • User Management

   • Booking Management

   • Emergency Monitoring

   • Emergency Response Control

   • Platform Monitoring

   • Dispute & Issue Management

   • Platform Statistics

   • Notifications and administrative account settings

 7. Scope & Accuracy Notes
   • Admin screen IDs A-01 onward are proposed identifiers for the UI specification; they are not claimed to be exact screen IDs
     from the source Developer Guide.

   • The source material supports the Admin responsibilities listed above but does not specify a complete Admin UI layout.
     Detailed UI elements are therefore design proposals for the project.
   • Emergency screens should display only location/network information actually available to the platform. Do not claim a
     production emergency-dispatch integration unless it is implemented.

   • Clinical medical-record access should remain privacy-controlled; Admin should not automatically receive unrestricted patient
     medical records merely because the Admin can manage the platform.
Admin Panel Specification                                                                                      Page 6
   • Advanced analytics, full dispute tooling and extensive account controls can be simplified or deferred for the 5-hour
     prototype.
Admin Panel Specification                                                                                     Page 7
```

**Next screens:** A-02, A-01
**Actions:** Save; Logout
**API:** GET /me; PUT /me
**Design-system components:** ProfileForm, SecuritySettings, ActivityLogPreview

## A-11 — Audit Log & Activity

**Phase 2** · PROPOSED

**Purpose:** Immutable list of every admin action (flow chart rule: all actions are logged)

**Specification**

```text
Layout: filter bar + table (time, actor, action, entity, reason). Read-only. No edit/delete anywhere.
```

**Next screens:** A-02
**Actions:** Filter by actor/entity/date; Open entity
**API:** GET /admin/audit-logs
**Design-system components:** FilterBar, DataTable
**States / rules:** read-only

## A-12 — Help & Support / Knowledge Base

**Phase 3** · PROPOSED

**Purpose:** FAQs, contact support, raise a ticket (flow chart A-15)

**Specification**

```text
Layout: search, FAQ accordion, contact card, ticket form.
```

**Next screens:** A-02
**Actions:** Search FAQ; Raise ticket
**API:** POST /public/contact
**Design-system components:** FaqAccordion

## A-13 — Broadcast & Message Templates

**Phase 3** · PROPOSED

**Purpose:** Send broadcast notifications and manage SMS/email/push templates (flow chart A-11/A-13)

**Specification**

```text
Layout: template list, editor with preview, audience selector (all patients / all professionals / segment), confirm dialog with recipient count.
```

**Next screens:** A-09
**Actions:** Create template; Send broadcast (confirm)
**API:** GET/PUT /admin/settings
**Design-system components:** TemplateEditor, AudienceSelector, ConfirmDialog
