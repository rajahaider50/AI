# Patient Android App — Screen Specification

Canonical IDs. Phase: **1** = MVP, **2** = core, **3** = full. `SHOWCASE` = included in the 5-hour hackathon build.

| ID | Screen | Phase | Showcase | Next |
|---|---|---|---|---|
| P-01 | Splash | 1 | yes | P-02 |
| P-02 | Onboarding 1 | 1 | yes | P-03 |
| P-03 | Onboarding 2 | 1 | yes | P-04 |
| P-04 | Onboarding 3 | 1 | yes | P-05 |
| P-05 | Login | 1 | yes | P-11, P-06 |
| P-06 | Sign Up | 1 | yes | P-07 |
| P-07 | OTP | 1 | yes | P-08 |
| P-08 | Profile Setup 1 | 1 |  | P-09 |
| P-09 | Profile Setup 2 — Address | 1 |  | P-10 |
| P-10 | Profile Setup 3 — Emergency Contact | 1 |  | P-11 |
| P-11 | Home Dashboard | 1 | yes | P-12, P-13, P-16, P-25, P-26, P-27, P-28, P-30, P-31, P-32 |
| P-12 | Service Category | 1 |  | P-13, P-26, P-27 |
| P-13 | Browse Professionals | 1 |  | P-14 |
| P-14 | Professional Profile | 1 |  | P-15 |
| P-15 | Booking Details | 1 | yes | P-16, P-17, P-18 |
| P-16 | Health Passport PIN / Access | 2 | yes | P-18 |
| P-17 | Supply Pre-Request | 2 |  | P-18 |
| P-18 | Booking Summary & Payment | 1 |  | P-19 |
| P-19 | Booking Confirmed | 1 |  | P-20, P-22 |
| P-20 | Live Tracking | 2 |  | P-21 |
| P-21 | Visit In Progress | 2 |  | P-22, P-25 |
| P-22 | Visit Complete | 2 |  | P-23, P-24 |
| P-23 | Rating & Review | 2 |  | P-32 |
| P-24 | Health Passport | 2 | yes | P-11, P-16 |
| P-25 | Emergency Screen / SOS | 3 | yes | A-06 |
| P-26 | Lab Test Booking | 3 |  | P-18 |
| P-27 | Medicine Order | 3 |  | P-18 |
| P-28 | Wallet | 3 |  | P-11 |
| P-29 | Referral | 3 |  | P-11 |
| P-30 | Notifications | 2 |  | P-11, P-19, P-25 |
| P-31 | Profile & Settings | 3 |  | P-11 |
| P-32 | Booking History | 2 |  | P-11, P-14 |
| P-33 | Help & Support | 3 |  | P-31 |

## P-01 — Splash

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Launch and brand entry

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • Full-screen teal gradient background.

 • Centered HomiGo Care logo and tagline: “Because Care Begins at Home”.

 • Small loading animation at the bottom.

Actions / Buttons:

 • No primary input.

 • Automatic transition after loading.

Next screen / destination: Existing logged-in user → P-11 Home Dashboard. New/logged-out user → P-02 Onboarding 1.

Behavior / functional purpose: Initial entry point. The source guide specifies a short loading period before routing the user.
```

**Next screens:** P-02
**Actions:** Start
**API:** GET /me (if token)
**Design-system components:** Splash gradient, Official logo (white-on-tile), LoadingDots
**States / rules:** route by auth state

## P-02 — Onboarding 1

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Introductory onboarding

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • White background.

 • Large illustration of a nurse visiting an elderly patient at home.

 • Three progress dots; first dot active.

 • Heading: Professional Home Care.

 • Supporting text explaining home visits.

Actions / Buttons:

 • Next → P-03.

 • Skip → P-05 Login.

Next screen / destination: P-03 or P-05.

Behavior / functional purpose: Introduces the core home-care value proposition.
```

**Next screens:** P-03
**Actions:** Next
**Design-system components:** OnboardingPage, DotsIndicator, HgButton, Illustration #1
**States / rules:** skip persisted

## P-03 — Onboarding 2

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Explain core healthcare value

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • White background.

 • Verification/document illustration.

 • Three progress dots; second dot active.

 • Heading: Verified & Trusted Professionals.

 • Supporting text about document verification and testing.

Actions / Buttons:

 • Next → P-04.

 • Skip → P-05 Login.

Next screen / destination: P-04 or P-05.

Behavior / functional purpose: Explains why professionals on the platform are trusted.
```

**Next screens:** P-04
**Actions:** Next
**Design-system components:** OnboardingPage, Illustration #2

## P-04 — Onboarding 3

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Complete onboarding and enter authentication

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • White background.

 • GPS/safety illustration.

 • Three progress dots; third dot active.

 • Heading: Your Safety is Our Priority.

 • Supporting text about GPS tracking and emergency protection.

Actions / Buttons:

 • Get Started → P-06 Sign Up.

 • Login → P-05 Login.

Next screen / destination: P-06 or P-05.

Behavior / functional purpose: Completes onboarding and introduces the safety story.
```

**Next screens:** P-05
**Actions:** Get Started
**Design-system components:** OnboardingPage, Illustration #3

## P-05 — Login

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Patient authentication

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • HomiGo Care logo and tagline.

 • Pakistan phone-number field with +92 prefix.

 • Password field with show/hide control.

 • Primary LOGIN button.

 • Forgot Password link.

 • Continue with Google option.

 • Sign-up prompt.

Actions / Buttons:

 • Login → P-11.

 • Forgot Password → OTP reset flow.

 • Sign Up → P-06.

 • Google login → authentication flow.

Next screen / destination: P-11 after successful authentication, or the relevant recovery/registration flow.

Behavior / functional purpose: Phone format is validated. The source guide specifies OTP/JWT-based authentication.
```

**Next screens:** P-11, P-06
**Actions:** Login; Create Account
**API:** POST /auth/login; POST /auth/forgot-password
**Design-system components:** HgPhoneField(+92), HgPasswordField, HgButton, GoogleButton
**States / rules:** loading, invalid creds, locked, offline

## P-06 — Sign Up

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Create patient account

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • HomiGo Care logo.

 • Full name field.

 • Pakistan phone-number field.

 • Password and confirm-password fields.

 • Privacy/terms checkbox.

 • Primary SIGN UP button.

 • Login link.

Actions / Buttons:

 • Sign Up → P-07 OTP Verification.

 • Login → P-05.

Next screen / destination: P-07.

Behavior / functional purpose: Starts verified patient registration.
```

**Next screens:** P-07
**Actions:** Continue
**API:** POST /auth/signup
**Design-system components:** HgTextField, HgPhoneField, HgPasswordField x2, HgCheckbox
**States / rules:** field errors, duplicate phone

## P-07 — OTP

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Verify phone number

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • 6-digit OTP input boxes.

 • Phone number confirmation text.

 • Resend timer.

 • Verify button.

 • Back arrow.

Actions / Buttons:

 • Verify → P-08 Profile Setup Step 1.

 • Resend OTP after timer.

 • Back → P-06.

Next screen / destination: P-08 after successful verification.

Behavior / functional purpose: Three incorrect attempts trigger lockout according to the source guide.
```

**Next screens:** P-08
**Actions:** Verify
**API:** POST /auth/verify-otp; POST /auth/resend-otp
**Design-system components:** OtpField(6), ResendTimer(60s)
**States / rules:** wrong code(3 max), expired(10 min), locked

## P-08 — Profile Setup 1

**Phase 1** · SOURCE_DERIVED

**Purpose:** Basic profile information

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • Progress: Step 1 of 3.

 • Profile photo upload.

 • CNIC number field.

 • CNIC front and back upload boxes.

 • Date of birth.

 • Gender selector.

 • Primary Next button.

Actions / Buttons:

 • Next → P-09.

 • Fields must be completed before continuing.

Next screen / destination: P-09.

Behavior / functional purpose: Creates the verified patient identity/profile information.
```

**Next screens:** P-09
**Actions:** Continue
**API:** PUT /patient/profile; POST /patient/documents/upload-url
**Design-system components:** StepProgress(1/3), PhotoPicker, CnicField, UploadBox x2, DatePicker, SegmentedGender
**States / rules:** all fields required, upload progress/failure

## P-09 — Profile Setup 2 — Address

**Phase 1** · SOURCE_DERIVED

**Purpose:** Patient address/location

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • Progress: Step 2 of 3.

 • Map with location pin.

 • Use My Current Location button.

 • Manual house/flat, street/area, city and zone fields.

 • Save Address.

 • Add Another Address option.

 • Next button.

Actions / Buttons:

 • Use location → populate address.

 • Add Another Address → save another location.

 • Next → P-10.

Next screen / destination: P-10.

Behavior / functional purpose: Stores the patient's service/home location(s).
```

**Next screens:** P-10
**Actions:** Continue
**API:** POST /patient/addresses
**Design-system components:** StepProgress(2/3), MapView, HgButton(outline,GPS), ZoneSelector
**States / rules:** location permission denied, GPS off, geocode fail

## P-10 — Profile Setup 3 — Emergency Contact

**Phase 1** · SOURCE_DERIVED

**Purpose:** Emergency contact setup

**Specification**

```text
Section: Auth Flow

Layout / What the user sees:

 • Progress: Step 3 of 3.

 • Emergency contact name and phone fields.

 • Relationship selector.

 • Safety information box.

 • Complete Setup button.

Actions / Buttons:

 • Complete Setup → P-11.

 • Back → previous setup step.

Next screen / destination: P-11 Home Dashboard.

Behavior / functional purpose: Creates the emergency contact used in the safety workflow.
```

**Next screens:** P-11
**Actions:** Finish
**API:** PUT /patient/emergency-contact
**Design-system components:** StepProgress(3/3), RelationshipChips, InfoBox(teal-50), Confetti
**States / rules:** on success confetti then P-11

## P-11 — Home Dashboard

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Main patient control center

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Top bar: location, notifications, profile.

 • Personalized greeting.

 • Large red EMERGENCY HELP button.

 • Service grid: Nurse, Doctor, Lab Test, Medicine, Equipment, Hospital Supply.

 • Quick Rebook section.

 • Top Rated Near You section.

 • Bottom navigation: Home, Bookings, Health Passport, Medicine, Profile.

Actions / Buttons:

 • Service category → P-12.

 • Emergency Help → P-25.

 • Notifications → P-30.

 • Profile → P-31.

 • Bottom navigation → corresponding section.

Next screen / destination: P-12, P-25, P-30, P-31 or other selected section.

Behavior / functional purpose: Central hub of the patient app. Urdu mode can expose voice-search access.
```

**Next screens:** P-12, P-13, P-16, P-25, P-26, P-27, P-28, P-30, P-31, P-32
**Actions:** Services; Professionals; Health Passport; SOS; Lab; Medicine; Wallet; Notifications; Profile; History
**API:** GET /catalog/services; GET /professionals?sort=rating; GET /bookings?tab=completed; GET /notifications
**Design-system components:** HgTopBar, SosButton(full width), ServiceTile grid 2x3, QuickRebook row, ProfessionalCard(compact), HgBottomNav
**States / rules:** skeletons, empty rebook, offline cache

## P-12 — Service Category

**Phase 1** · SOURCE_DERIVED

**Purpose:** Select healthcare service category

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Back arrow and service heading.

 • Search bar with search/voice controls.

 • Filter chips: All, Nearby, Top Rated, Available Now.

 • Large service-type cards.

 • Specialization/help-with icon grid.

Actions / Buttons:

 • Select service type/specialization → P-13.

 • Search/filter to narrow options.

 • Back → P-11.

Next screen / destination: P-13 Browse Professionals.

Behavior / functional purpose: For example, Nurse services can expose Home Visit Nurse, Dedicated Nurse and Hospital
Companion.
```

**Next screens:** P-13, P-26, P-27
**Actions:** Doctor/Nurse; Lab; Medicine
**API:** GET /catalog/services?category=NURSE
**Design-system components:** HgTopBar, SearchBar+mic, FilterChips, ServiceTypeCard, SpecializationGrid
**States / rules:** empty, search no result

## P-13 — Browse Professionals

**Phase 1** · SOURCE_DERIVED

**Purpose:** Browse doctors/nurses

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Back arrow and selected service.

 • Sort/filter controls for rating, price, distance, gender, language and availability.

 • Favourites section when available.

 • Verified professional cards with photo, name, certification badge, specialization, hospital/clinic affiliation, rating, languages,
   distance, price and availability.

 • Book Now and favourite controls.

Actions / Buttons:

 • Tap professional/Book Now → P-14.

 • Favourite → save professional.

Next screen / destination: P-14 Professional Profile.

Behavior / functional purpose: Only suitable/verified professionals should be presented to the patient.
```

**Next screens:** P-14
**Actions:** View Professional
**API:** GET /professionals; PUT /patient/favourites/{id}
**Design-system components:** FilterBar, ProfessionalCard, FavouriteHeart
**States / rules:** skeleton, empty, paging

## P-14 — Professional Profile

**Phase 1** · SOURCE_DERIVED

**Purpose:** Review professional information

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Cover/profile imagery.

 • Verified badges.

 • Name, specialization and experience.

 • Current hospital/clinic affiliation.

 • Rating/reviews.

 • Languages.

 • About/bio.

 • Services offered.

 • Verified credentials.

 • Reviews.

 • Availability calendar.

 • Pricing table.

 • Fixed Book Now button.

Actions / Buttons:

 • Book Now → P-15.

 • See all reviews → review list.

 • Back → P-13.

Next screen / destination: P-15 Booking Details.

Behavior / functional purpose: Patient can assess qualifications and service details before booking.
```

**Next screens:** P-15
**Actions:** Book
**API:** GET /professionals/{id}; GET /professionals/{id}/reviews; GET /professionals/{id}/availability
**Design-system components:** CoverGradient, Avatar, VerifiedBadge, ReviewItem, AvailabilityCalendar, PricingTable, BottomActionBar
**States / rules:** offline/busy professional

## P-15 — Booking Details

**Phase 1** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Enter service/visit details

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Professional summary.

 • Booking type: Instant, Scheduled, Recurring, Online video.

 • Date/time when applicable.

 • Duration for dedicated care.

 • Saved-address selector.

 • Problem/special-instruction field.

 • Optional Urdu voice note.

 • Add More Services: Lab Test, Medicine Delivery, Equipment Rental.

 • Continue button.

Actions / Buttons:

 • Continue → P-16 Health Passport Access.

 • Choose address/date/type/duration as applicable.

Next screen / destination: P-16.

Behavior / functional purpose: Collects the actual service request details before access/payment.
```

**Next screens:** P-16, P-17, P-18
**Actions:** Health Passport; Supply Pre-Request; Continue
**API:** POST /bookings/quote; GET /patient/addresses
**Design-system components:** SegmentedBookingType, DateTimePicker, DurationSelector, AddressSelector, VoiceNoteRecorder, ExtrasCheckboxes
**States / rules:** validation, past date blocked

## P-16 — Health Passport PIN / Access

**Phase 2** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Authorize protected Health Passport access with 4-digit PIN

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Large lock icon.

 • Explanation that the professional will ask for the PIN during the visit.

 • Four masked PIN dots.

 • View PIN option protected by device authentication.

 • Expandable list of information the professional can see.

 • Customize Access option.

 • Critical-alert warning when applicable.

 • Continue to Booking button.

Actions / Buttons:

 • Continue → P-17 if supplies are involved; otherwise → P-18.

 • Customize Access → configure permitted health information.

Next screen / destination: P-17 or P-18.

Behavior / functional purpose: Patient-controlled Health Passport authorization. This is a hackathon MVP hero feature
even though the original source guide places the PIN screen under the broader main-app flow.
```

**Next screens:** P-18
**Actions:** Authorize
**API:** POST /health-passport/verify-pin; POST /health-passport/grants
**Design-system components:** Lock icon, PinDots, BiometricPrompt, ScopeList, HgButton
**States / rules:** wrong PIN, lockout, MVP bridge = consent/skip

## P-17 — Supply Pre-Request

**Phase 2** · SOURCE_DERIVED

**Purpose:** Collect additional booking/request information when required

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Supply-request heading.

 • Nurse request explanation.

 • Supply list with item, quantity and price.

 • Subtotal.

 • Receipt-verification notice.

 • Approve, Request Changes and Decline actions.

Actions / Buttons:

 • Approve → P-18.

 • Request Changes → supply revision flow.

 • Decline → P-18 without supplies.

Next screen / destination: P-18 Booking Summary.

Behavior / functional purpose: Use when a nurse/professional has requested supplies.
```

**Next screens:** P-18
**Actions:** Continue
**API:** PUT /bookings/{id}/supplies/{sid}/decision
**Design-system components:** SupplyItemRow, Subtotal, HgButton x3
**States / rules:** realtime update

## P-18 — Booking Summary & Payment

**Phase 1** · SOURCE_DERIVED

**Purpose:** Review booking and payment

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Booking reference.

 • Professional summary.

 • Service/date/time/location/duration.

 • Cost breakdown.

 • Total amount.

 • Payment-method selector.

 • Cancellation policy.

 • Confirm & Pay button.

Actions / Buttons:

 • Confirm & Pay → payment processing → P-19.

 • Back → edit booking details.

Next screen / destination: P-19 after successful payment.

Behavior / functional purpose: For a 5-hour prototype, payment can be represented by a controlled demo state rather
than a production payment integration.
```

**Next screens:** P-19
**Actions:** Confirm
**API:** POST /bookings; POST /payments/confirm
**Design-system components:** ProfessionalCardSmall, CostBreakdown, PaymentMethodSelector, HgButton
**States / rules:** idempotent submit, payment failed, wallet short

## P-19 — Booking Confirmed

**Phase 1** · SOURCE_DERIVED

**Purpose:** Confirmation and booking reference

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Large success checkmark.

 • Booking reference.

 • Professional details.

 • Estimated arrival.

 • Track on Map.

 • Call Professional.

 • Add to Calendar.

 • Share booking.

 • Back to Home.

Actions / Buttons:

 • Track on Map → P-20.

 • Back to Home → P-11.

 • Call → phone action.

Next screen / destination: P-20 or P-11.

Behavior / functional purpose: Confirms that the booking was successfully created.
```

**Next screens:** P-20, P-22
**Actions:** Track; View/Manage
**API:** GET /bookings/{id}
**Design-system components:** AnimatedCheck, BookingRef, ProfessionalCardSmall, HgButton x2
**States / rules:** confetti-free, calm animation

## P-20 — Live Tracking

**Phase 2** · SOURCE_DERIVED

**Purpose:** Track applicable home visit

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Full-screen map.

 • Professional moving-location indicator.

 • Patient/home pin.

 • Route line.

 • Bottom professional status card with ETA/distance.

 • Call and Chat controls.

 • Small always-visible Emergency button.

Actions / Buttons:

 • Emergency → P-25.

 • When professional arrives → P-21.

 • Call/Chat → communication action.

Next screen / destination: P-21 Visit In Progress.

Behavior / functional purpose: Real-time tracking is a broader core feature; for the 5-hour MVP, it can be represented with
a simulated/demo movement state if live tracking is not implemented.
```

**Next screens:** P-21
**Actions:** View Visit
**API:** WS booking:{id} tracking.location
**Design-system components:** MapView, BottomSheet, EtaChip, SosChip
**States / rules:** GPS lag, reconnect

## P-21 — Visit In Progress

**Phase 2** · SOURCE_DERIVED

**Purpose:** Active visit state

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Visit status with active indicator.

 • Professional details.

 • Visit timer.

 • Service checklist.

 • Supplies-used section.

 • Large red SOS button with hold-to-activate instruction.

Actions / Buttons:

 • SOS → P-25.

 • Professional completes visit → P-22.

Next screen / destination: P-22 when completed; P-25 for emergency.

Behavior / functional purpose: Safety remains accessible during an active home visit.
```

**Next screens:** P-22, P-25
**Actions:** Complete; SOS
**API:** WS booking:{id}
**Design-system components:** VisitTimer, ChecklistView, SupplyUsed, SosButton(hold 3s)
**States / rules:** only professional completes

## P-22 — Visit Complete

**Phase 2** · SOURCE_DERIVED

**Purpose:** Completed service

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Completion checkmark.

 • Visit duration.

 • Services performed.

 • Supplies used.

 • View Visit Notes.

 • Rating prompt.

 • Final bill/payment status.

 • Pay Now when applicable.

Actions / Buttons:

 • Rate → P-23.

 • View Visit Notes → Health Passport history entry.

 • Pay Now → payment flow.

Next screen / destination: P-23 or Health Passport history.

Behavior / functional purpose: Summarizes the completed service.
```

**Next screens:** P-23, P-24
**Actions:** Rate; Health Passport
**API:** GET /bookings/{id}
**Design-system components:** SummaryCard, BillBreakdown, HgButton
**States / rules:** cash due

## P-23 — Rating & Review

**Phase 2** · SOURCE_DERIVED

**Purpose:** Rate professional and leave feedback

**Specification**

```text
Section: Main App

Layout / What the user sees:

 • Professional photo/name.

 • Category ratings: punctuality, professionalism, medical skills, communication and overall experience.

 • Written review box.

 • Anonymous toggle.

 • Submit Review.

 • Skip for now.

 • Cashback notice.

Actions / Buttons:

 • Submit → booking/profile update and wallet cashback state.

 • Skip → booking/home context.

Next screen / destination: Returns to the relevant booking/history context.

Behavior / functional purpose: Review becomes part of the professional's public reputation.
```

**Next screens:** P-32
**Actions:** Submit
**API:** POST /bookings/{id}/review
**Design-system components:** RatingBar x5, ReviewTextArea, AnonymousSwitch, CashbackBanner
**States / rules:** PKR 50 cashback

## P-24 — Health Passport

**Phase 2** · SHOWCASE · SOURCE_DERIVED

**Purpose:** View digital medical record after authorization

**Specification**

```text
Section: Health & Records

Layout / What the user sees:

 • Health Passport title and QR icon.

 • Unique patient ID.

 • Quick info: blood group, allergies, conditions.

 • Tabs: Overview, History, Documents, Vitals, Access Log.

 • Overview: health info, medications, critical alerts, masked emergency PIN.

 • History: chronological visit notes.

 • Documents: prescriptions, lab reports, discharge summaries.

 • Vitals: blood pressure, blood sugar, weight, temperature.

 • Access Log: who accessed what and when; unauthorized-access report.

Actions / Buttons:

 • Open tabs to view records.

 • Reveal sensitive information only after device/PIN protection.

 • Report unauthorized access → security/support flow.

Next screen / destination: Remains within Health Passport.

Behavior / functional purpose: Core privacy feature. Data is encrypted and the access log is intended to be immutable
according to the source guide.
```

**Next screens:** P-11, P-16
**Actions:** Home; Authorize Access
**API:** GET /health-passport; GET /health-passport/records; GET /health-passport/access-log
**Design-system components:** TabRow(5), InfoChips, VitalsChart, DocumentList, AccessLogList
**States / rules:** PIN/biometric gate, immutable log

## P-25 — Emergency Screen / SOS

**Phase 3** · SHOWCASE · SOURCE_DERIVED

**Purpose:** Trigger emergency alert

**Specification**

```text
Section: Emergency

Layout / What the user sees:

 • Red/teal emergency visual treatment.

 • Large central SOS control with 3-second hold instruction.

 • One-tap emergency contacts: Rescue 1122, Police 15, Edhi Ambulance 115, Women Safety 1099, HomiGo Care
   Emergency.

 • Emergency booking cards for nurse/doctor/online doctor.

 • Location-sharing status.

 • Cancel control.

Actions / Buttons:

 • Hold SOS → activate emergency alert and location-sharing behavior.

 • Emergency booking → prioritized emergency booking flow.

 • Cancel → return to prior screen.

Next screen / destination: P-25 activated state / Admin emergency workflow.

Behavior / functional purpose: This is explicitly promoted into the hackathon MVP as a hero feature. The prototype should
only claim offline/SMS escalation if it is actually implemented; otherwise describe it as a designed emergency workflow.
```

**Next screens:** A-06
**Actions:** Send SOS
**API:** POST /sos; POST /sos/{id}/location; POST /sos/{id}/cancel
**Design-system components:** SosHoldButton(3s), EmergencyNumberRow, EmergencyBookingCards, CancelText
**States / rules:** offline queue + SMS fallback, haptics, honest status text

## P-26 — Lab Test Booking

**Phase 3** · SOURCE_DERIVED

**Purpose:** Select and schedule lab test

**Specification**

```text
Section: Additional Services

Layout / What the user sees:

 • Test search.

 • Categories: blood, urine, imaging, cultures, packages.

 • Health package cards with price/contents.

 • Partner-lab section.

 • Popular tests list with price, home collection and Book action.

Actions / Buttons:

 • Select test/package/lab → booking details and confirmation flow.

 • Results later appear in Health Passport.

Next screen / destination: Booking/confirmation flow and then P-24 for results.

Behavior / functional purpose: For the 5-hour MVP, keep this as a simplified test selection → home collection →
date/address → confirmation flow.
```

**Next screens:** P-18
**Actions:** Confirm
**API:** GET /catalog/services?category=LAB_TEST
**Design-system components:** SearchBar, CategoryRow, PackageCard, PartnerLabRow
**States / rules:** phase 3

## P-27 — Medicine Order

**Phase 3** · SOURCE_DERIVED

**Purpose:** Search/upload prescription and place medicine order

**Specification**

```text
Section: Additional Services

Layout / What the user sees:

 • Medicine search.

 • Upload Prescription button.

 • Use Doctor's Prescription option when a digital prescription exists.

 • Medicine/supply categories.

 • Partner pharmacies.

 • Cart.

 • Delivery type selector.

Actions / Buttons:

 • Search/select → cart/order flow.

 • Upload prescription → attach prescription to order.

 • Use Doctor's Prescription → choose existing digital prescription.

Next screen / destination: Order confirmation/tracking flow.

Behavior / functional purpose: For the 5-hour MVP, simplify to search/upload prescription → order summary → place
order.
```

**Next screens:** P-18
**Actions:** Order
**API:** POST medicine order (phase 3)
**Design-system components:** UploadRxButton, PharmacyRow, Cart
**States / rules:** phase 3

## P-28 — Wallet

**Phase 3** · SOURCE_DERIVED

**Purpose:** View/manage wallet information

**Specification**

```text
Section: Wallet & Referral

Layout / What the user sees:

 • Wallet balance card.

 • Add Money and Withdraw actions.

 • Cashback summary.

 • Quick actions.

 • Recent transactions.

 • View all transactions.

Actions / Buttons:

 • Add Money → funding flow.

 • Withdraw → withdrawal flow.

 • Transaction History → transaction list.

Next screen / destination: Wallet subflows.

Behavior / functional purpose: Wallet is part of the full source screen set but can be deferred for the short hackathon
MVP.
```

**Next screens:** P-11
**Actions:** Home
**API:** GET /wallet
**Design-system components:** BalanceCard(gradient), TransactionRow
**States / rules:** phase 3

## P-29 — Referral

**Phase 3** · SOURCE_DERIVED

**Purpose:** Referral feature

**Specification**

```text
Section: Wallet & Referral

Layout / What the user sees:

 • Referral title.

 • Referral code card.

 • Copy and Share actions.

 • Three-step referral explanation.

 • Referral statistics.

 • Leaderboard.

 • Monthly prize banner.

Actions / Buttons:

 • Copy/Share → device sharing action.

 • Referral activity → referral status.

Next screen / destination: Referral subflows.

Behavior / functional purpose: Full feature; defer from the 5-hour hero build unless time remains.
```

**Next screens:** P-11
**Actions:** Back
**API:** GET /referrals
**Design-system components:** ReferralCodeCard, Leaderboard
**States / rules:** phase 3

## P-30 — Notifications

**Phase 2** · SOURCE_DERIVED

**Purpose:** Patient notifications

**Specification**

```text
Section: Settings & History

Layout / What the user sees:

 • Notifications title and Mark All Read.

 • Filter tabs: All, Bookings, Payments, Health, Promotions.

 • Notifications grouped by day.

 • Unread visual indicator.

 • Action button when relevant.

 • Empty state.

Actions / Buttons:

 • Tap notification → relevant destination.

 • Mark all read → clear unread state.

Next screen / destination: Relevant booking/payment/health/profile screen.

Behavior / functional purpose: Central notification history.
```

**Next screens:** P-11, P-19, P-25
**Actions:** Open Notification
**API:** GET /notifications; POST /notifications/read-all
**Design-system components:** FilterTabs, NotificationRow, EmptyState
**States / rules:** unread teal border

## P-31 — Profile & Settings

**Phase 3** · SOURCE_DERIVED

**Purpose:** Manage patient account/settings

**Specification**

```text
Section: Settings & History

Layout / What the user sees:

 • Profile photo and edit control.

 • Name, phone and HomiGo Care ID.

 • Account Settings.

 • Health Passport Settings.

 • Payment Settings.

 • Notification Settings.

 • Language: Urdu/English.

 • Privacy & Security.

 • Referral Program.

 • Help & Support.

 • Privacy Policy and Terms.

 • Log Out and Delete Account.

Actions / Buttons:

 • Edit profile → profile edit flow.

 • Language → switch entire app language.

 • Health Passport Settings → P-24-related controls.

 • Delete Account → OTP confirmation and cooling-period flow.

 • Log Out → P-05.

Next screen / destination: Settings subflows or P-05.

Behavior / functional purpose: Controls the user's account and privacy preferences.
```

**Next screens:** P-11
**Actions:** Save; Back
**API:** GET /me; PUT /me; DELETE /me
**Design-system components:** SettingsSection, LanguageToggle, DangerRow
**States / rules:** delete = OTP + 30 days

## P-32 — Booking History

**Phase 2** · SOURCE_DERIVED

**Purpose:** View previous bookings/orders

**Specification**

```text
Section: Settings & History

Layout / What the user sees:

 • Tabs: Upcoming, Completed, Cancelled.

 • Booking cards with professional, service, date, status and amount.

 • Book Again.

 • View Details.

 • Empty state when no bookings exist.

Actions / Buttons:

 • View Details → booking details/summary.

 • Book Again → pre-filled booking flow.

 • Tabs → corresponding history.

Next screen / destination: Booking detail or P-15/P-18 depending on action.

Behavior / functional purpose: Provides the patient's full booking history and rebooking path.

5. 5-Hour Hackathon MVP — User Panel Scope
• Hero Feature 1 — Digital Health Passport + 4-Digit PIN: P-16 and P-24. Demonstrate patient-controlled access to medical
  history.

• Hero Feature 2 — All-in-One Booking: P-11 → P-12/P-13/P-14/P-15 → confirmation, plus simplified P-26 Lab Test and P-27
  Medicine flows.

• Hero Feature 3 — Emergency SOS: P-11/P-20/P-21 → P-25, with the corresponding emergency alert visible in the Admin
  panel.

• Recommended demo path: Home Dashboard → choose service → professional → booking → Health Passport PIN →
  confirmation; then Health Passport → PIN-controlled access; then SOS → emergency alert.

• Full-source features such as Wallet, Referral, advanced tracking, complete payment integrations and the full marketplace
  experience can be shown as deferred/full-version scope if they are not built in the 5-hour MVP.

6. MVP Screen Priority
   Priority                     Screens

   Must Build                   P-01, P-05, P-06, P-07, P-11, P-12, P-13, P-14, P-15, P-16, P-18, P-19, P-24, P-25

   Simplified Build             P-26 Lab Test Booking, P-27 Medicine Order

   Supporting / Demo            P-17, P-20, P-21, P-22, P-23, P-30, P-31, P-32
   State

   Defer if time is limited     P-28 Wallet, P-29 Referral, advanced live tracking/payment marketplace behavior

7. Important Scope Notes
• The source Developer Guide contains a larger full-feature patient journey than the 5-hour hackathon build. This document
  preserves that full user-panel structure while clearly identifying the MVP subset.

• The Health Passport PIN and Emergency SOS are intentionally promoted to the hackathon MVP because they are core
  demonstration features agreed for HomiGo Care.

• Do not describe an emergency feature as fully offline or production-grade unless the prototype actually implements the
  required cellular/SMS behavior. The screen flow can demonstrate the intended escalation.

• Partner, professional and admin panels are outside this document. They should be documented separately so each role has
  its own screen-by-screen specification.
```

**Next screens:** P-11, P-14
**Actions:** Home; Rebook
**API:** GET /bookings?tab=
**Design-system components:** TabRow(3), BookingCard, EmptyState
**States / rules:** rebook prefill

## P-33 — Help & Support

**Phase 3** · SOURCE_DERIVED

**Purpose:** FAQs, contact support, raise a ticket

**Specification**

```text
Layout: search, FAQ list, contact options, ticket form. Entered from Profile & Settings.
```

**Next screens:** P-31
**Actions:** Search FAQ; Raise ticket; Chat/Call support
**API:** POST /public/contact
**Design-system components:** FaqAccordion
