-- =====================================================================
-- HomiGo Care — DEVELOPMENT SEED DATA (never run in production)
-- All demo accounts use password  Demo@1234   and Health Passport PIN  1234
-- Demo OTP in development (OTP_DEV_BYPASS=true):  123456
-- =====================================================================
BEGIN;

-- ------------------------------------------------ service catalog (prices from Developer Guide v1.0)
INSERT INTO services (category, code, name_en, name_ur, description, icon_key, from_price_pkr, min_price_pkr, max_price_pkr, duration_hours, professional_types, phase) VALUES
('NURSE','NURSE_HOME_VISIT','Home Visit Nurse','ہوم وزٹ نرس','Short visits: injections, wound care, drips, catheter care','syringe',800,600,2500,NULL,'{HOME_VISIT_NURSE,STUDENT_NURSE,INTERN_NURSE,CNA}',1),
('NURSE','NURSE_DEDICATED','Dedicated Nurse','ڈیڈیکیٹڈ نرس','Continuous care for 8, 12 or 24 hours','user-medical',2500,2000,9000,'{8,12,24}','{DEDICATED_NURSE}',1),
('NURSE','NURSE_HOSPITAL_COMPANION','Hospital Companion','ہسپتال کمپینین','A registered nurse stays with the patient inside the hospital','hospital',2000,1500,6000,NULL,'{HOSPITAL_COMPANION_NURSE}',1),
('NURSE','NURSE_HOSPITAL_NAVIGATOR','Hospital Navigator','ہسپتال نیویگیٹر','Guides families through government hospital systems','navigation',1500,1000,4000,NULL,'{HOSPITAL_NAVIGATOR}',1),
('DOCTOR','DOC_GP_HOME_VISIT','GP Home Visit','جی پی ہوم وزٹ','General physician visits your home','stethoscope',1200,1000,4000,NULL,'{GP}',1),
('DOCTOR','DOC_SPECIALIST_ONLINE','Specialist Online Consultation','اسپیشلسٹ آن لائن مشاورت','Video or audio consultation with a specialist','video',1500,1000,6000,NULL,'{SPECIALIST}',1),
('LAB_TEST','LAB_HOME_COLLECTION','Lab Test — Home Collection','لیب ٹیسٹ','Sample collection at home, results in your Health Passport','flask',500,300,5000,NULL,'{MLT}',3),
('MEDICINE','MED_DELIVERY','Medicine Delivery','ادویات کی ڈیلیوری','Order from partner pharmacies','pill',50,50,150,NULL,'{}',3),
('EQUIPMENT','EQ_RENTAL','Equipment Rental','سامان کرایہ پر','Wheelchairs, oxygen concentrators, hospital beds','wheelchair',1000,500,8000,NULL,'{}',3),
('HOSPITAL_SUPPLY','SUPPLY_KIT','Hospital Supply Kit','ہسپتال سپلائی','Gloves, gauze, dressings and other supplies','box',300,100,3000,NULL,'{}',2);

-- ------------------------------------------------ demo users
INSERT INTO users (id, role, phone, email, password_hash, full_name, status, phone_verified_at) VALUES
('00000000-0000-0000-0000-0000000000a1','ADMIN','+923000000001','admin@homigocare.test',crypt('Demo@1234',gen_salt('bf',12)),'Aun Admin','ACTIVE',now()),
('00000000-0000-0000-0000-0000000000b1','PATIENT','+923000000002','ali@homigocare.test',crypt('Demo@1234',gen_salt('bf',12)),'Ali Raza','ACTIVE',now()),
('00000000-0000-0000-0000-0000000000c1','PROFESSIONAL','+923000000003','sara@homigocare.test',crypt('Demo@1234',gen_salt('bf',12)),'Sara Khan','ACTIVE',now()),
('00000000-0000-0000-0000-0000000000c2','PROFESSIONAL','+923000000004','imran@homigocare.test',crypt('Demo@1234',gen_salt('bf',12)),'Dr. Imran Malik','ACTIVE',now()),
('00000000-0000-0000-0000-0000000000c3','PROFESSIONAL','+923000000005','hina@homigocare.test',crypt('Demo@1234',gen_salt('bf',12)),'Hina Tariq','ACTIVE',now());

INSERT INTO patients (id, account_id, full_name, hgc_id, dob, gender, blood_group, cnic_last4, profile_complete) VALUES
('00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000b1','Ali Raza','HGC-ISB-2026-00123','1994-03-12','MALE','A+','4521',true);
INSERT INTO emergency_contacts (patient_id, name, phone, relationship) VALUES ('00000000-0000-0000-0000-0000000000d1','Zainab Raza','+923001112233','SPOUSE');
INSERT INTO addresses (patient_id, label, house, street, city, zone, lat, lng, is_default) VALUES
('00000000-0000-0000-0000-0000000000d1','Home','House 14','Street 7, G-11/3','Islamabad','G-11',33.6692,72.9894,true);
INSERT INTO wallets (user_id, balance_pkr) VALUES ('00000000-0000-0000-0000-0000000000b1',5240),('00000000-0000-0000-0000-0000000000c1',0),('00000000-0000-0000-0000-0000000000c2',0);
INSERT INTO health_passports (patient_id, pin_hash, pin_set_at, allergies, conditions, medications, critical_alert) VALUES
('00000000-0000-0000-0000-0000000000d1',crypt('1234',gen_salt('bf',12)),now(),'{Penicillin}','{Type 2 Diabetes}','[{"name":"Metformin","dose":"500 mg","freq":"twice daily"}]','Penicillin allergy');

-- ------------------------------------------------ professionals: two live + approved, one waiting for admin verification
INSERT INTO professionals (user_id, professional_type, gender, bio, specialization, years_experience, languages, regulator_reg_no, hospital_name, department, verification_status, verified_at, verified_by, assessment_complete, is_live, is_online, base_lat, base_lng, rating_avg, rating_count, badges) VALUES
('00000000-0000-0000-0000-0000000000c1','HOME_VISIT_NURSE','FEMALE','Registered nurse with 6 years in ICU and home care. Calm, punctual, careful with elderly patients.','Wound care · Injections · Elderly care',6,'{Urdu,English}','PNC-1048832','Shifa International Hospital','ICU','APPROVED',now(),'00000000-0000-0000-0000-0000000000a1',true,true,true,33.6844,73.0479,4.8,47,'{CERTIFIED,TOP_RATED}'),
('00000000-0000-0000-0000-0000000000c2','GP','MALE','General physician, home visits for fever, flu, chronic disease follow-up.','General medicine',9,'{Urdu,English,Punjabi}','PMDC-77421-P','PIMS Islamabad','Medicine OPD','APPROVED',now(),'00000000-0000-0000-0000-0000000000a1',true,true,true,33.7000,73.0600,4.7,31,'{CERTIFIED}'),
('00000000-0000-0000-0000-0000000000c3','HOME_VISIT_NURSE','FEMALE','Nursing graduate seeking home-care work.','Post-surgery care',3,'{Urdu}','PNC-2207741','Holy Family Hospital','Surgical Ward','UNDER_REVIEW',NULL,NULL,false,false,false,33.6007,73.0679,0,0,'{}');

INSERT INTO professional_services (professional_id, service_id, price_pkr)
SELECT '00000000-0000-0000-0000-0000000000c1', id, 1200 FROM services WHERE code='NURSE_HOME_VISIT';
INSERT INTO professional_services (professional_id, service_id, price_pkr)
SELECT '00000000-0000-0000-0000-0000000000c2', id, 1500 FROM services WHERE code='DOC_GP_HOME_VISIT';
INSERT INTO availability_rules (professional_id, weekday, start_time, end_time)
SELECT p, d, '09:00', '20:00' FROM (VALUES ('00000000-0000-0000-0000-0000000000c1'::uuid),('00000000-0000-0000-0000-0000000000c2'::uuid)) v(p), generate_series(0,6) d;

-- pending professional's uploaded documents (storage keys are fake in seed)
INSERT INTO documents (owner_user_id, doc_type, storage_key, mime, size_bytes) VALUES
('00000000-0000-0000-0000-0000000000c3','CNIC_FRONT','seed/c3/cnic_front.jpg','image/jpeg',120000),
('00000000-0000-0000-0000-0000000000c3','CNIC_BACK','seed/c3/cnic_back.jpg','image/jpeg',118000),
('00000000-0000-0000-0000-0000000000c3','REGULATOR_REGISTRATION','seed/c3/pnc.pdf','application/pdf',340000),
('00000000-0000-0000-0000-0000000000c3','DEGREE','seed/c3/degree.pdf','application/pdf',410000),
('00000000-0000-0000-0000-0000000000c3','EXPERIENCE_LETTER','seed/c3/experience.pdf','application/pdf',210000),
('00000000-0000-0000-0000-0000000000c3','CHARACTER_CERT','seed/c3/character.pdf','application/pdf',90000),
('00000000-0000-0000-0000-0000000000c3','PROFILE_PHOTO','seed/c3/photo.jpg','image/jpeg',80000);
INSERT INTO verification_events (professional_id, from_status, to_status, reason) VALUES
('00000000-0000-0000-0000-0000000000c3','DRAFT','SUBMITTED','Documents submitted'),
('00000000-0000-0000-0000-0000000000c3','SUBMITTED','UNDER_REVIEW','Picked up for review');

-- ------------------------------------------------ one pending booking so the professional dashboard is never empty
INSERT INTO bookings (patient_id, booked_by, professional_id, service_id, booking_type, status, scheduled_at, address_id, address_snapshot, notes, price_visit, platform_fee, total_pkr, commission_pkr, offer_expires_at)
SELECT '00000000-0000-0000-0000-0000000000d1','00000000-0000-0000-0000-0000000000b1','00000000-0000-0000-0000-0000000000c1', s.id,'INSTANT','PENDING', now(), a.id,
 '{"house":"House 14","street":"Street 7, G-11/3","city":"Islamabad","zone":"G-11"}','Insulin injection and blood-pressure check.',1200,150,1350,180, now()+interval '2 minutes'
FROM services s, addresses a WHERE s.code='NURSE_HOME_VISIT' AND a.patient_id='00000000-0000-0000-0000-0000000000d1' LIMIT 1;
INSERT INTO booking_offers (booking_id, professional_id, expires_at) SELECT id,'00000000-0000-0000-0000-0000000000c1', now()+interval '2 minutes' FROM bookings LIMIT 1;

-- ------------------------------------------------ SAMPLE assessment questions (NOT clinically validated — replace with a reviewed bank)
INSERT INTO assessment_questions (phase, text_en, text_ur, options, correct_index, explanation) VALUES
('P1_KNOWLEDGE','What is the first step before giving any injection?','کسی بھی انجکشن سے پہلے پہلا قدم کیا ہے؟','["Wash hands and verify the patient and the order","Choose the needle size","Ask the family to hold the patient","Clean the vial with water"]',0,'Hand hygiene and patient/order verification come first.'),
('P1_KNOWLEDGE','A normal adult resting pulse is usually:','بالغ فرد کی نارمل نبض عموماً کتنی ہوتی ہے؟','["20–40 bpm","60–100 bpm","120–160 bpm","160–200 bpm"]',1,'Typical adult resting heart rate is 60–100 bpm.'),
('P1_KNOWLEDGE','Which of these should be documented after every home visit?','ہر ہوم وزٹ کے بعد کیا لکھنا ضروری ہے؟','["Only the payment","Care given, observations and vitals","Only the patient name","Nothing if the patient was fine"]',1,'Accurate visit notes protect the patient and the professional.'),
('P1_KNOWLEDGE','Used needles must be disposed of in:','استعمال شدہ سوئیاں کہاں پھینکنی چاہئیں؟','["A regular dustbin","A puncture-resistant sharps container","The sink","A paper bag"]',1,'Sharps containers prevent needle-stick injuries.'),
('P1_KNOWLEDGE','A patient reports sudden chest pain and sweating. You should:','مریض کو اچانک سینے میں درد اور پسینہ آئے تو آپ کیا کریں؟','["Wait and observe for an hour","Treat it as an emergency and call for emergency help","Give a sleeping tablet","Ask them to walk"]',1,'Possible cardiac emergency — escalate immediately.'),
('P1_KNOWLEDGE','The best way to confirm a patient''s identity is:','مریض کی شناخت کا بہترین طریقہ کیا ہے؟','["Use two identifiers such as name and date of birth","Use the room number","Ask the neighbour","Guess from the file"]',0,'Two identifiers reduce errors.'),
('P2_PRACTICAL','You arrive and the patient''s BP is 190/110 with a severe headache. What do you do?','آپ پہنچیں تو مریض کا بی پی 190/110 ہو اور شدید سر درد ہو، آپ کیا کریں گے؟','["Continue the routine task and leave","Stop, recheck, escalate to a doctor/emergency care and document","Give extra medicine from your bag","Reschedule for next week"]',1,'Red-flag vitals require escalation and documentation.'),
('P2_PRACTICAL','The patient''s family asks you to skip hand hygiene because they are in a hurry.','مریض کے گھر والے جلدی میں آپ سے ہاتھ دھوئے بغیر کام کرنے کو کہیں۔','["Agree to save time","Politely explain and follow infection-control steps","Leave without telling anyone","Use perfume instead"]',1,'Infection control is non-negotiable.'),
('P2_PRACTICAL','A wound dressing has heavy yellow-green discharge and a bad smell. This most likely suggests:','زخم کی پٹی پر گاڑھا پیلا سبز رطوبت اور بدبو ہو تو اس کا امکان کیا ہے؟','["Normal healing","Possible infection — report to the doctor","Dry skin","Allergy to soap only"]',1,'Signs of infection need clinical review.'),
('P3_ETHICS','A patient asks you to share their lab report with a neighbour.','مریض آپ سے کہے کہ لیب رپورٹ پڑوسی کو دکھا دیں۔','["Share it, they asked","Refuse; only share with the patient''s own consent through the app","Post it in a group","Photograph it for later"]',1,'Patient privacy is protected; consent flows through the app.'),
('P3_ETHICS','You are offered extra cash to visit outside the app.','آپ کو ایپ سے باہر وزٹ کرنے کے لیے اضافی رقم کی پیشکش ہو۔','["Accept; it is private","Decline: bookings must go through HomiGo Care","Accept but tell nobody","Ask for double"]',1,'Off-platform bookings break safety, insurance and trust.'),
('P3_ETHICS','A patient is rude but not in danger. You should:','مریض بدتمیزی کرے مگر خطرے میں نہ ہو تو آپ کیا کریں؟','["Shout back","Stay professional, complete the safe parts of care, and report the issue","Take photos and post them","Leave without documenting"]',1,'Professionalism and reporting protect everyone.');

COMMIT;
