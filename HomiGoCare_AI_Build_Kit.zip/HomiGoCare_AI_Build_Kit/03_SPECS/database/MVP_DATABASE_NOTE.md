# Database scope note — MVP

The original `schema.sql` and `seed.sql` are retained as technical references from the full-platform blueprint. They may contain tables for deferred roles and features. Do not implement or expose those tables in the MVP UI merely because they exist.

For the MVP, the required domain data is limited to:
- User/auth and role (Patient, Doctor, Nurse, Admin)
- Professional profile, documents metadata, verification status
- Booking and status transitions
- Minimal synthetic Health Passport data
- Booking-scoped authorization/grant and access events
- SOS alert and Admin response status

If the current schema is too broad, prefer using a minimal migration or the existing subset rather than deleting useful reference SQL. Ensure API authorization and UI are consistent.
