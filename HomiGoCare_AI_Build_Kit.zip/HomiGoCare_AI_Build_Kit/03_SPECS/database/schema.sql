-- =====================================================================
-- HomiGo Care — PostgreSQL 16 schema (single source of truth)
-- Tested: loads cleanly on PostgreSQL 16 with an empty database.
-- Conventions: uuid PKs (gen_random_uuid), timestamptz, snake_case,
-- money = numeric(12,2) in PKR, soft-delete via status, append-only logs.
-- Sensitive columns are encrypted BY THE APP (AES-256-GCM, key in KMS/Secrets Manager)
-- and stored as bytea: patients.cnic_enc, health_records.body_enc, admin_totp.secret_enc.
-- =====================================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- crypt()/gen_salt() for seed data only

-- ---------------------------------------------------------------- ENUMS
CREATE TYPE user_role AS ENUM ('PATIENT','PROFESSIONAL','ADMIN','VERIFICATION_OFFICER','FIELD_SUPERVISOR','SUPPORT_AGENT','LAB_PARTNER','PHARMACY_PARTNER');
CREATE TYPE account_status AS ENUM ('PENDING','ACTIVE','SUSPENDED','DELETION_PENDING','DELETED');
CREATE TYPE gender AS ENUM ('MALE','FEMALE','OTHER');
CREATE TYPE professional_type AS ENUM (
  'HOME_VISIT_NURSE','DEDICATED_NURSE','HOSPITAL_COMPANION_NURSE','STUDENT_NURSE','INTERN_NURSE','CNA',
  'CMW','LHV','MLT','PHYSIOTHERAPIST','OCCUPATIONAL_THERAPIST','GP','SPECIALIST',
  'SPEECH_THERAPIST','RESPIRATORY_THERAPIST','PSYCHOLOGIST','NUTRITIONIST','PALLIATIVE_NURSE',
  'VACCINATION_SPECIALIST','HOME_HEALTH_AIDE','AMBULANCE_DRIVER','HOSPITAL_NAVIGATOR');
CREATE TYPE verification_status AS ENUM ('DRAFT','SUBMITTED','UNDER_REVIEW','APPROVED','REJECTED','ACTION_REQUIRED','SUSPENDED');
CREATE TYPE document_type AS ENUM ('CNIC_FRONT','CNIC_BACK','PROFILE_PHOTO','REGULATOR_REGISTRATION','DEGREE','EXPERIENCE_LETTER','CHARACTER_CERT','AFFILIATION_LETTER','SPECIALTY_CERT','STUDENT_ID','PRESCRIPTION','LAB_REPORT','DISCHARGE_SUMMARY','RECEIPT','VOICE_NOTE','OTHER');
CREATE TYPE doc_review_status AS ENUM ('PENDING','ACCEPTED','REJECTED');
CREATE TYPE service_category AS ENUM ('NURSE','DOCTOR','LAB_TEST','MEDICINE','EQUIPMENT','HOSPITAL_SUPPLY');
CREATE TYPE booking_type AS ENUM ('INSTANT','SCHEDULED','RECURRING','ONLINE');
CREATE TYPE booking_status AS ENUM ('PENDING','ACCEPTED','DECLINED','ON_THE_WAY','ARRIVED','IN_PROGRESS','COMPLETED','CANCELLED','EXPIRED');
CREATE TYPE offer_status AS ENUM ('OFFERED','ACCEPTED','DECLINED','EXPIRED');
CREATE TYPE payment_method AS ENUM ('WALLET','JAZZCASH','EASYPAISA','CASH','BANK_TRANSFER','CARD','SANDBOX');
CREATE TYPE payment_status AS ENUM ('INITIATED','SUCCESS','FAILED','REFUNDED');
CREATE TYPE sos_status AS ENUM ('ACTIVE','ACKNOWLEDGED','RESPONDING','ESCALATED','RESOLVED','FALSE_ALARM');
CREATE TYPE sos_source AS ENUM ('APP_ONLINE','SMS_RELAY','ADMIN_CREATED');
CREATE TYPE dispute_status AS ENUM ('OPEN','IN_PROGRESS','ESCALATED','RESOLVED','CLOSED');
CREATE TYPE priority_level AS ENUM ('LOW','MEDIUM','HIGH','URGENT');
CREATE TYPE assessment_phase AS ENUM ('P1_KNOWLEDGE','P2_PRACTICAL','P3_ETHICS');
CREATE TYPE health_record_kind AS ENUM ('VISIT_NOTE','PRESCRIPTION','LAB_RESULT','DISCHARGE_SUMMARY','CONSULTATION','OTHER');
CREATE TYPE vital_kind AS ENUM ('BLOOD_PRESSURE','BLOOD_SUGAR','WEIGHT','TEMPERATURE','PULSE','SPO2');
CREATE TYPE supply_status AS ENUM ('REQUESTED','APPROVED','CHANGES_REQUESTED','DECLINED');
CREATE TYPE partner_kind AS ENUM ('LAB','PHARMACY');
CREATE TYPE order_status AS ENUM ('PLACED','CONFIRMED','COLLECTED','OUT_FOR_DELIVERY','DELIVERED','RESULTS_READY','CANCELLED');

-- ---------------------------------------------------------------- GENERIC HELPERS
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION '% on % is not allowed: table is append-only', TG_OP, TG_TABLE_NAME; END $$;

-- ---------------------------------------------------------------- IDENTITY & AUTH
CREATE TABLE users (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role             user_role NOT NULL,
  phone            text UNIQUE CHECK (phone ~ '^\+92[0-9]{10}$'),
  email            text UNIQUE,
  password_hash    text NOT NULL,                      -- bcrypt, cost >= 12
  full_name        text NOT NULL,
  status           account_status NOT NULL DEFAULT 'PENDING',
  locale           text NOT NULL DEFAULT 'en' CHECK (locale IN ('en','ur')),
  phone_verified_at timestamptz,
  last_login_at    timestamptz,
  deletion_requested_at timestamptz,                   -- 30-day cooling period
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (phone IS NOT NULL OR email IS NOT NULL)
);
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX idx_users_role_status ON users(role, status);

CREATE TABLE otp_codes (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone       text NOT NULL,
  purpose     text NOT NULL CHECK (purpose IN ('SIGNUP','LOGIN','RESET_PASSWORD','ADMIN_2FA')),
  code_hash   text NOT NULL,
  attempts    smallint NOT NULL DEFAULT 0,             -- 3 wrong attempts => locked
  expires_at  timestamptz NOT NULL,                    -- created_at + 10 minutes
  consumed_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_otp_phone_created ON otp_codes(phone, created_at DESC);

CREATE TABLE refresh_tokens (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  device_id  text,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  replaced_by uuid REFERENCES refresh_tokens(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_refresh_user ON refresh_tokens(user_id) WHERE revoked_at IS NULL;

CREATE TABLE devices (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform   text NOT NULL DEFAULT 'android',
  fcm_token  text NOT NULL UNIQUE,
  app        text NOT NULL CHECK (app IN ('patient','professional','admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE admin_totp (
  user_id    uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  secret_enc bytea NOT NULL,
  enabled    boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- PATIENTS (profile rows; Family Account Manager = many rows per account)
CREATE TABLE patients (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  is_primary    boolean NOT NULL DEFAULT true,
  relation      text NOT NULL DEFAULT 'SELF',
  full_name     text NOT NULL,
  hgc_id        text UNIQUE,                            -- e.g. HGC-ISB-2026-00123
  dob           date,
  gender        gender,
  blood_group   text CHECK (blood_group IN ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  cnic_enc      bytea,                                  -- AES-GCM encrypted CNIC
  cnic_last4    text,
  profile_complete boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_patient_primary ON patients(account_id) WHERE is_primary;
CREATE TRIGGER trg_patients_updated BEFORE UPDATE ON patients FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE emergency_contacts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id   uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  name         text NOT NULL,
  phone        text NOT NULL CHECK (phone ~ '^\+92[0-9]{10}$'),
  relationship text NOT NULL CHECK (relationship IN ('SPOUSE','PARENT','SIBLING','CHILD','FRIEND','OTHER')),
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE addresses (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  label      text NOT NULL DEFAULT 'Home',
  house      text NOT NULL,
  street     text NOT NULL,
  city       text NOT NULL CHECK (city IN ('Islamabad','Rawalpindi')),
  zone       text,                                      -- e.g. G-11, Bahria Town
  lat        double precision, lng double precision,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_addr_patient ON addresses(patient_id);

-- ---------------------------------------------------------------- DOCUMENTS (private storage keys only — never public URLs)
CREATE TABLE documents (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doc_type      document_type NOT NULL,
  storage_key   text NOT NULL UNIQUE,                   -- s3://bucket/{userId}/{docId}; served via short-lived signed URL
  mime          text NOT NULL,
  size_bytes    integer NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 10485760),
  review_status doc_review_status NOT NULL DEFAULT 'PENDING',
  reviewer_note text,
  reviewed_by   uuid REFERENCES users(id),
  reviewed_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_documents_owner ON documents(owner_user_id, doc_type);

-- ---------------------------------------------------------------- PROFESSIONALS
CREATE TABLE professionals (
  user_id            uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  professional_type  professional_type NOT NULL,
  scope_label        text CHECK (scope_label IN ('STUDENT','INTERN','CNA')),   -- shown on public profile for limited-scope roles
  gender             gender,
  bio                text,
  specialization     text,
  years_experience   smallint CHECK (years_experience BETWEEN 0 AND 60),
  languages          text[] NOT NULL DEFAULT '{}',
  regulator_reg_no   text,                              -- PNC / PMDC / etc.
  hospital_name      text,                              -- MUST be current affiliation (guide rule)
  department         text,
  verification_status verification_status NOT NULL DEFAULT 'DRAFT',
  verification_note  text,
  verified_at        timestamptz,
  verified_by        uuid REFERENCES users(id),
  assessment_complete boolean NOT NULL DEFAULT false,
  is_live            boolean NOT NULL DEFAULT false,    -- set by "Go Live" (PR-19) only after approval + assessment
  is_online          boolean NOT NULL DEFAULT false,
  base_lat           double precision, base_lng double precision,
  service_radius_km  numeric(5,1) NOT NULL DEFAULT 15,
  rating_avg         numeric(3,2) NOT NULL DEFAULT 0,
  rating_count       integer NOT NULL DEFAULT 0,
  badges             text[] NOT NULL DEFAULT '{}',      -- CERTIFIED, TOP_RATED, ELITE
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT is_live OR (verification_status = 'APPROVED' AND assessment_complete))
);
CREATE INDEX idx_prof_discovery ON professionals(professional_type, is_live, is_online) WHERE is_live;
CREATE TRIGGER trg_prof_updated BEFORE UPDATE ON professionals FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE verification_events (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id uuid NOT NULL REFERENCES professionals(user_id) ON DELETE CASCADE,
  from_status     verification_status,
  to_status       verification_status NOT NULL,
  actor_id        uuid REFERENCES users(id),
  reason          text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_verif_prof ON verification_events(professional_id, created_at DESC);

CREATE TABLE availability_rules (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id uuid NOT NULL REFERENCES professionals(user_id) ON DELETE CASCADE,
  weekday         smallint NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_time      time NOT NULL, end_time time NOT NULL,
  break_start     time, break_end time,
  CHECK (end_time > start_time)
);
CREATE INDEX idx_avail_prof ON availability_rules(professional_id, weekday);

-- ---------------------------------------------------------------- CERTIFICATION ASSESSMENT
CREATE TABLE assessment_questions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phase         assessment_phase NOT NULL,
  professional_type professional_type,                  -- null = all types
  text_en       text NOT NULL,
  text_ur       text,
  options       jsonb NOT NULL,                         -- ["A text","B text","C text","D text"]
  correct_index smallint NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
  explanation   text,
  active        boolean NOT NULL DEFAULT true
);
CREATE INDEX idx_aq_phase ON assessment_questions(phase) WHERE active;

CREATE TABLE assessment_attempts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id uuid NOT NULL REFERENCES professionals(user_id) ON DELETE CASCADE,
  phase           assessment_phase NOT NULL,
  attempt_no      smallint NOT NULL CHECK (attempt_no BETWEEN 1 AND 3),
  question_ids    uuid[] NOT NULL,
  answers         jsonb NOT NULL DEFAULT '{}',          -- {questionId: selectedIndex} auto-saved per selection
  started_at      timestamptz NOT NULL DEFAULT now(),
  deadline_at     timestamptz NOT NULL,                 -- server enforces timer
  submitted_at    timestamptz,
  score_pct       numeric(5,2),
  passed          boolean,
  next_retry_at   timestamptz,                          -- 7-day cooling period after a fail
  UNIQUE (professional_id, phase, attempt_no)
);

-- ---------------------------------------------------------------- SERVICE CATALOG
CREATE TABLE services (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category        service_category NOT NULL,
  code            text NOT NULL UNIQUE,
  name_en         text NOT NULL, name_ur text,
  description     text,
  icon_key        text NOT NULL,                        -- name from icons.json
  from_price_pkr  numeric(10,2) NOT NULL,
  min_price_pkr   numeric(10,2) NOT NULL, max_price_pkr numeric(10,2) NOT NULL,
  duration_hours  smallint[] ,                          -- e.g. {8,12,24} for Dedicated Nurse
  professional_types professional_type[] NOT NULL DEFAULT '{}',
  phase           smallint NOT NULL DEFAULT 1,
  active          boolean NOT NULL DEFAULT true,
  CHECK (min_price_pkr <= max_price_pkr)
);
CREATE TABLE professional_services (
  professional_id uuid NOT NULL REFERENCES professionals(user_id) ON DELETE CASCADE,
  service_id      uuid NOT NULL REFERENCES services(id),
  price_pkr       numeric(10,2) NOT NULL,               -- validated against services.min/max
  active          boolean NOT NULL DEFAULT true,
  PRIMARY KEY (professional_id, service_id)
);

-- ---------------------------------------------------------------- BOOKINGS
CREATE SEQUENCE booking_ref_seq START 1;
CREATE TABLE bookings (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference        text NOT NULL UNIQUE DEFAULT ('HGC-' || to_char(now(),'YYYY') || '-' || lpad(nextval('booking_ref_seq')::text, 5, '0')),
  patient_id       uuid NOT NULL REFERENCES patients(id),
  booked_by        uuid NOT NULL REFERENCES users(id),
  professional_id  uuid REFERENCES professionals(user_id),
  service_id       uuid NOT NULL REFERENCES services(id),
  booking_type     booking_type NOT NULL,
  status           booking_status NOT NULL DEFAULT 'PENDING',
  scheduled_at     timestamptz,
  duration_hours   smallint,
  address_id       uuid REFERENCES addresses(id),
  address_snapshot jsonb,                               -- immutable copy at booking time
  notes            text,
  voice_note_doc_id uuid REFERENCES documents(id),
  extras           jsonb NOT NULL DEFAULT '{}',         -- {labTest:true, medicineDelivery:false, equipmentRental:false}
  consent_scope    jsonb NOT NULL DEFAULT '{"healthPassport":"NONE"}',   -- MVP consent/skip bridge
  price_visit      numeric(10,2) NOT NULL DEFAULT 0,
  price_supplies   numeric(10,2) NOT NULL DEFAULT 0,
  price_lab        numeric(10,2) NOT NULL DEFAULT 0,
  price_medicine   numeric(10,2) NOT NULL DEFAULT 0,
  platform_fee     numeric(10,2) NOT NULL DEFAULT 0,
  cashback_discount numeric(10,2) NOT NULL DEFAULT 0,
  total_pkr        numeric(10,2) NOT NULL DEFAULT 0,
  commission_pkr   numeric(10,2) NOT NULL DEFAULT 0,    -- 15% professional commission snapshot
  offer_expires_at timestamptz,
  accepted_at timestamptz, started_at timestamptz, completed_at timestamptz,
  cancelled_at timestamptz, cancel_reason text, cancelled_by uuid REFERENCES users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CHECK (total_pkr >= 0),
  CHECK (booking_type <> 'SCHEDULED' OR scheduled_at IS NOT NULL)
);
CREATE INDEX idx_bookings_patient ON bookings(patient_id, created_at DESC);
CREATE INDEX idx_bookings_prof ON bookings(professional_id, status, scheduled_at);
CREATE INDEX idx_bookings_status ON bookings(status, created_at DESC);
CREATE TRIGGER trg_bookings_updated BEFORE UPDATE ON bookings FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE booking_offers (   -- "limited time to accept before it goes to the next professional"
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id      uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  professional_id uuid NOT NULL REFERENCES professionals(user_id),
  status          offer_status NOT NULL DEFAULT 'OFFERED',
  offered_at      timestamptz NOT NULL DEFAULT now(),
  expires_at      timestamptz NOT NULL,
  responded_at    timestamptz,
  decline_reason  text,
  UNIQUE (booking_id, professional_id)
);
CREATE INDEX idx_offers_prof ON booking_offers(professional_id, status, expires_at);

CREATE TABLE booking_events (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  status     booking_status NOT NULL,
  actor_id   uuid REFERENCES users(id),
  meta       jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_bevents ON booking_events(booking_id, created_at);

CREATE TABLE booking_checklist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  label text NOT NULL, done boolean NOT NULL DEFAULT false, done_at timestamptz
);

CREATE TABLE supply_requests (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id  uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  status      supply_status NOT NULL DEFAULT 'REQUESTED',
  items       jsonb NOT NULL,                           -- [{name, qty, pricePkr}]
  subtotal    numeric(10,2) NOT NULL,
  receipt_doc_id uuid REFERENCES documents(id),
  created_at  timestamptz NOT NULL DEFAULT now(), decided_at timestamptz
);

-- ---------------------------------------------------------------- PAYMENTS & WALLET
CREATE TABLE payments (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id      uuid NOT NULL REFERENCES bookings(id),
  payer_id        uuid NOT NULL REFERENCES users(id),
  method          payment_method NOT NULL,
  status          payment_status NOT NULL DEFAULT 'INITIATED',
  amount_pkr      numeric(10,2) NOT NULL CHECK (amount_pkr >= 0),
  provider_ref    text,
  idempotency_key text NOT NULL UNIQUE,                 -- retry never double-charges / duplicates a booking
  failure_reason  text,
  created_at      timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER trg_payments_updated BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE wallets (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  balance_pkr numeric(12,2) NOT NULL DEFAULT 0 CHECK (balance_pkr >= 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  kind text NOT NULL CHECK (kind IN ('CREDIT','DEBIT')),
  amount_pkr numeric(12,2) NOT NULL CHECK (amount_pkr > 0),
  reason text NOT NULL,                                 -- BOOKING, REVIEW_CASHBACK, REFERRAL, TOPUP, WITHDRAWAL, EARNING
  ref_type text, ref_id uuid,
  balance_after numeric(12,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_wtx_user ON wallet_transactions(user_id, created_at DESC);

-- ---------------------------------------------------------------- REVIEWS
CREATE TABLE reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL UNIQUE REFERENCES bookings(id),
  patient_id uuid NOT NULL REFERENCES patients(id),
  professional_id uuid NOT NULL REFERENCES professionals(user_id),
  punctuality smallint NOT NULL CHECK (punctuality BETWEEN 1 AND 5),
  professionalism smallint NOT NULL CHECK (professionalism BETWEEN 1 AND 5),
  medical_skill smallint NOT NULL CHECK (medical_skill BETWEEN 1 AND 5),
  communication smallint NOT NULL CHECK (communication BETWEEN 1 AND 5),
  overall smallint NOT NULL CHECK (overall BETWEEN 1 AND 5),
  body text, anonymous boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_prof ON reviews(professional_id, created_at DESC);

-- ---------------------------------------------------------------- HEALTH PASSPORT (patient-controlled)
CREATE TABLE health_passports (
  patient_id           uuid PRIMARY KEY REFERENCES patients(id) ON DELETE CASCADE,
  pin_hash             text,                            -- bcrypt of 4-digit PIN + per-user pepper; NEVER stored plain
  pin_set_at           timestamptz,
  pin_failed_attempts  smallint NOT NULL DEFAULT 0,
  pin_locked_until     timestamptz,                     -- lockout after 5 wrong tries (backoff)
  allergies            text[] NOT NULL DEFAULT '{}',
  conditions           text[] NOT NULL DEFAULT '{}',
  medications          jsonb NOT NULL DEFAULT '[]',
  critical_alert       text,
  updated_at           timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE health_records (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id   uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  kind         health_record_kind NOT NULL,
  booking_id   uuid REFERENCES bookings(id),
  author_id    uuid REFERENCES users(id),
  title        text NOT NULL,
  body_enc     bytea,                                   -- AES-GCM encrypted free text
  document_id  uuid REFERENCES documents(id),
  flagged      boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_hrec_patient ON health_records(patient_id, created_at DESC);
CREATE TABLE vitals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  kind vital_kind NOT NULL, value1 numeric(7,2) NOT NULL, value2 numeric(7,2), unit text NOT NULL,
  measured_at timestamptz NOT NULL DEFAULT now(), recorded_by uuid REFERENCES users(id)
);
CREATE INDEX idx_vitals_patient ON vitals(patient_id, kind, measured_at DESC);

CREATE TABLE access_grants (   -- created ONLY when the patient enters the PIN for a specific booking
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  professional_id uuid NOT NULL REFERENCES professionals(user_id),
  booking_id      uuid NOT NULL REFERENCES bookings(id),
  scope           text[] NOT NULL DEFAULT '{BASIC}',    -- BASIC, HISTORY, LABS, PRESCRIPTIONS, VITALS
  granted_at      timestamptz NOT NULL DEFAULT now(),
  expires_at      timestamptz NOT NULL,                 -- default: end of visit, max 24h
  revoked_at      timestamptz
);
CREATE INDEX idx_grants_lookup ON access_grants(professional_id, patient_id, expires_at) WHERE revoked_at IS NULL;

CREATE TABLE access_logs (   -- IMMUTABLE: patient can view; nobody can edit/delete
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL, professional_id uuid, booking_id uuid, grant_id uuid,
  actor_id uuid NOT NULL, actor_role user_role NOT NULL,
  action text NOT NULL,                                 -- GRANT, VIEW_OVERVIEW, VIEW_HISTORY, VIEW_DOCUMENT, REVOKE, DENIED, PIN_FAILED
  resource text, ip inet, user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_access_patient ON access_logs(patient_id, created_at DESC);
CREATE TRIGGER trg_access_logs_immutable BEFORE UPDATE OR DELETE ON access_logs FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- ---------------------------------------------------------------- EMERGENCY / SOS
CREATE TABLE sos_alerts (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patients(id),
  triggered_by    uuid NOT NULL REFERENCES users(id),
  booking_id      uuid REFERENCES bookings(id),
  status          sos_status NOT NULL DEFAULT 'ACTIVE',
  source          sos_source NOT NULL DEFAULT 'APP_ONLINE',
  triggered_at    timestamptz NOT NULL DEFAULT now(),
  lat double precision, lng double precision, accuracy_m real, location_at timestamptz,
  network_info    jsonb NOT NULL DEFAULT '{}',          -- ONLY what the device actually reported (connectivity type, battery)
  message         text,
  acknowledged_by uuid REFERENCES users(id), acknowledged_at timestamptz,
  resolved_by     uuid REFERENCES users(id), resolved_at timestamptz, resolution_note text
);
CREATE INDEX idx_sos_open ON sos_alerts(status, triggered_at DESC) WHERE status IN ('ACTIVE','ACKNOWLEDGED','RESPONDING','ESCALATED');
CREATE TABLE sos_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sos_id uuid NOT NULL REFERENCES sos_alerts(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('CREATED','LOCATION_UPDATE','ACKNOWLEDGED','NOTE','CONTACT_ATTEMPT','ESCALATED','RESOLVED','FALSE_ALARM')),
  actor_id uuid REFERENCES users(id), note text, data jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_sosev ON sos_events(sos_id, created_at);

-- ---------------------------------------------------------------- DISPUTES / SUPPORT
CREATE SEQUENCE ticket_seq START 1;
CREATE TABLE disputes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_no text NOT NULL UNIQUE DEFAULT ('TKT-' || lpad(nextval('ticket_seq')::text, 5, '0')),
  booking_id uuid REFERENCES bookings(id), reporter_id uuid NOT NULL REFERENCES users(id),
  against_user_id uuid REFERENCES users(id),
  category text NOT NULL CHECK (category IN ('NO_SHOW','QUALITY','BILLING','SAFETY','CONDUCT','APP_ISSUE','OTHER')),
  priority priority_level NOT NULL DEFAULT 'MEDIUM', status dispute_status NOT NULL DEFAULT 'OPEN',
  description text NOT NULL, assigned_to uuid REFERENCES users(id), resolution text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz
);
CREATE INDEX idx_disputes_status ON disputes(status, priority, created_at DESC);
CREATE TRIGGER trg_disputes_updated BEFORE UPDATE ON disputes FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TABLE dispute_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dispute_id uuid NOT NULL REFERENCES disputes(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES users(id), note text NOT NULL, internal boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- NOTIFICATIONS
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL,           -- BOOKING_REQUEST, BOOKING_ACCEPTED, VERIFICATION_RESULT, SOS_ALERT, PAYMENT, SYSTEM ...
  title text NOT NULL, body text NOT NULL, data jsonb NOT NULL DEFAULT '{}',
  read_at timestamptz, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_notif_user ON notifications(user_id, read_at, created_at DESC);

-- ---------------------------------------------------------------- AUDIT (append-only)
CREATE TABLE audit_logs (
  id bigserial PRIMARY KEY,
  actor_id uuid, actor_role user_role, action text NOT NULL,       -- e.g. PROFESSIONAL_APPROVED, USER_SUSPENDED, SOS_RESOLVED
  entity_type text NOT NULL, entity_id text, before jsonb, after jsonb, reason text,
  ip inet, user_agent text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id, created_at DESC);
CREATE INDEX idx_audit_actor ON audit_logs(actor_id, created_at DESC);
CREATE TRIGGER trg_audit_immutable BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- ---------------------------------------------------------------- PHASE 3 TABLES (created now so migrations stay linear)
CREATE TABLE referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES users(id), referred_id uuid UNIQUE REFERENCES users(id),
  code text NOT NULL, reward_pkr numeric(10,2) NOT NULL DEFAULT 300, rewarded_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE partners (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), kind partner_kind NOT NULL, name text NOT NULL,
  contact_user_id uuid REFERENCES users(id), commission_pct numeric(4,1) NOT NULL, active boolean NOT NULL DEFAULT true
);
CREATE TABLE lab_tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), partner_id uuid NOT NULL REFERENCES partners(id),
  name text NOT NULL, category text NOT NULL, price_pkr numeric(10,2) NOT NULL, home_collection boolean NOT NULL DEFAULT true
);
CREATE TABLE lab_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), patient_id uuid NOT NULL REFERENCES patients(id),
  partner_id uuid NOT NULL REFERENCES partners(id), booking_id uuid REFERENCES bookings(id),
  test_ids uuid[] NOT NULL, status order_status NOT NULL DEFAULT 'PLACED', result_doc_id uuid REFERENCES documents(id),
  total_pkr numeric(10,2) NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE medicine_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), patient_id uuid NOT NULL REFERENCES patients(id),
  partner_id uuid REFERENCES partners(id), items jsonb NOT NULL, prescription_doc_id uuid REFERENCES documents(id),
  delivery_type text NOT NULL CHECK (delivery_type IN ('STANDARD','EXPRESS','EMERGENCY')),
  delivery_fee_pkr numeric(10,2) NOT NULL DEFAULT 0, total_pkr numeric(10,2) NOT NULL,
  status order_status NOT NULL DEFAULT 'PLACED', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE feature_flags (key text PRIMARY KEY, enabled boolean NOT NULL DEFAULT false, config jsonb NOT NULL DEFAULT '{}', updated_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE waitlist_signups (   -- marketing website
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text, email text, phone text,
  audience text NOT NULL CHECK (audience IN ('PATIENT','PROFESSIONAL','PARTNER','OTHER')), city text, source text,
  consent boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------- ADMIN DASHBOARD VIEW (GET /admin/stats)
CREATE VIEW v_admin_kpis AS
SELECT
  (SELECT count(*) FROM users WHERE role='PATIENT' AND status='ACTIVE')                                   AS active_patients,
  (SELECT count(*) FROM professionals WHERE verification_status='APPROVED')                              AS verified_professionals,
  (SELECT count(*) FROM professionals WHERE verification_status IN ('SUBMITTED','UNDER_REVIEW'))         AS pending_verifications,
  (SELECT count(*) FROM bookings WHERE status IN ('PENDING','ACCEPTED','ON_THE_WAY','ARRIVED','IN_PROGRESS')) AS active_bookings,
  (SELECT count(*) FROM bookings WHERE status='COMPLETED')                                               AS completed_bookings,
  (SELECT count(*) FROM sos_alerts WHERE status IN ('ACTIVE','ACKNOWLEDGED','RESPONDING','ESCALATED'))    AS open_sos,
  (SELECT count(*) FROM disputes WHERE status IN ('OPEN','IN_PROGRESS','ESCALATED'))                      AS open_disputes;
