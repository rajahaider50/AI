# MVP conversion notes

This archive is a scope-adjusted version of the original HomiGo Care AI Build Kit.

## Updated as authoritative MVP content
- `00_START_HERE.md`
- `AI_MASTER_PROMPT.md`
- `MVP_SCOPE.md`
- `03_SPECS/docs/DECISIONS.md`
- `03_SPECS/docs/ARCHITECTURE.md`
- `03_SPECS/docs/STATE_MACHINES.md`
- `03_SPECS/docs/SECURITY_PRIVACY.md`
- `03_SPECS/docs/SOS_SPEC.md`
- `03_SPECS/docs/DEMO_SCRIPT.md`
- `03_SPECS/docs/QA_CHECKLIST.md`
- `03_SPECS/docs/DESIGN_SYSTEM.md`
- `03_SPECS/roles/ROLES.md` and `roles.json`
- `03_SPECS/screens/screens_patient.md`, `screens_professional.md`, `screens_admin.md`, and `screens.json`
- Build phase prompts, especially `HACKATHON_5H.md`
- Mock API README

## Retained as reference/assets
- Official logo assets, icons, illustrations, design tokens
- Existing starter mock API implementation
- Original SQL schema/seed files
- The full OpenAPI contract, which may list routes beyond MVP
- Other non-authoritative legacy technical assets

## Important
This is a **specification and prompt scope conversion**, not a claim that the app has already been built or that the retained mock API supports every MVP behavior. The AI builder must inspect the implementation, run it, and report real gaps before coding.
