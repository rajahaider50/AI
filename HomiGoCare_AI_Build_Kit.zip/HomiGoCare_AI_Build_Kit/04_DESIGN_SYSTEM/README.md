# 04_DESIGN_SYSTEM
- `design/` tokens.json, tokens.css, tailwind.preset.cjs, contrast.json, `android/designsystem/*.kt` (Color, Theme, Type, Shape, HgIcon)
- `icons/` 107 original icons: `svg/`, `android/drawable/hg_ic_*.xml`, `icons.json`
- `logo_assets/` OFFICIAL logo, transparent: mark, wordmark, tagline, lockups, Android launcher mipmaps, Play Store assets, favicons, OG image
- `illustrations/` six SVG illustrations
Rules are in `03_SPECS/docs/DESIGN_SYSTEM.md`. No emoji. Do not modify the logo.
