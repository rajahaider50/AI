package com.homigocare.core.designsystem.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.homigocare.core.designsystem.R

// Bundle Plus Jakarta Sans (Regular/SemiBold/Bold) + Noto Naskh Arabic in res/font. Arial is the spec fallback.
val HgLatin = FontFamily(
    Font(R.font.plus_jakarta_sans_regular, FontWeight.Normal),
    Font(R.font.plus_jakarta_sans_semibold, FontWeight.SemiBold),
    Font(R.font.plus_jakarta_sans_bold, FontWeight.Bold),
)
val HgUrdu = FontFamily(Font(R.font.noto_naskh_arabic_regular, FontWeight.Normal), Font(R.font.noto_naskh_arabic_bold, FontWeight.Bold))

// Sizes are the guide's: brand 28, H1 22, H2 18, body 14, small 12, button 16 bold.
val HgTypography = Typography(
    displayMedium = TextStyle(fontFamily = HgLatin, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp),
    headlineMedium = TextStyle(fontFamily = HgLatin, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = HgLatin, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = HgLatin, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = HgLatin, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = HgLatin, fontWeight = FontWeight.Bold, fontSize = 16.sp, lineHeight = 20.sp),
)
