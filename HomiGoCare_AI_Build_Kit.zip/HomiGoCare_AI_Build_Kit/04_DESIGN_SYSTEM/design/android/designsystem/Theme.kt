package com.homigocare.core.designsystem.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.LayoutDirection

/** Light-only for v1: the clinical teal/white identity is the product. Dark theme is a Phase 3 design task. */
private val HgLightColors = lightColorScheme(
    primary = HgColor.Primary, onPrimary = HgColor.White,
    primaryContainer = HgColor.Teal50, onPrimaryContainer = HgColor.PrimaryDark,
    secondary = HgColor.Secondary, onSecondary = HgColor.PrimaryDark,
    secondaryContainer = HgColor.Orange50, onSecondaryContainer = HgColor.Orange700,
    background = HgColor.White, onBackground = HgColor.TextPrimary,
    surface = HgColor.White, onSurface = HgColor.TextPrimary,
    surfaceVariant = HgColor.SurfaceMuted, onSurfaceVariant = HgColor.TextSecondaryAA,
    error = HgColor.Error, onError = HgColor.White, errorContainer = HgColor.Red50, onErrorContainer = HgColor.Red700,
    outline = HgColor.Border, outlineVariant = HgColor.Divider,
)

object HgGradients {
    val Splash = Brush.verticalGradient(listOf(HgColor.Primary, HgColor.PrimaryDark))
    val Earnings = Brush.linearGradient(listOf(HgColor.Primary, HgColor.Teal600))
}

/** Semantic colours that Material 3 has no slot for. */
data class HgSemantic(val success: androidx.compose.ui.graphics.Color = HgColor.Success, val emergency: androidx.compose.ui.graphics.Color = HgColor.Error,
                      val accent: androidx.compose.ui.graphics.Color = HgColor.Secondary, val placeholder: androidx.compose.ui.graphics.Color = HgColor.TextSecondary)
val LocalHgSemantic = staticCompositionLocalOf { HgSemantic() }

@Composable
fun HomiGoTheme(rtl: Boolean = false, content: @Composable () -> Unit) {
    CompositionLocalProvider(
        LocalHgSemantic provides HgSemantic(),
        androidx.compose.ui.platform.LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        MaterialTheme(colorScheme = HgLightColors, typography = HgTypography, shapes = HgShapes, content = content)
    }
}
