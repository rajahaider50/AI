package com.homigocare.core.designsystem.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

object HgRadius { val Button = 25.dp; val Input = 25.dp; val Card = 15.dp; val Chip = 20.dp; val Sheet = 24.dp; val Small = 8.dp }
val HgShapes = Shapes(
    extraSmall = RoundedCornerShape(HgRadius.Small), small = RoundedCornerShape(HgRadius.Chip),
    medium = RoundedCornerShape(HgRadius.Card), large = RoundedCornerShape(HgRadius.Button), extraLarge = RoundedCornerShape(HgRadius.Sheet),
)
object HgSpace { val xs = 4.dp; val sm = 8.dp; val md = 12.dp; val lg = 16.dp; val xl = 20.dp; val xxl = 24.dp; val x3 = 32.dp; val x4 = 40.dp; val x5 = 48.dp }
val MinTouchTarget = 48.dp
