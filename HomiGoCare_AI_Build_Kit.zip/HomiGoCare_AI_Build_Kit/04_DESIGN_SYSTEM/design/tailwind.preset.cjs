/** HomiGo Care Tailwind preset — import in tailwind.config: presets: [require('./tailwind.preset.cjs')] */
module.exports = {
  "theme": {
    "extend": {
      "colors": {
        "hg": {
          "teal": {
            "50": "#E9F5F2",
            "100": "#CFE8E3",
            "200": "#A5D2CA",
            "300": "#6FB1A6",
            "400": "#3E8F83",
            "500": "#1B6B63",
            "600": "#14574F",
            "700": "#0D4A44",
            "800": "#093632"
          },
          "orange": {
            "50": "#FEF1E8",
            "100": "#FDE3D1",
            "200": "#FAC4A0",
            "500": "#F5823A",
            "700": "#A8501A"
          },
          "red": {
            "50": "#FDECEB",
            "100": "#F9CFCD",
            "500": "#E53935",
            "700": "#A52824"
          },
          "green": {
            "50": "#EAF6EB",
            "100": "#CDE9CF",
            "500": "#43A047",
            "700": "#2D7A31"
          },
          "primary": "#1B6B63",
          "primaryDark": "#0D4A44",
          "secondary": "#F5823A",
          "muted": "#F5F5F5",
          "text": "#333333",
          "textSecondary": "#888888",
          "error": "#E53935",
          "success": "#43A047",
          "border": "#E3ECEA"
        }
      },
      "borderRadius": {
        "hg-button": "25px",
        "hg-card": "15px",
        "hg-chip": "20px",
        "hg-sheet": "24px"
      },
      "fontFamily": {
        "hg": [
          "Plus Jakarta Sans",
          "Arial",
          "sans-serif"
        ],
        "hg-urdu": [
          "Noto Naskh Arabic",
          "serif"
        ]
      },
      "boxShadow": {
        "hg-card": "0 4px 14px rgba(13,74,68,.08)",
        "hg-raised": "0 8px 24px rgba(13,74,68,.14)"
      }
    }
  }
};
