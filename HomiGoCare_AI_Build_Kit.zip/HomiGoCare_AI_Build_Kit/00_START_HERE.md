# HomiGo Care — AI Build Kit

**Because Care Begins at Home** · Islamabad & Rawalpindi

This ZIP contains everything an AI coding assistant needs to build HomiGo Care from zero to release: native Android apps, the Admin panel, the website and the backend. Work is split into phases so each part can be built and checked separately.

## English quick start
1. Open a new session with your AI coding tool (Claude Code, Cursor, Codex, etc.) and give it this whole folder.
2. Paste `AI_MASTER_PROMPT.md` as the first message.
3. Then paste ONE phase prompt from `02_PHASE_PROMPTS/` at a time, in order.
4. After each phase, check the "Definition of Done" list at the end of that prompt. Only then start the next phase.
5. Want a working demo in 5 hours? Run `02_PHASE_PROMPTS/HACKATHON_5H.md` instead of the full sequence.

## اردو میں مختصر ہدایات
1. اپنے AI کوڈنگ ٹول میں نیا سیشن کھولیں اور یہ پورا فولڈر اسے دیں۔
2. سب سے پہلے `AI_MASTER_PROMPT.md` پیسٹ کریں۔
3. پھر `02_PHASE_PROMPTS/` میں سے ایک وقت میں صرف ایک فیز کا پرامپٹ دیں، ترتیب وار۔
4. ہر فیز کے آخر میں "Definition of Done" دیکھیں؛ مکمل ہو تو اگلا فیز شروع کریں۔
5. اگر صرف 5 گھنٹے کا ہیکاتھون ڈیمو چاہیے تو `HACKATHON_5H.md` استعمال کریں۔
6. آفیشل لوگو `04_DESIGN_SYSTEM/logo_assets/` میں ہے (شفاف بیک گراؤنڈ کے ساتھ)۔ اسے بغیر تبدیلی کے ہر جگہ استعمال کرنا ہے۔

## Folder map
| Folder | What is inside |
|---|---|
| `01_MASTER_GUIDE/` | The premium PDF guide (read it, or hand it to the AI as extra context) |
| `AI_MASTER_PROMPT.md` | System prompt: paste first, every session |
| `02_PHASE_PROMPTS/` | 12 phase prompts: foundation, backend, bookings, Android core, Patient app, Professional app, Admin, Health Passport + SOS, Phase 2, Phase 3, website, QA/release, plus the 5-hour hackathon plan |
| `03_SPECS/screens/` | 76 screens (Patient 33, Professional 24, Admin 19) with API, components, states |
| `03_SPECS/api/openapi.yaml` | 105 operations, realtime events |
| `03_SPECS/database/` | PostgreSQL 16 `schema.sql` and `seed.sql` (demo data) |
| `03_SPECS/docs/` | Architecture, decisions, security, state machines, SOS, design rules, QA, demo script |
| `03_SPECS/roles/` | 29 roles with phase and required documents |
| `04_DESIGN_SYSTEM/` | Tokens, Android theme, 107 icons, official logo assets (transparent), illustrations |
| `05_STARTER/mock-api/` | Run `node server.ts` (Node 22.6+) for a working fake backend on port 4000 |

## Demo accounts (seed + mock API)
| Role | Login | Secret |
|---|---|---|
| Patient | +923000000002 | password `Demo@1234`, OTP `123456`, Health Passport PIN `1234` |
| Nurse | +923000000003 | password `Demo@1234`, OTP `123456` |
| Admin | admin@homigocare.test | password `Demo@1234`, 2FA code `123456` |

These work only in development (`OTP_DEV_BYPASS=true`). Remove before any public deployment.

## Known limits of this kit
- Android and backend code is **not** included as finished code; the AI builds it from the specs. The schema, OpenAPI file and mock server were tested here.
- Assessment questions are samples, not clinically validated.
- Payments and SMS use sandbox providers behind interfaces. Real JazzCash/Easypaisa and SMS credentials must be added by the owner.
- The official logo is raster art. A vector version would give sharper results at very large sizes.
