# START HERE — HomiGo Care Minimalist MVP

## 1. Read in this order
1. `MVP_SCOPE.md`
2. `AI_MASTER_PROMPT.md`
3. `03_SPECS/docs/DECISIONS.md`
4. `03_SPECS/docs/ARCHITECTURE.md`
5. `03_SPECS/docs/SECURITY_PRIVACY.md`
6. `03_SPECS/docs/SOS_SPEC.md`
7. `03_SPECS/screens/screens_patient.md`
8. `03_SPECS/screens/screens_professional.md`
9. `03_SPECS/screens/screens_admin.md`
10. `03_SPECS/docs/DEMO_SCRIPT.md`
11. `03_SPECS/docs/QA_CHECKLIST.md`
12. `04_DESIGN_SYSTEM/README.md`

## 2. MVP objective
Build one polished, connected healthcare workflow:
Patient books a Doctor/Nurse → Professional accepts and completes the booking → Patient controls Health Passport access via PIN → Patient triggers SOS → Admin receives and acknowledges the alert.

## 3. Required panels
- Patient Android app
- Professional Android app, shared by Doctor and Nurse
- Admin web panel

Do not build a public marketing website for this MVP.

## 4. Recommended build order
1. Inspect starter files and existing environment; report what already works.
2. Establish the smallest working backend/mock API and shared design tokens.
3. Build the Patient booking path.
4. Build the Professional accept/complete path.
5. Build Admin verification, booking monitoring, and SOS monitoring.
6. Wire Health Passport PIN/authorization and SOS end-to-end.
7. Run the QA checklist and rehearse the demo.

## 5. Demo-first rule
Prioritize a complete, reliable vertical slice over many screens. Use a seeded demo account and clearly labeled mock data where necessary. Do not pretend mock integrations are production integrations.

## 6. Retained files
The ZIP retains the original logo, icons, design tokens, starter API and supporting references. Some legacy files describe deferred features. They are not build requirements unless listed in `MVP_SCOPE.md`.

## 7. Local run and AI workflow
Ask the coding AI to inspect the repository before editing, identify the current framework/build status, and implement incrementally. After each phase, it must report changed files, commands run, results, blockers, and any mocked behavior. Never claim the app builds or tests pass unless commands were actually run.
