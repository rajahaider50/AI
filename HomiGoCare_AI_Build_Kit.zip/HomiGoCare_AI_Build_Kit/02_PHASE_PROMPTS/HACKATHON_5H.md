# Hackathon MVP Plan — Minimalist Five-Hour Build

## Goal
A working vertical slice, not a full healthcare marketplace.

### Hour 1 — Audit and foundation
- Inspect repo, run existing app/API, identify blockers.
- Configure seed data and shared design system.
- Confirm core API/state model.

### Hour 2 — Patient booking
- Login/demo entry, home, approved professional list/profile, create booking, confirmation.

### Hour 3 — Professional workflow
- Doctor/Nurse shared panel, verification status, incoming booking, accept/decline, complete.

### Hour 4 — Privacy and SOS
- Health Passport PIN + booking-scoped authorization.
- SOS creates persisted alert visible in Admin.

### Hour 5 — Admin, integration, QA
- Admin verification, booking monitor, SOS alert acknowledgment.
- Run core end-to-end tests, polish states, rehearse demo, record backup.

## Priority if behind
1. Booking end-to-end.
2. SOS-to-Admin end-to-end.
3. Health Passport authorization demo.
4. Admin verification.
5. Visual polish.

## AI instruction
“Build only the Minimalist MVP defined in `MVP_SCOPE.md`. Inspect the repository first. Reuse existing assets and stack. Do not build the full 29-role platform, website, medicine/lab flows, wallet, payments, referrals, advanced assessments, chat, or analytics. Report real build/test results and label mocked behavior.”
