# Hackathon 5-hour MVP plan

Goal: a convincing demo of three things, using the mock API so nothing blocks on the backend.
1. Digital Health Passport with a 4-digit PIN lock.
2. All-in-One Booking UI (doctor appointment, nurse home visit, medicine order, lab test).
3. SOS alert that appears as a prominent red alert on the Admin dashboard.

Use only screens with `showcase: true` in `03_SPECS/screens/screens.json`.

## Timeline
| Hour | Work |
|---|---|
| 0:00-0:30 | Run `05_STARTER/mock-api` (`node server.ts`). Create Android project with the design system and official logo (Phase 03 steps 2-4 only) and a Vite admin app with the tokens |
| 0:30-1:30 | Patient: splash, login (demo account), home with the All-in-One grid (4 tiles) |
| 1:30-2:30 | Booking flow: pick service, professional list, confirm, sandbox pay, status screen |
| 2:30-3:30 | Health Passport: PIN set/verify (lock after 5 tries), passport view, grant to booking |
| 3:30-4:15 | SOS: hold-to-send button, SOS active screen, Admin red alert banner via SSE |
| 4:15-5:00 | Polish: states, copy, icons, run DEMO_SCRIPT.md twice, record backup video |

## Prompt to give the AI
"Run the Hackathon 5H plan. Use the mock API at http://10.0.2.2:4000/v1. Build only showcase screens. Use the design system and official logo from the kit. No emoji. Follow SOS_SPEC.md honesty rules: label anything not real as prototype. Stop after each hour block and report."

## Honesty note for judges
State plainly: payments are sandbox, ambulance dispatch is not simulated, and SOS reaches the admin dashboard and emergency contact only.
