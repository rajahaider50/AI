# Phase 06 — Admin Web MVP

Build a protected, minimal Admin panel with:
1. Login.
2. Dashboard summary: pending verification, bookings, active SOS.
3. Professional verification queue and detail; approve/reject/request changes with reason.
4. Booking monitoring/detail with metadata only.
5. SOS list/detail; acknowledge and resolve/update status.

Use a simple navigation sidebar/topbar and clean tables. Admin IDs are proposed UI identifiers. Do not build dispute center, broadcast messaging, CSV exports, advanced analytics, or unrestricted medical-record access.
