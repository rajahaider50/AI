# Phase 06 - Admin web panel (A-01..A-13)

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Build the admin panel in React + Vite with the shared tokens and official logo.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Login with 2FA; session timeout; role-based menu (Admin, Verification Officer, Support, Field Supervisor)
2. Dashboard KPIs (from v_admin_kpis) and a prominent red SOS alert banner (realtime), sound toggle, reduced-motion safe
3. Verification queue and detail with document viewer (presigned), approve/reject/action-required with reason
4. Bookings, users, disputes, payments/commissions, notifications, audit log viewer
5. Tailwind preset from 04_DESIGN_SYSTEM; official white lockup in sidebar; favicons and OG from logo_assets/web
6. Tables with filters, pagination, CSV export; empty/error/loading states

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] All A-* screens for phase 1 work against the mock API and real API
- [ ] SOS appears within 1 s and cannot be missed on any page
- [ ] Lighthouse accessibility >= 95; keyboard navigable

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
