# Phase 01 — MVP Backend Core

Read `MVP_SCOPE.md`, `ARCHITECTURE.md`, `SECURITY_PRIVACY.md`, `STATE_MACHINES.md`, and the existing API contract.

## Required backend capability
- Demo/local authentication with environment-gated development bypass.
- Patient and Doctor/Nurse profile basics.
- Professional document metadata and verification status.
- Professional search/list for approved professionals.
- Booking create/read/update with server-side status transitions.
- Health Passport PIN verification and booking-scoped authorization.
- SOS create/list/detail/acknowledge/resolve.
- Minimal admin dashboard summary.
- Validation, role-based authorization, consistent errors, and tests for core state transitions.

## Rules
- Add or update only MVP routes.
- Do not implement wallet, commission, pharmacy, lab, referral, chat, assessment, website, or analytics APIs.
- Do not expose Health Passport records to Admin.
- Use synthetic seed data.
- Update OpenAPI documentation whenever routes change.
- If the existing mock API is enough for a UI-only demo, state exactly which parts are mocked.
