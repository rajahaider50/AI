# Phase 01 - Backend core: auth, profiles, catalog, verification

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Implement the API foundation from openapi.yaml and schema.sql.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Prisma schema generated from 03_SPECS/database/schema.sql (keep triggers via raw migration); seed from seed.sql
2. Auth: signup, OTP (provider interface + dev bypass), login, refresh rotation with reuse detection, admin 2FA
3. Patient profile, addresses, family members, emergency contact
4. Professional onboarding: documents upload (presigned), submission, verification state machine, assessment engine (sample questions)
5. Catalog and professional search (filters, sort, distance)
6. Admin: professionals queue, decision with reason, audit log writes
7. Zod on every route; error format {error:{code,message,fields}}; request ids; rate limits
8. Tests: unit for state machines, integration for auth and verification

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] All Phase-1 auth/profile/catalog/verification operations in openapi.yaml respond per contract
- [ ] State machine tests pass; illegal transitions return 409
- [ ] No secrets or PII in logs (test with a log scraper)

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
