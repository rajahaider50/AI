# Phase 09 - Phase 3 features

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Add everything flagged phase 3 and the remaining roles.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Lab partner and pharmacy partner portals (web)
2. Respiratory therapist, nutritionist, palliative nurse, vaccination specialist, ambulance driver
3. Verification officer, field supervisor, support agent sub-roles with scoped permissions
4. Analytics, reports, advanced search

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] All 76 screens implemented; all 29 roles gated by flags; regression green

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
