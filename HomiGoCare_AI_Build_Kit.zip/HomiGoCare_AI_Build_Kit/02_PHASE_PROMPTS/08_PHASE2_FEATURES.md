# Phase 08 - Phase 2 features

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Add all screens and features flagged phase 2 in screens.json and roles 16, 18, 22.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Recurring and scheduled bookings, dedicated nurse shifts, family account manager
2. Wallet, promo codes, invoices, support chat
3. Roles: Speech Therapist, Psychologist, Home Health Aide with their documents
4. Admin: disputes, refunds, supervisor tools

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] Phase-2 flagged screens complete; regression suite of phase 1 still green

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
