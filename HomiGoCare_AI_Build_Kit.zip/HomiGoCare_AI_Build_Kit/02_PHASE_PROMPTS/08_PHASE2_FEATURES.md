# Deferred — Phase 2 Features

**Do not execute for the current MVP.** This file is retained as a roadmap placeholder from the original full-platform kit.

Possible later features: family profiles, full Health Passport record management, lab booking, medicine orders, wallet/payments, booking history, notifications, reviews, advanced availability, and expanded professional types.

Only start a deferred feature after the MVP acceptance criteria pass and the owner explicitly approves scope expansion.
