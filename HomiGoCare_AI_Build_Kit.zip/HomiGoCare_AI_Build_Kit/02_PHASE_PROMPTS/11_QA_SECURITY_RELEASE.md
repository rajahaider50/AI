# Phase 11 — MVP QA and Demo Readiness

Use `03_SPECS/docs/QA_CHECKLIST.md`, `SECURITY_PRIVACY.md`, `SOS_SPEC.md`, and `DEMO_SCRIPT.md`.

Required:
- Test the connected booking workflow across Patient and Professional.
- Test Admin verification and ensure unapproved professionals cannot accept bookings.
- Test Health Passport authorization and denial without authorization.
- Test SOS creation, Admin visibility, acknowledgment, and resolution.
- Check role access, error states, privacy boundaries, and design consistency.
- Run available tests/builds and report exact output.
- List all mocked integrations and remaining blockers.

Do not claim production readiness or regulatory compliance based only on a successful demo.
