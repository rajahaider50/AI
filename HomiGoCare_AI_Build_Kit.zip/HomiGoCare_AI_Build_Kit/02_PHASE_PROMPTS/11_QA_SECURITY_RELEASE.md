# Phase 11 - QA, security, release

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Prove quality and ship.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Run QA_CHECKLIST.md fully; fix all blockers
2. Security pass per SECURITY_PRIVACY.md including OWASP list; dependency audit
3. Release: signed AAB, Play listing assets (play_store_icon_512, feature graphic), privacy policy URL, data safety form draft
4. Backups, monitoring, alerts, crash reporting; runbook for SOS outages
5. Remove dev bypasses in production config; verify with a smoke test

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] Release checklist signed off with evidence (command output, screenshots)

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
