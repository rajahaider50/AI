# Phase 00 — MVP Foundation

Read `AI_MASTER_PROMPT.md`, `MVP_SCOPE.md`, `03_SPECS/docs/DECISIONS.md`, and `ARCHITECTURE.md` first.

## Goal
Inspect the current repository and establish only the structure needed for Patient Android, Professional Android, Admin web, and the API/mock API.

## Tasks
1. Report current repository structure and working build status before changing files.
2. Preserve existing technology choices and starter code unless there is a concrete blocker.
3. Reuse existing design tokens, logo, and icon assets.
4. Configure local environment examples without real secrets.
5. Ensure core route/navigation and API contract agree with MVP.
6. Document local run instructions and seed demo accounts/data.
7. Run available lint/build checks and report actual results.

## Do not
- Create a marketing website.
- Build all 29 roles.
- Implement future-phase modules.
- Rewrite the repository structure just for aesthetics.
