# Phase 00 - Foundation and monorepo

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Create the monorepo and tooling so every later phase has a place to live.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. pnpm workspace with apps/android, apps/admin-web, apps/website, services/api, packages/design-tokens, packages/api-types
2. Copy 04_DESIGN_SYSTEM/design into packages/design-tokens; copy 03_SPECS into docs/specs (read-only)
3. Docker compose: postgres 16 + api; scripts: dev, lint, test, build
4. Lint/format: ESLint, Prettier, ktlint, detekt; EditorConfig; pre-commit hook that rejects emoji characters in source and strings
5. GitHub Actions: lint + test for each package; Android assemble debug
6. README with run instructions; .env.example; DECISIONS_LOG.md

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] Fresh clone runs `pnpm i && pnpm dev` for API + admin
- [ ] CI is green on an empty app
- [ ] Emoji check hook works (test it with a deliberate emoji)

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
