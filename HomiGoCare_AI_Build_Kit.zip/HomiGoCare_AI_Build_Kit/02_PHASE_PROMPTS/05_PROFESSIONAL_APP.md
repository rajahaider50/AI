# Phase 05 — Shared Professional App MVP

Only Doctor and Nurse types.

Implement:
1. Login/register.
2. Basic details and credential upload/seeded demo document support.
3. Verification status.
4. Dashboard and incoming booking list.
5. Booking details; accept/decline.
6. Mark service in progress/completed where supported.
7. Health Passport view only after valid patient authorization.

Do not build the 29-role selector, complex exams, earnings, ratings, messages, or advanced scheduling.
