# Phase 05 - Professional app (PR-01..PR-24)

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Build the Professional app.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Onboarding: signup, role selection (29 roles gated by phase flags), document upload with camera/gallery, status tracker with under_review illustration
2. Assessment (3 phases) with timer, attempts, cooldown UI
3. Dashboard, online/offline toggle, incoming request with accept/decline countdown, active visit (on the way, arrived, in progress, complete), earnings, schedule, reviews
4. Granted Health Passport read-only view with watermark and FLAG_SECURE
5. Profile and affiliation display; Student/Intern labels

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] A new professional can register, upload docs, and (after admin approval in mock) receive and complete a booking
- [ ] Role gating by phase works via feature flags
- [ ] All screens pass the visual QA bar

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
