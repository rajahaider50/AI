# Phase 04 - Patient app (P-01..P-33)

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Build the Patient app from screens_patient.md, in the order of phase flags (phase 1 first).

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Auth flow P-01..P-10: splash, onboarding (3 illustrations), signup, OTP, login, profile completion
2. Home dashboard with All-in-One Booking grid (doctor, nurse, medicine, lab)
3. Professional search, profile, booking flow, payment sandbox, tracking, history, rating
4. Health Passport: PIN set/verify, lock after 5 tries, grant per booking, access log (FLAG_SECURE)
5. SOS P-25 (and P-16 / P-24 Health Passport) per SOS_SPEC.md
6. Settings, language switch, notifications, help
7. Every screen: loading, empty, error, offline states; strings in resources

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] All phase-1 patient screens implemented against the mock API, then the real API
- [ ] Instrumented UI tests cover signup-to-booking and SOS
- [ ] Visual QA on 320/360/411 dp, font scale 1.3, Urdu RTL

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
