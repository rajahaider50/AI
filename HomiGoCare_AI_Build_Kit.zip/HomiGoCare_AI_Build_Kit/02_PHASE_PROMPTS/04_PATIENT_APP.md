# Phase 04 — Patient App MVP

Implement:
1. Login/demo entry.
2. Minimal home dashboard: Doctor, Nurse, Health Passport, SOS.
3. Browse approved professionals.
4. Professional profile.
5. Booking details and confirmation/status.
6. Health Passport PIN and authorization/grant state.
7. SOS confirmation and alert status.

The patient must be able to complete one connected booking. Use only fields necessary for the booking. Do not build family management, medicine/lab orders, wallet, referrals, rewards, advanced profile settings, or full history.
