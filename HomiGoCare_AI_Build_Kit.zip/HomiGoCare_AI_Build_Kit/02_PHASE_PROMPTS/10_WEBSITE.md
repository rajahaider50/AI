# Deferred — Public Website

**No public website is required for the minimalist MVP.** Retained only for roadmap compatibility. Do not create a website or waitlist page unless the owner explicitly approves it after the core three-panel demo works.
