# Phase 10 - Public website

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Build the marketing site in Next.js 15 with EN/UR and RTL.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Pages: Home, Services, How it works, For professionals, Safety and privacy, About, Contact, Privacy policy, Terms, Waitlist
2. Hero with official stacked lockup and Android download badges (placeholder links)
3. Waitlist form -> POST /v1/public/waitlist with validation and success state
4. SEO: metadata, sitemap, OG image from logo_assets/web, structured data
5. Performance: Lighthouse >= 90 all categories; images optimized; no layout shift
6. Tokens from tailwind.preset.cjs; icons from the set; illustrations from the kit; no emoji

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] EN and UR both complete; RTL mirrored; forms accessible
- [ ] Deployed preview URL; OG image renders in link preview

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
