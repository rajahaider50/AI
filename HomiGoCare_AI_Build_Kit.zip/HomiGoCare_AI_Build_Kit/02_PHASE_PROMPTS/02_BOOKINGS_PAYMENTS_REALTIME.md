# Phase 02 - Bookings, payments, realtime

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Implement the booking lifecycle end to end.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Quote and create booking for 4 types: doctor appointment, nurse home visit, medicine order, lab test; Idempotency-Key
2. Dispatch: offers to nearby online approved professionals; atomic accept (first wins), decline, expiry job (5 min)
3. Status transitions per STATE_MACHINES.md
4. Payment provider interface, SANDBOX provider, confirm endpoint, 15% commission rows, refunds on cancel rules
5. Realtime gateway (Socket.io) with the x-realtime events; reconnect and resync endpoint
6. Notifications table + FCM sender interface
7. Ratings and receipts

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] Full booking happy path and all failure paths pass integration tests
- [ ] Duplicate accept returns 409; idempotent create returns the same booking
- [ ] Realtime events reach a test client within 1 s

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
