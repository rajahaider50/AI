# Phase 02 — MVP Booking Integration (payments deferred)

This filename is retained for compatibility with the original kit. **Real payments are out of MVP scope.**

## Build
- Patient creates a Doctor appointment or Nurse home-visit booking.
- Booking appears in Professional dashboard.
- Professional accepts or declines.
- Status transitions are persisted and reflected in Patient/Admin views.
- Admin can inspect booking metadata.
- Use the existing real-time mechanism if available; otherwise use a reliable refresh/polling approach and label it.

## Do not build
Payment gateway, wallet, commission, payouts, medicine/lab checkout, recurring booking, chat, or advanced tracking.
