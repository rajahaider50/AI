# Phase 07 - Health Passport and SOS hardening

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Finish the two safety-critical features end to end across backend, apps and admin.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Backend: PIN set/verify with lockout, grants, immutable access_logs, field encryption, expiry job
2. SOS: create, location stream, SMS relay endpoint, contact notification, admin actions, timeline, audit
3. Offline SOS fallback on Android (SMS composer + call 1122 intent)
4. Security tests: IDOR on passport, brute force PIN, replay of SOS create
5. Admin sees no medical data (test)

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] SOS acceptance tests in SOS_SPEC.md all pass
- [ ] Passport access log shows each read; trying to update or delete log rows fails at DB level

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
