# Phase 07 — MVP Hero Features: Health Passport + SOS

## Health Passport
- Four-digit PIN setup/entry for the synthetic demo record.
- Explicit patient authorization for a specific professional/booking.
- Deny access without a valid grant.
- Log grant/revoke/read events where implemented.
- Do not store PIN in plaintext or logs.
- State clearly that a demo PIN screen alone is not production-grade security.

## SOS
- Patient triggers an authenticated alert.
- Alert is persisted and visible on Admin dashboard.
- Admin opens, acknowledges, and resolves/updates it.
- Include location only when actually available and permissioned.
- Do not claim dispatch, guaranteed offline, or SMS fallback unless built and tested.

Keep these features small and testable. No unrelated Phase 2/3 functionality.
