# Phase 03 — Android Core for MVP

Maintain native Kotlin/Compose if that is the existing app stack. Implement only the Patient and shared Professional Android interfaces defined in `MVP_SCOPE.md`.

## Quality bar
- Reuse supplied theme, tokens, logo and icons.
- Core navigation must work.
- Provide validation and loading/error/empty/success states.
- Use ViewModels/repositories or the architecture already established in the repo.
- Do not add unused screens or role-specific apps.
- Run Android build/lint checks if available; report exact results.
