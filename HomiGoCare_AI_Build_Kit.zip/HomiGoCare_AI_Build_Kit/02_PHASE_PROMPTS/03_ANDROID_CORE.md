# Phase 03 - Android shared core and design system

> Paste `AI_MASTER_PROMPT.md` first. Then this prompt.

## Goal
Create the Gradle multi-module Android project and the design system, with the official logo.

## Read first
- `03_SPECS/docs/DECISIONS.md`, `ARCHITECTURE.md`
- Files named in the tasks below

## Tasks
1. Modules: app-patient, app-pro, core-designsystem, core-network, core-data, core-ui, feature-*
2. Copy 04_DESIGN_SYSTEM/design/android/designsystem/*.kt into core-designsystem; bundle Inter and Noto Nastaliq Urdu
3. Copy 04_DESIGN_SYSTEM/icons/android/drawable/*.xml to core-designsystem res; HgIcon composable
4. Copy logo_assets/android/mipmap-* and ic_launcher XML into both apps; set adaptive icon; copy homigo_lockup_*.png into drawable-nodpi
5. Components: HgButton, HgTextField, HgCard, StatusBadge, TopBar, BottomNav, EmptyState, ErrorState, LoadingSkeleton, SosButton, PinPad, OtpField
6. Network: Retrofit + OkHttp, token authenticator (refresh), error mapper, Idempotency-Key interceptor; base URL by build type pointing to mock API (http://10.0.2.2:4000/v1) in debug
7. Navigation graph skeleton and UiState pattern; Hilt; locale switching EN/UR with RTL
8. Compose previews and screenshot tests for every component at font scale 1.0 and 1.3

## Rules for this phase
- Contract first (`openapi.yaml`); tokens only; official logo only; no emoji.
- Do not start work belonging to other phases.

## Definition of Done
- [ ] App launches with the official logo splash and correct launcher icon on API 26 and 34
- [ ] Component gallery screen shows every component with no clipping at 320 dp and RTL
- [ ] No hex literals outside Color.kt; no emoji (CI check)

## Final report format
Built / Tested (real command output summary) / Deferred / Assumptions logged in DECISIONS_LOG.md.
