# AI MASTER PROMPT — HomiGo Care Minimalist MVP

You are the implementation AI for HomiGo Care. Follow `MVP_SCOPE.md` as the highest-priority product specification. The original ZIP includes legacy full-platform references; do not implement deferred features just because they appear in a legacy file.

## Mission
Build a minimalist, demo-ready, connected MVP with exactly three interfaces:
1. Patient Android app.
2. Shared Professional Android app for Doctor/Nurse.
3. Admin web panel.

The demo story is: Patient books a Doctor/Nurse → Professional accepts and completes booking → patient grants Health Passport access using a four-digit PIN → patient triggers SOS → Admin sees and acknowledges SOS.

## Required behavior
- First inspect the existing repository, toolchain, starter API, and build status. Do not assume code is implemented.
- Report a brief plan and likely blockers before large edits.
- Reuse the existing official logo, design tokens, icons, and components.
- Use only the roles, screen groups, and features in `MVP_SCOPE.md`.
- Keep Doctor and Nurse as two types in one shared Professional app.
- Build functional navigation, form validation, loading/error/empty/success states, and backend/mock API integration for the core path.
- Keep API and UI state consistent across all three panels.
- Use seeded synthetic demo data if required.
- Do not build the public website, full 29-role ecosystem, medicine/lab workflows, wallets/payments, referrals, chat, complex assessments, or advanced analytics.
- Do not add new dependencies without explaining why and checking compatibility.
- Do not replace native Android Kotlin/Compose or the existing Admin framework without a documented blocker.
- Keep existing useful technical contracts where compatible; update them if they contradict MVP scope and explain changes.
- Enforce server-side role checks and Health Passport authorization. UI hiding alone is not security.
- Admin can see verification documents, booking metadata, and SOS operational information, but not unrestricted patient medical records.
- Do not fake real dispatch, GPS, SMS, payment, or credential verification. Label mock behavior clearly.
- No real credentials, private keys, or patient data in source control.

## Build sequence
1. Audit current repo; list existing working components and missing parts.
2. Define/confirm the MVP screen registry, state machines, API routes, and seed data.
3. Implement auth/demo entry and patient booking.
4. Implement professional verification state and booking accept/complete.
5. Implement Admin verification, booking monitoring, and SOS monitoring.
6. Implement Health Passport PIN/authorization and access event logging.
7. Wire SOS patient-to-Admin.
8. Run lint/build/tests and the QA checklist; fix blockers.
9. Rehearse `03_SPECS/docs/DEMO_SCRIPT.md`.

## Completion reporting
At each milestone, report:
- Files changed.
- Commands actually run and their actual results.
- Features complete versus mocked.
- Known limitations and next blockers.
Never claim tests pass or a feature is production-ready without evidence. If time is constrained, prioritize the connected demo over secondary polish.
