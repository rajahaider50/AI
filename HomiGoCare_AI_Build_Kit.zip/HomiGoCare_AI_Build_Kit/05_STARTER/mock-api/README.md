# HomiGo mock API
Zero-dependency Node 22.6+ server implementing the contract in `03_SPECS/api/openapi.yaml` with in-memory data.

    node server.ts          # http://localhost:4000/v1 ; PORT env to change
Android emulator base URL: `http://10.0.2.2:4000/v1`. Realtime (SSE): `/v1/rt/stream?token=<accessToken>`.
Logins (password `Demo@1234`, OTP/2FA `123456`): patient +923000000002, professional +923000000003, admin admin@homigocare.test. Health Passport PIN 1234.
Development only; never deploy.
