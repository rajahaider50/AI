# Mock API — MVP development aid

This starter mock API is retained from the original kit. Before relying on it, inspect its routes and confirm they support the MVP flows in `MVP_SCOPE.md`.

MVP routes/capabilities needed:
- Demo auth/session.
- Approved professional list/detail.
- Booking create/list/status updates.
- Professional verification state and Admin decision.
- Health Passport PIN/booking-scoped grant/access status.
- SOS create/list/detail/acknowledge/resolve.

If a route is missing, implement only what the MVP needs and update `03_SPECS/api/openapi.yaml`. Do not treat every legacy route as required. Do not use real patient data or secrets.
