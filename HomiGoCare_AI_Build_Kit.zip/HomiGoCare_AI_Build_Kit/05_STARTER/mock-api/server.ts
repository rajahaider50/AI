/**
 * HomiGo Care — MOCK API (zero dependencies, Node 22+).  Run:  node server.ts
 * Purpose: lets the Android / Admin / Website builders develop against the REAL contract (03_SPECS/api/openapi.yaml)
 * before the production backend exists. In-memory data, resets on restart. NOT for production.
 *
 * Demo logins (password Demo@1234): patient +923000000002 · professional +923000000003 · admin admin@homigocare.test
 * OTP is always 123456.  Health Passport PIN for the demo patient: 1234.
 * Realtime: Server-Sent Events at GET /v1/rt/stream?token=<jwt>  (production uses Socket.io with the same event names).
 */
import http from 'node:http';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT ?? 4000);
const SECRET = 'mock-secret-change-me';
const OTP = '123456';

// ---------------------------------------------------------------- tiny JWT (HS256)
const b64 = (o: unknown) => Buffer.from(JSON.stringify(o)).toString('base64url');
const sign = (p: object, ttl = 900) => { const h = b64({ alg: 'HS256', typ: 'JWT' }), b = b64({ ...p, exp: Math.floor(Date.now() / 1000) + ttl }); return `${h}.${b}.${crypto.createHmac('sha256', SECRET).update(`${h}.${b}`).digest('base64url')}`; };
function verify(t?: string): any { if (!t) return null; const [h, b, s] = t.split('.'); if (!s) return null; const ok = crypto.createHmac('sha256', SECRET).update(`${h}.${b}`).digest('base64url') === s; if (!ok) return null; const p = JSON.parse(Buffer.from(b, 'base64url').toString()); return p.exp > Date.now() / 1000 ? p : null; }

// ---------------------------------------------------------------- data
type R = 'PATIENT' | 'PROFESSIONAL' | 'ADMIN';
interface U { id: string; role: R; phone?: string; email?: string; password: string; fullName: string; status: string }
const id = () => crypto.randomUUID();
const users: U[] = [
  { id: 'u-admin', role: 'ADMIN', email: 'admin@homigocare.test', phone: '+923000000001', password: 'Demo@1234', fullName: 'Aun Admin', status: 'ACTIVE' },
  { id: 'u-ali', role: 'PATIENT', phone: '+923000000002', email: 'ali@homigocare.test', password: 'Demo@1234', fullName: 'Ali Raza', status: 'ACTIVE' },
  { id: 'u-sara', role: 'PROFESSIONAL', phone: '+923000000003', email: 'sara@homigocare.test', password: 'Demo@1234', fullName: 'Sara Khan', status: 'ACTIVE' },
  { id: 'u-imran', role: 'PROFESSIONAL', phone: '+923000000004', email: 'imran@homigocare.test', password: 'Demo@1234', fullName: 'Dr. Imran Malik', status: 'ACTIVE' },
  { id: 'u-hina', role: 'PROFESSIONAL', phone: '+923000000005', email: 'hina@homigocare.test', password: 'Demo@1234', fullName: 'Hina Tariq', status: 'ACTIVE' },
];
const professionals: any[] = [
  { id: 'u-sara', fullName: 'Sara Khan', type: 'HOME_VISIT_NURSE', specialization: 'Wound care · Injections · Elderly care', hospitalName: 'Shifa International Hospital', ratingAvg: 4.8, ratingCount: 47, languages: ['Urdu', 'English'], distanceKm: 2.3, pricePkr: 1200, isOnline: true, badges: ['CERTIFIED', 'TOP_RATED'], bio: 'Registered nurse, 6 years ICU + home care.', verification: 'APPROVED', serviceCode: 'NURSE_HOME_VISIT' },
  { id: 'u-imran', fullName: 'Dr. Imran Malik', type: 'GP', specialization: 'General medicine', hospitalName: 'PIMS Islamabad', ratingAvg: 4.7, ratingCount: 31, languages: ['Urdu', 'English', 'Punjabi'], distanceKm: 4.1, pricePkr: 1500, isOnline: true, badges: ['CERTIFIED'], bio: 'GP, 9 years. Home visits for fever, flu, chronic follow-up.', verification: 'APPROVED', serviceCode: 'DOC_GP_HOME_VISIT' },
  { id: 'u-hina', fullName: 'Hina Tariq', type: 'HOME_VISIT_NURSE', specialization: 'Post-surgery care', hospitalName: 'Holy Family Hospital', ratingAvg: 0, ratingCount: 0, languages: ['Urdu'], distanceKm: 6, pricePkr: 1000, isOnline: false, badges: [], bio: '', verification: 'UNDER_REVIEW', serviceCode: 'NURSE_HOME_VISIT' },
];
const services = [
  { code: 'NURSE_HOME_VISIT', category: 'NURSE', nameEn: 'Home Visit Nurse', nameUr: 'ہوم وزٹ نرس', iconKey: 'syringe', fromPricePkr: 800, phase: 1 },
  { code: 'NURSE_DEDICATED', category: 'NURSE', nameEn: 'Dedicated Nurse', nameUr: 'ڈیڈیکیٹڈ نرس', iconKey: 'user-medical', fromPricePkr: 2500, durationHours: [8, 12, 24], phase: 1 },
  { code: 'NURSE_HOSPITAL_COMPANION', category: 'NURSE', nameEn: 'Hospital Companion', nameUr: 'ہسپتال کمپینین', iconKey: 'hospital', fromPricePkr: 2000, phase: 1 },
  { code: 'DOC_GP_HOME_VISIT', category: 'DOCTOR', nameEn: 'GP Home Visit', nameUr: 'جی پی ہوم وزٹ', iconKey: 'stethoscope', fromPricePkr: 1200, phase: 1 },
  { code: 'DOC_SPECIALIST_ONLINE', category: 'DOCTOR', nameEn: 'Specialist Online', nameUr: 'اسپیشلسٹ آن لائن', iconKey: 'video', fromPricePkr: 1500, phase: 1 },
  { code: 'LAB_HOME_COLLECTION', category: 'LAB_TEST', nameEn: 'Lab Test', nameUr: 'لیب ٹیسٹ', iconKey: 'flask', fromPricePkr: 500, phase: 3 },
  { code: 'MED_DELIVERY', category: 'MEDICINE', nameEn: 'Medicine', nameUr: 'ادویات', iconKey: 'pill', fromPricePkr: 50, phase: 3 },
];
const addresses: any[] = [{ id: 'a1', patientUserId: 'u-ali', label: 'Home', house: 'House 14', street: 'Street 7, G-11/3', city: 'Islamabad', zone: 'G-11', lat: 33.6692, lng: 72.9894, isDefault: true }];
const bookings: any[] = []; const notifications: any[] = []; const accessLogs: any[] = []; const grants: any[] = []; const sos: any[] = []; const audit: any[] = []; const idem = new Map<string, any>();
let bookingSeq = 456; const pin = { u: 'u-ali', value: '1234', fails: 0, lockedUntil: 0 };
const otps = new Map<string, { userId: string; tries: number }>();

// ---------------------------------------------------------------- SSE realtime
const clients = new Set<{ res: http.ServerResponse; user: any }>();
function emit(event: string, payload: any, to: (u: any) => boolean) { for (const c of clients) if (to(c.user)) c.res.write(`event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`); }
const notify = (userId: string, type: string, title: string, body: string, data: any = {}) => { const n = { id: id(), userId, type, title, body, data, readAt: null, createdAt: new Date().toISOString() }; notifications.push(n); emit('notification.new', n, u => u.sub === userId); };

// ---------------------------------------------------------------- helpers
const E = (res: http.ServerResponse, status: number, code: string, message: string, fields?: object) => send(res, status, { error: { code, message, fields } });
function send(res: http.ServerResponse, status: number, body?: unknown) { res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' }); res.end(body === undefined ? '' : JSON.stringify(body)); }
const readBody = (req: http.IncomingMessage) => new Promise<any>(r => { let d = ''; req.on('data', c => (d += c)); req.on('end', () => { try { r(d ? JSON.parse(d) : {}); } catch { r({}); } }); });
const tokens = (u: U) => ({ accessToken: sign({ sub: u.id, role: u.role }), refreshToken: sign({ sub: u.id, role: u.role, r: 1 }, 2592000), expiresIn: 900, user: pub(u), next: u.role === 'ADMIN' ? 'DASHBOARD' : u.role === 'PATIENT' ? 'HOME' : (professionals.find(p => p.id === u.id)?.verification === 'APPROVED' ? 'DASHBOARD' : 'VERIFICATION_PENDING') });
const pub = (u: U) => ({ id: u.id, role: u.role, fullName: u.fullName, phone: u.phone, email: u.email, status: u.status, locale: 'en' });
const price = (p: any, extras: any = {}) => { const visit = p?.pricePkr ?? 1200; const platformFee = 150; const cashbackDiscount = 0; return { visit, supplies: 0, lab: extras.labTest ? 500 : 0, medicine: extras.medicineDelivery ? 100 : 0, platformFee, cashbackDiscount, total: visit + platformFee + (extras.labTest ? 500 : 0) + (extras.medicineDelivery ? 100 : 0) }; };
const fullBooking = (b: any) => ({ ...b, professional: professionals.find(p => p.id === b.professionalId), address: addresses.find(a => a.id === b.addressId) });

// ---------------------------------------------------------------- router
type H = (ctx: { req: http.IncomingMessage; res: http.ServerResponse; body: any; auth: any; q: URLSearchParams; p: string[] }) => unknown | Promise<unknown>;
const routes: { m: string; re: RegExp; roles?: R[]; h: H }[] = [];
const route = (m: string, path: string, h: H, roles?: R[]) => routes.push({ m, re: new RegExp('^' + path.replace(/:\w+/g, '([^/]+)') + '$'), roles, h });

route('POST', '/v1/auth/signup', ({ res, body }) => {
  const f: Record<string, string> = {};
  if (!body.fullName) f.fullName = 'Please enter your full name.'; if (!/^\+92\d{10}$/.test(body.phone ?? '')) f.phone = 'Enter a valid Pakistan number like +923001234567.'; if ((body.password ?? '').length < 8) f.password = 'Use at least 8 characters.'; if (!body.acceptedTerms) f.acceptedTerms = 'Please accept the privacy policy and terms.';
  if (Object.keys(f).length) return E(res, 422, 'VALIDATION_ERROR', 'Please fix the highlighted fields.', f);
  if (users.some(u => u.phone === body.phone)) return E(res, 409, 'PHONE_TAKEN', 'This phone number is already registered. Try logging in.');
  const u: U = { id: id(), role: body.role === 'PROFESSIONAL' ? 'PROFESSIONAL' : 'PATIENT', phone: body.phone, password: body.password, fullName: body.fullName, status: 'PENDING' }; users.push(u);
  if (u.role === 'PROFESSIONAL') professionals.push({ id: u.id, fullName: u.fullName, type: body.professionalType ?? 'HOME_VISIT_NURSE', verification: 'DRAFT', ratingAvg: 0, ratingCount: 0, languages: [], badges: [], isOnline: false, distanceKm: 3, pricePkr: 1000, specialization: '', hospitalName: '', bio: '', serviceCode: 'NURSE_HOME_VISIT' });
  const token = id(); otps.set(token, { userId: u.id, tries: 0 }); send(res, 201, { otpToken: token, resendInSeconds: 60 });
});
route('POST', '/v1/auth/verify-otp', ({ res, body }) => {
  const o = otps.get(body.otpToken); if (!o) return E(res, 400, 'OTP_EXPIRED', 'This code has expired. Please request a new one.');
  if (o.tries >= 3) return E(res, 429, 'OTP_LOCKED', 'Too many wrong attempts. Please try again later.');
  if (body.code !== OTP) { o.tries++; return E(res, 400, 'OTP_INVALID', `That code is not correct. ${3 - o.tries} attempts left.`); }
  const u = users.find(x => x.id === o.userId)!; u.status = 'ACTIVE'; otps.delete(body.otpToken); send(res, 200, { ...tokens(u), next: u.role === 'PATIENT' ? 'PROFILE_SETUP' : 'PROFILE_SETUP' });
});
route('POST', '/v1/auth/resend-otp', ({ res }) => send(res, 200, { resendInSeconds: 60 }));
route('POST', '/v1/auth/login', ({ res, body }) => {
  const u = users.find(x => (x.phone === body.identifier || x.email === body.identifier) && x.password === body.password);
  if (!u) return E(res, 401, 'INVALID_CREDENTIALS', 'Phone/email or password is not correct.');
  if (u.status === 'SUSPENDED') return E(res, 403, 'ACCOUNT_SUSPENDED', 'Your account is suspended. Please contact support.');
  if (u.role === 'ADMIN') { const t = id(); otps.set(t, { userId: u.id, tries: 0 }); return send(res, 200, { requires2fa: true, otpToken: t }); }
  send(res, 200, tokens(u));
});
route('POST', '/v1/auth/admin/2fa', ({ res, body }) => { const o = otps.get(body.otpToken); if (!o || body.code !== OTP) return E(res, 400, 'OTP_INVALID', 'That code is not correct.'); otps.delete(body.otpToken); send(res, 200, tokens(users.find(u => u.id === o.userId)!)); });
route('POST', '/v1/auth/refresh', ({ res, body }) => { const p = verify(body.refreshToken); if (!p?.r) return E(res, 401, 'TOKEN_INVALID', 'Please log in again.'); send(res, 200, tokens(users.find(u => u.id === p.sub)!)); });
route('POST', '/v1/auth/logout', ({ res }) => send(res, 204));
route('POST', '/v1/devices', ({ res }) => send(res, 204));
route('GET', '/v1/me', ({ res, auth }) => send(res, 200, pub(users.find(u => u.id === auth.sub)!)));

route('GET', '/v1/catalog/services', ({ res, q }) => send(res, 200, services.filter(s => !q.get('category') || s.category === q.get('category'))));
route('GET', '/v1/professionals', ({ res, q }) => {
  let items = professionals.filter(p => p.verification === 'APPROVED'); const sc = q.get('serviceCode'); if (sc) items = items.filter(p => p.serviceCode === sc);
  if (q.get('availableNow') === 'true') items = items.filter(p => p.isOnline); const t = (q.get('q') ?? '').toLowerCase(); if (t) items = items.filter(p => (p.fullName + p.specialization).toLowerCase().includes(t));
  const s = q.get('sort'); if (s === 'rating') items = [...items].sort((a, b) => b.ratingAvg - a.ratingAvg); if (s === 'price') items = [...items].sort((a, b) => a.pricePkr - b.pricePkr); if (s === 'distance') items = [...items].sort((a, b) => a.distanceKm - b.distanceKm);
  send(res, 200, { items, total: items.length });
});
route('GET', '/v1/professionals/:id', ({ res, p }) => { const x = professionals.find(y => y.id === p[0] && y.verification === 'APPROVED'); x ? send(res, 200, { ...x, credentials: [{ label: 'Degree verified', verified: true }, { label: 'Licence verified', verified: true }, { label: 'Verified by HomiGo Care', verified: true }], topReviews: [] }) : E(res, 404, 'NOT_FOUND', 'Professional not found.'); });

route('GET', '/v1/patient/profile', ({ res, auth }) => send(res, 200, { id: 'p-' + auth.sub, hgcId: 'HGC-ISB-2026-00123', fullName: users.find(u => u.id === auth.sub)!.fullName, cnicMasked: '*****-*******-1', profileComplete: true, walletBalance: 5240 }), ['PATIENT']);
route('PUT', '/v1/patient/profile', ({ res }) => send(res, 200, { ok: true }), ['PATIENT']);
route('PUT', '/v1/patient/emergency-contact', ({ res, body }) => send(res, 200, body), ['PATIENT']);
route('GET', '/v1/patient/addresses', ({ res, auth }) => send(res, 200, addresses.filter(a => a.patientUserId === auth.sub)), ['PATIENT']);
route('POST', '/v1/patient/addresses', ({ res, auth, body }) => { const a = { ...body, id: id(), patientUserId: auth.sub }; addresses.push(a); send(res, 201, a); }, ['PATIENT']);

// ---- bookings
route('POST', '/v1/bookings/quote', ({ res, body }) => send(res, 200, price(professionals.find(p => p.id === body.professionalId), body.extras)));
route('POST', '/v1/bookings', ({ req, res, auth, body }) => {
  const key = String(req.headers['idempotency-key'] ?? ''); if (!key) return E(res, 400, 'IDEMPOTENCY_KEY_REQUIRED', 'Missing Idempotency-Key header.'); if (idem.has(key)) return send(res, 201, idem.get(key));
  const pro = professionals.find(p => p.id === body.professionalId && p.verification === 'APPROVED'); if (!pro) return E(res, 422, 'PROFESSIONAL_UNAVAILABLE', 'This professional is not available. Please choose another.');
  const b = { id: id(), reference: `HGC-2026-${String(++bookingSeq).padStart(5, '0')}`, patientUserId: auth.sub, professionalId: pro.id, serviceCode: body.serviceCode, bookingType: body.bookingType, status: 'PENDING', paid: false, scheduledAt: body.scheduledAt ?? new Date().toISOString(), addressId: body.addressId ?? 'a1', notes: body.notes ?? '', healthPassportConsent: body.healthPassportConsent ?? 'NONE', price: price(pro, body.extras), createdAt: new Date().toISOString(), timeline: [{ status: 'PENDING', at: new Date().toISOString() }] };
  bookings.push(b); const out = fullBooking(b); idem.set(key, out); send(res, 201, out);
}, ['PATIENT']);
route('GET', '/v1/bookings', ({ res, auth, q }) => {
  let l = bookings.filter(b => b.patientUserId === auth.sub || b.professionalId === auth.sub); const tab = q.get('tab');
  if (tab === 'upcoming') l = l.filter(b => ['PENDING', 'ACCEPTED', 'ON_THE_WAY', 'ARRIVED', 'IN_PROGRESS'].includes(b.status)); if (tab === 'completed') l = l.filter(b => b.status === 'COMPLETED'); if (tab === 'cancelled') l = l.filter(b => ['CANCELLED', 'DECLINED', 'EXPIRED'].includes(b.status));
  send(res, 200, { items: l.map(fullBooking), total: l.length });
});
route('GET', '/v1/bookings/:id', ({ res, p }) => { const b = bookings.find(x => x.id === p[0]); b ? send(res, 200, fullBooking(b)) : E(res, 404, 'NOT_FOUND', 'Booking not found.'); });
route('POST', '/v1/payments/confirm', ({ req, res, auth, body }) => {
  const b = bookings.find(x => x.id === body.bookingId && x.patientUserId === auth.sub); if (!b) return E(res, 404, 'NOT_FOUND', 'Booking not found.');
  if (b.paid) return send(res, 200, { status: 'SUCCESS', bookingReference: b.reference });
  b.paid = true; b.paymentMethod = body.method; b.timeline.push({ status: 'PAID', at: new Date().toISOString() });
  emit('booking.offer', { bookingId: b.id, reference: b.reference, patientFirstName: users.find(u => u.id === b.patientUserId)!.fullName.split(' ')[0], service: b.serviceCode, distanceKm: 2.3, expiresAt: new Date(Date.now() + 120000).toISOString(), price: b.price.visit }, u => u.sub === b.professionalId);
  notify(b.professionalId, 'BOOKING_REQUEST', 'New booking request', `${b.reference} — tap to review`, { bookingId: b.id });
  send(res, 200, { status: 'SUCCESS', bookingReference: b.reference });
}, ['PATIENT']);
route('POST', '/v1/bookings/:id/accept', ({ res, auth, p }) => {
  const b = bookings.find(x => x.id === p[0] && x.professionalId === auth.sub); if (!b) return E(res, 404, 'NOT_FOUND', 'Booking not found.'); if (b.status !== 'PENDING') return E(res, 409, 'ALREADY_HANDLED', 'This request was already handled.');
  b.status = 'ACCEPTED'; b.timeline.push({ status: 'ACCEPTED', at: new Date().toISOString() }); emit('booking.updated', { bookingId: b.id, status: 'ACCEPTED' }, u => u.sub === b.patientUserId || u.role === 'ADMIN'); notify(b.patientUserId, 'BOOKING_ACCEPTED', 'Booking accepted', `${professionals.find(x => x.id === b.professionalId)?.fullName} accepted ${b.reference}`, { bookingId: b.id }); send(res, 200, fullBooking(b));
}, ['PROFESSIONAL']);
route('POST', '/v1/bookings/:id/decline', ({ res, auth, p }) => { const b = bookings.find(x => x.id === p[0] && x.professionalId === auth.sub); if (!b) return E(res, 404, 'NOT_FOUND', 'Booking not found.'); b.status = 'DECLINED'; emit('booking.updated', { bookingId: b.id, status: 'DECLINED' }, u => u.sub === b.patientUserId || u.role === 'ADMIN'); send(res, 200, fullBooking(b)); }, ['PROFESSIONAL']);
route('PUT', '/v1/bookings/:id/status', ({ res, auth, p, body }) => { const b = bookings.find(x => x.id === p[0] && x.professionalId === auth.sub); if (!b) return E(res, 404, 'NOT_FOUND', 'Booking not found.'); b.status = body.status; b.timeline.push({ status: body.status, at: new Date().toISOString() }); emit('booking.updated', { bookingId: b.id, status: b.status }, u => u.sub === b.patientUserId || u.role === 'ADMIN'); send(res, 200, fullBooking(b)); }, ['PROFESSIONAL']);
route('GET', '/v1/professional/dashboard', ({ res, auth }) => { const mine = bookings.filter(b => b.professionalId === auth.sub); send(res, 200, { earningsToday: 4500, earningsMonth: 28000, pendingOffers: mine.filter(b => b.status === 'PENDING' && b.paid).map(fullBooking), active: mine.filter(b => ['ON_THE_WAY', 'ARRIVED', 'IN_PROGRESS'].includes(b.status)).map(fullBooking), upcoming: mine.filter(b => b.status === 'ACCEPTED').map(fullBooking) }); }, ['PROFESSIONAL']);
route('GET', '/v1/professional/verification-status', ({ res, auth }) => { const p = professionals.find(x => x.id === auth.sub); send(res, 200, { status: p?.verification ?? 'DRAFT', timeline: [{ step: 'Documents submitted', state: 'done' }, { step: 'Under review', state: p?.verification === 'APPROVED' ? 'done' : 'current' }, { step: 'Assessment test', state: 'pending' }, { step: 'Profile activation', state: 'pending' }] }); }, ['PROFESSIONAL']);
route('POST', '/v1/professional/submit-verification', ({ res, auth }) => { const p = professionals.find(x => x.id === auth.sub); if (p) p.verification = 'SUBMITTED'; send(res, 200, { status: 'SUBMITTED' }); }, ['PROFESSIONAL']);
route('PUT', '/v1/professional/online', ({ res, auth, body }) => { const p = professionals.find(x => x.id === auth.sub); if (p) p.isOnline = !!body.online; send(res, 200, { online: !!body.online }); }, ['PROFESSIONAL']);

// ---- health passport
route('POST', '/v1/health-passport/verify-pin', ({ res, auth, body }) => {
  if (Date.now() < pin.lockedUntil) return E(res, 423, 'PIN_LOCKED', 'Too many wrong attempts. Try again in a few minutes.');
  if (body.pin !== pin.value) { pin.fails++; accessLogs.push({ id: id(), patientUserId: auth.sub, action: 'PIN_FAILED', at: new Date().toISOString() }); if (pin.fails >= 5) { pin.lockedUntil = Date.now() + 5 * 60000; pin.fails = 0; } return E(res, 400, 'PIN_INVALID', 'That PIN is not correct.'); }
  pin.fails = 0; send(res, 200, { passportToken: sign({ sub: auth.sub, passport: 1 }, 300) });
}, ['PATIENT']);
route('POST', '/v1/health-passport/grants', ({ req, res, auth, body }) => {
  if (!verify(String(req.headers['x-passport-token'] ?? ''))?.passport) return E(res, 403, 'PIN_REQUIRED', 'Enter your Health Passport PIN first.');
  const b = bookings.find(x => x.id === body.bookingId && x.patientUserId === auth.sub); if (!b) return E(res, 404, 'NOT_FOUND', 'Booking not found.');
  const g = { id: id(), patientUserId: auth.sub, professionalId: b.professionalId, bookingId: b.id, scope: body.scope, expiresAt: new Date(Date.now() + 86400000).toISOString() }; grants.push(g); accessLogs.push({ id: id(), patientUserId: auth.sub, professionalId: b.professionalId, action: 'GRANT', at: new Date().toISOString() }); send(res, 201, g);
}, ['PATIENT']);
route('GET', '/v1/health-passport/access-log', ({ res, auth }) => send(res, 200, accessLogs.filter(l => l.patientUserId === auth.sub)), ['PATIENT']);
route('GET', '/v1/professional/patients/:id/health-passport', ({ res, auth, p }) => {
  const g = grants.find(x => x.professionalId === auth.sub && x.patientUserId === p[0] && new Date(x.expiresAt) > new Date());
  if (!g) { accessLogs.push({ id: id(), patientUserId: p[0], professionalId: auth.sub, action: 'DENIED', at: new Date().toISOString() }); return E(res, 403, 'NO_GRANT', 'The patient has not authorised access to the Health Passport.'); }
  accessLogs.push({ id: id(), patientUserId: p[0], professionalId: auth.sub, action: 'VIEW_OVERVIEW', at: new Date().toISOString() });
  send(res, 200, { bloodGroup: 'A+', allergies: ['Penicillin'], conditions: ['Type 2 Diabetes'], medications: [{ name: 'Metformin', dose: '500 mg' }], criticalAlert: 'Penicillin allergy', scope: g.scope });
}, ['PROFESSIONAL']);

// ---- SOS
route('POST', '/v1/sos', ({ res, auth, body }) => {
  const u = users.find(x => x.id === auth.sub)!; const a = { id: id(), status: 'ACTIVE', source: 'APP_ONLINE', triggeredAt: new Date().toISOString(), patient: { id: u.id, name: u.fullName, phone: u.phone, emergencyContact: { name: 'Zainab Raza', phone: '+923001112233', relationship: 'SPOUSE' } }, booking: body.bookingId ?? null, location: body.lat ? { lat: body.lat, lng: body.lng, accuracyM: body.accuracyM, at: body.locationAt ?? new Date().toISOString() } : null, networkInfo: body.networkInfo ?? {}, message: body.message ?? '', timeline: [{ kind: 'CREATED', at: new Date().toISOString() }] };
  sos.push(a); emit('sos.created', a, x => x.role === 'ADMIN'); send(res, 201, a);
}, ['PATIENT', 'PROFESSIONAL']);
route('POST', '/v1/sos/:id/location', ({ res, p, body }) => { const a = sos.find(x => x.id === p[0]); if (a) { a.location = { lat: body.lat, lng: body.lng, accuracyM: body.accuracyM, at: new Date().toISOString() }; a.timeline.push({ kind: 'LOCATION_UPDATE', at: a.location.at }); emit('sos.updated', a, x => x.role === 'ADMIN'); } send(res, 204); });
route('GET', '/v1/admin/sos', ({ res, q }) => { const s = q.get('status') ?? 'all'; send(res, 200, sos.filter(a => s === 'all' || (s === 'open') === !['RESOLVED', 'FALSE_ALARM'].includes(a.status)).sort((a, b) => +new Date(b.triggeredAt) - +new Date(a.triggeredAt))); }, ['ADMIN']);
route('GET', '/v1/admin/sos/:id', ({ res, p }) => { const a = sos.find(x => x.id === p[0]); a ? send(res, 200, a) : E(res, 404, 'NOT_FOUND', 'Alert not found.'); }, ['ADMIN']);
const sosAct = (kind: string, status?: string): H => ({ res, auth, p, body }) => { const a = sos.find(x => x.id === p[0]); if (!a) return E(res, 404, 'NOT_FOUND', 'Alert not found.'); if (status) a.status = body.falseAlarm ? 'FALSE_ALARM' : status; a.timeline.push({ kind: body.kind ?? kind, note: body.note, by: auth.sub, at: new Date().toISOString() }); audit.push({ actor: auth.sub, action: 'SOS_' + kind, entity: a.id, at: new Date().toISOString() }); emit('sos.updated', a, x => x.role === 'ADMIN'); send(res, 200, a); };
route('POST', '/v1/admin/sos/:id/acknowledge', sosAct('ACKNOWLEDGED', 'ACKNOWLEDGED'), ['ADMIN']);
route('POST', '/v1/admin/sos/:id/events', sosAct('NOTE'), ['ADMIN']);
route('POST', '/v1/admin/sos/:id/resolve', ({ res, body, ...r }) => body.note ? sosAct('RESOLVED', 'RESOLVED')({ res, body, ...r } as any) : E(res, 422, 'NOTE_REQUIRED', 'Please add a resolution note.'), ['ADMIN']);

// ---- admin
route('GET', '/v1/admin/stats', ({ res }) => send(res, 200, { kpis: { activePatients: users.filter(u => u.role === 'PATIENT').length, verifiedProfessionals: professionals.filter(p => p.verification === 'APPROVED').length, pendingVerifications: professionals.filter(p => ['SUBMITTED', 'UNDER_REVIEW'].includes(p.verification)).length, activeBookings: bookings.filter(b => ['PENDING', 'ACCEPTED'].includes(b.status)).length, completedBookings: bookings.filter(b => b.status === 'COMPLETED').length, openSos: sos.filter(a => !['RESOLVED', 'FALSE_ALARM'].includes(a.status)).length, openDisputes: 0 }, bookingsByStatus: bookings.reduce((m: any, b) => ((m[b.status] = (m[b.status] ?? 0) + 1), m), {}) }), ['ADMIN']);
route('GET', '/v1/admin/professionals', ({ res, q }) => { const s = q.get('status'); send(res, 200, { items: professionals.filter(p => !s || p.verification === s || (s === 'PENDING' && ['SUBMITTED', 'UNDER_REVIEW'].includes(p.verification))), total: professionals.length }); }, ['ADMIN']);
route('GET', '/v1/admin/professionals/:id', ({ res, p }) => { const x = professionals.find(y => y.id === p[0]); x ? send(res, 200, { ...x, documents: ['CNIC_FRONT', 'CNIC_BACK', 'REGULATOR_REGISTRATION', 'DEGREE', 'EXPERIENCE_LETTER', 'CHARACTER_CERT', 'PROFILE_PHOTO'].map(t => ({ id: t, docType: t, reviewStatus: 'PENDING', url: null })) }) : E(res, 404, 'NOT_FOUND', 'Not found.'); }, ['ADMIN']);
route('PUT', '/v1/admin/professionals/:id/decision', ({ res, auth, p, body }) => {
  const x = professionals.find(y => y.id === p[0]); if (!x) return E(res, 404, 'NOT_FOUND', 'Not found.'); if (['REJECT', 'REQUEST_CHANGES'].includes(body.decision) && !body.reason) return E(res, 422, 'REASON_REQUIRED', 'Please give a reason.');
  x.verification = { APPROVE: 'APPROVED', REJECT: 'REJECTED', REQUEST_CHANGES: 'ACTION_REQUIRED' }[body.decision as string] ?? x.verification; audit.push({ actor: auth.sub, action: 'PROFESSIONAL_' + body.decision, entity: x.id, reason: body.reason, at: new Date().toISOString() });
  emit('verification.updated', { status: x.verification, reason: body.reason }, u => u.sub === x.id); notify(x.id, 'VERIFICATION_RESULT', 'Verification update', `Your status is now ${x.verification}`); send(res, 200, x);
}, ['ADMIN']);
route('GET', '/v1/admin/bookings', ({ res }) => send(res, 200, { items: bookings.map(fullBooking), total: bookings.length }), ['ADMIN']);
route('GET', '/v1/admin/audit-logs', ({ res }) => send(res, 200, audit), ['ADMIN']);
route('GET', '/v1/notifications', ({ res, auth }) => send(res, 200, notifications.filter(n => n.userId === auth.sub).reverse()));
route('POST', '/v1/notifications/read-all', ({ res, auth }) => { notifications.filter(n => n.userId === auth.sub).forEach(n => (n.readAt = new Date().toISOString())); send(res, 204); });
route('POST', '/v1/public/waitlist', ({ res }) => send(res, 201, { ok: true }));

// ---------------------------------------------------------------- server
http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204);
  const url = new URL(req.url ?? '/', 'http://x'); const path = url.pathname.replace(/\/$/, '');
  if (path === '/v1/rt/stream') { const user = verify(url.searchParams.get('token') ?? ''); if (!user) return E(res, 401, 'UNAUTHORIZED', 'Invalid token.'); res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'Access-Control-Allow-Origin': '*' }); res.write(': connected\n\n'); const c = { res, user }; clients.add(c); req.on('close', () => clients.delete(c)); return; }
  if (path === '/health') return send(res, 200, { ok: true, mock: true });
  const open = ['/v1/auth/signup', '/v1/auth/verify-otp', '/v1/auth/resend-otp', '/v1/auth/login', '/v1/auth/admin/2fa', '/v1/auth/refresh', '/v1/catalog/services', '/v1/public/waitlist'];
  const auth = verify((req.headers.authorization ?? '').replace('Bearer ', ''));
  for (const r of routes) {
    if (r.m !== req.method) continue; const m = path.match(r.re); if (!m) continue;
    if (!auth && !open.includes(path) && !(req.method === 'GET' && /^\/v1\/professionals(\/[^/]+)?$/.test(path))) return E(res, 401, 'UNAUTHORIZED', 'Please log in to continue.');
    if (r.roles && !r.roles.includes(auth?.role)) return E(res, 403, 'FORBIDDEN', 'You do not have access to this.');
    try { await r.h({ req, res, body: req.method === 'GET' ? {} : await readBody(req), auth, q: url.searchParams, p: m.slice(1) }); } catch (e) { console.error(e); E(res, 500, 'SERVER_ERROR', 'Something went wrong. Please try again.'); } return;
  }
  E(res, 404, 'NOT_FOUND', 'Unknown endpoint (see 03_SPECS/api/openapi.yaml).');
}).listen(PORT, () => console.log(`HomiGo mock API on http://localhost:${PORT}/v1  (OTP 123456)`));
